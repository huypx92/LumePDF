use crate::color_cms::{apply_color_pipeline, ColorMode, MonitorColorProfile};
use libloading::{Library, Symbol};
use lru::LruCache;
use memmap2::Mmap;
use std::collections::HashMap;
use std::ffi::{c_int, c_ulong, c_void};
use std::fs::File;
use std::num::NonZeroUsize;
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;
use url::Url;

// Định nghĩa các kiểu con trỏ hàm C chuẩn của Google PDFium
type FpdfDocument = *mut c_void;
type FpdfPage = *mut c_void;
type FpdfBitmap = *mut c_void;
type FpdfLink = *mut c_void;
type FpdfDest = *mut c_void;
type FpdfAction = *mut c_void;
type FpdfAnnotation = *mut c_void;

const FPDF_ANNOT: c_int = 0x01;
const FPDF_LCD_TEXT: c_int = 0x02;
const FPDF_REVERSE_BYTE_ORDER: c_int = 0x10;
const FPDF_RENDER_LIMITEDIMAGECACHE: c_int = 0x200;
const FPDF_RENDER_NO_SMOOTHIMAGE: c_int = 0x2000;
const FPDFBITMAP_BGRA: c_int = 4;

const PDFACTION_GOTO: c_ulong = 1;
const PDFACTION_REMOTEGOTO: c_ulong = 2;
const PDFACTION_URI: c_ulong = 3;
const PDFACTION_LAUNCH: c_ulong = 4;

type FnInitLibrary = unsafe extern "C" fn();
type FnDestroyLibrary = unsafe extern "C" fn();
type FnLoadMemDocument64 =
    unsafe extern "C" fn(data_buf: *const c_void, size: usize, password: *const i8) -> FpdfDocument;
type FnLoadMemDocument =
    unsafe extern "C" fn(data_buf: *const c_void, size: c_int, password: *const i8) -> FpdfDocument;
type FnCloseDocument = unsafe extern "C" fn(document: FpdfDocument);
type FnGetPageCount = unsafe extern "C" fn(document: FpdfDocument) -> c_int;
type FnGetPageSizeByIndexF =
    unsafe extern "C" fn(document: FpdfDocument, page_index: c_int, size: *mut FsSizeF) -> c_int;
type FnGetPageSizeByIndex = unsafe extern "C" fn(
    document: FpdfDocument,
    page_index: c_int,
    width: *mut f64,
    height: *mut f64,
) -> c_int;
type FnLoadPage = unsafe extern "C" fn(document: FpdfDocument, page_index: c_int) -> FpdfPage;
type FnClosePage = unsafe extern "C" fn(page: FpdfPage);
type FnBitmapCreateEx = unsafe extern "C" fn(
    width: c_int,
    height: c_int,
    format: c_int,
    first_scan: *mut c_void,
    stride: c_int,
) -> FpdfBitmap;
type FnBitmapFillRect = unsafe extern "C" fn(
    bitmap: FpdfBitmap,
    left: c_int,
    top: c_int,
    width: c_int,
    height: c_int,
    color: c_ulong,
);
type FnBitmapDestroy = unsafe extern "C" fn(bitmap: FpdfBitmap);
type FnRenderPageBitmap = unsafe extern "C" fn(
    bitmap: FpdfBitmap,
    page: FpdfPage,
    start_x: c_int,
    start_y: c_int,
    size_x: c_int,
    size_y: c_int,
    rotate: c_int,
    flags: c_int,
);
type FnGetLastError = unsafe extern "C" fn() -> c_ulong;
type FnLinkEnumerate =
    unsafe extern "C" fn(page: FpdfPage, start_pos: *mut c_int, link_annot: *mut FpdfLink) -> c_int;
type FnLinkGetAnnotRect =
    unsafe extern "C" fn(link_annot: FpdfLink, rect: *mut FsRectF) -> c_int;
type FnLinkGetDest =
    unsafe extern "C" fn(document: FpdfDocument, link: FpdfLink) -> FpdfDest;
type FnLinkGetAction = unsafe extern "C" fn(link: FpdfLink) -> FpdfAction;
type FnActionGetType = unsafe extern "C" fn(action: FpdfAction) -> c_ulong;
type FnActionGetDest =
    unsafe extern "C" fn(document: FpdfDocument, action: FpdfAction) -> FpdfDest;
type FnActionGetUriPath = unsafe extern "C" fn(
    document: FpdfDocument,
    action: FpdfAction,
    buffer: *mut c_void,
    buflen: c_ulong,
) -> c_ulong;
type FnActionGetFilePath =
    unsafe extern "C" fn(action: FpdfAction, buffer: *mut c_void, buflen: c_ulong) -> c_ulong;
type FnDestGetDestPageIndex =
    unsafe extern "C" fn(document: FpdfDocument, dest: FpdfDest) -> c_int;
type FnPageGetAnnotCount = unsafe extern "C" fn(page: FpdfPage) -> c_int;
type FnPageGetAnnot = unsafe extern "C" fn(page: FpdfPage, index: c_int) -> FpdfAnnotation;
type FnPageCloseAnnot = unsafe extern "C" fn(annot: FpdfAnnotation);
type FnAnnotGetRect =
    unsafe extern "C" fn(annot: FpdfAnnotation, rect: *mut FsRectF) -> c_int;
type FnAnnotGetLink = unsafe extern "C" fn(annot: FpdfAnnotation) -> FpdfLink;

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
struct FsSizeF {
    width: f32,
    height: f32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
struct FsRectF {
    left: f32,
    top: f32,
    right: f32,
    bottom: f32,
}

#[derive(Debug, Clone)]
pub enum PdfLinkTarget {
    /// Nhảy tới trang đích (0-based page_index) trong cùng tài liệu PDF
    GoToPage(usize),
    /// Mở liên kết HTTP hoặc HTTPS trong trình duyệt.
    ExternalUri(String),
    /// Mở tài liệu PDF theo đường dẫn tương đối bên dưới thư mục của tài liệu đang xem.
    LinkedPdf(PathBuf),
}

fn web_link_target(value: &str) -> Option<PdfLinkTarget> {
    let url = Url::parse(value).ok()?;
    matches!(url.scheme(), "http" | "https").then(|| PdfLinkTarget::ExternalUri(url.into()))
}

fn relative_pdf_target(value: &str) -> Option<PdfLinkTarget> {
    if value.starts_with(['/', '\\']) || value.contains([':', '\0']) {
        return None;
    }
    let portable = value.replace('\\', "/");
    let path = Path::new(&portable);
    let is_pdf = path.extension()?.to_str()?.eq_ignore_ascii_case("pdf");
    let within_folder = path.components().all(|part| {
        matches!(part, Component::Normal(_) | Component::CurDir)
    });
    (is_pdf && within_folder).then(|| PdfLinkTarget::LinkedPdf(path.to_path_buf()))
}

#[cfg(test)]
mod interactive_tests {
    use super::*;

    #[test]
    fn external_link_targets_are_limited_to_websites_and_nearby_pdfs() {
        assert!(matches!(web_link_target("https://example.org/"), Some(PdfLinkTarget::ExternalUri(_))));
        assert!(web_link_target("file:///example.pdf").is_none());
        assert!(web_link_target("mailto:support@example.org").is_none());
        assert!(matches!(relative_pdf_target("Docs/Guide.PDF"), Some(PdfLinkTarget::LinkedPdf(_))));
        assert!(relative_pdf_target("../Guide.pdf").is_none());
        assert!(relative_pdf_target(r"C:\Docs\Guide.pdf").is_none());
        assert!(relative_pdf_target("Guide.exe").is_none());
    }

    #[test]
    #[ignore = "requires the PDFium library for this target"]
    fn extracts_interactive_links_with_pdfium() {
        use std::io::Write;

        let objects = [
            "<< /Type /Catalog /Pages 2 0 R >>",
            "<< /Type /Pages /Count 2 /Kids [3 0 R 4 0 R] >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 300] /Annots [5 0 R 6 0 R] >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 300] >>",
            "<< /Type /Annot /Subtype /Link /Rect [20 200 100 250] /Dest [4 0 R /Fit] >>",
            "<< /Type /Annot /Subtype /Link /Rect [20 100 100 150] /A << /S /URI /URI (https://example.org/) >> >>",
        ];
        let mut pdf = b"%PDF-1.4\n".to_vec();
        let mut offsets = Vec::new();
        for (index, object) in objects.iter().enumerate() {
            offsets.push(pdf.len());
            write!(pdf, "{} 0 obj\n{object}\nendobj\n", index + 1).unwrap();
        }
        let xref = pdf.len();
        let size = offsets.len() + 1;
        write!(pdf, "xref\n0 {size}\n0000000000 65535 f \n").unwrap();
        for offset in offsets {
            writeln!(pdf, "{offset:010} 00000 n ").unwrap();
        }
        write!(pdf, "trailer\n<< /Size {size} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n").unwrap();

        let path = std::env::temp_dir().join(format!("lumepdf-link-test-{}.pdf", std::process::id()));
        std::fs::write(&path, pdf).unwrap();
        let mut doc = PdfDocumentHandle::open(PdfiumLibrary::load().unwrap(), &path).unwrap();
        let links = doc.get_page_links(0);
        assert_eq!(links.len(), 2);
        let internal = links.iter().find(|link| matches!(link.target, PdfLinkTarget::GoToPage(1))).unwrap();
        assert!((internal.norm_x0 - 0.1).abs() < 0.001);
        assert!(links.iter().any(|link| matches!(&link.target, PdfLinkTarget::ExternalUri(uri) if uri == "https://example.org/")));
        assert!(doc.get_page_links(1).is_empty());
        drop(doc);
        std::fs::remove_file(path).unwrap();
    }
}

#[derive(Debug, Clone)]
pub struct PdfInteractiveLink {
    /// Tọa độ chuẩn hóa [0.0 .. 1.0] tính từ góc TRÊN-TRÁI của trang gốc (chưa xoay)
    pub norm_x0: f32,
    pub norm_y0: f32,
    pub norm_x1: f32,
    pub norm_y1: f32,
    pub target: PdfLinkTarget,
}

impl PdfInteractiveLink {
    /// Chuyển đổi vùng tương tác chuẩn hóa sang tọa độ [0.0 .. 1.0] sau khi xoay trang (0, 90, 180, 270 độ)
    pub fn rotated_norm_bounds(&self, rotation_steps: i32) -> (f32, f32, f32, f32) {
        let u0 = self.norm_x0;
        let v0 = self.norm_y0;
        let u1 = self.norm_x1;
        let v1 = self.norm_y1;
        match rotation_steps.rem_euclid(4) {
            1 => (1.0 - v1, u0, 1.0 - v0, u1),
            2 => (1.0 - u1, 1.0 - v1, 1.0 - u0, 1.0 - v0),
            3 => (v0, 1.0 - u1, v1, 1.0 - u0),
            _ => (u0, v0, u1, v1),
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct PageDimension {
    pub width_pt: f32,
    pub height_pt: f32,
}

impl PageDimension {
    pub fn aspect_ratio(&self, rotation_steps: i32) -> f32 {
        let (w, h) = self.rotated_size(rotation_steps);
        if h <= 0.1 {
            1.0 / 1.4142
        } else {
            w / h
        }
    }

    pub fn rotated_size(&self, rotation_steps: i32) -> (f32, f32) {
        if rotation_steps.rem_euclid(2) == 1 {
            (self.height_pt, self.width_pt)
        } else {
            (self.width_pt, self.height_pt)
        }
    }
}

/// Thông tin hệ màu phát hiện bên trong file PDF thiết kế
#[derive(Debug, Clone, Default)]
pub struct PdfColorMetadata {
    pub has_cmyk: bool,
    pub has_icc_profile: bool,
    pub has_spot_pantone: bool,
    pub has_output_intent: bool,
    pub has_transparency_group: bool,
}

impl PdfColorMetadata {
    pub fn summary_badge(&self) -> String {
        let mut tags = Vec::new();
        if self.has_cmyk {
            tags.push("CMYK");
        } else {
            tags.push("RGB");
        }
        if self.has_icc_profile || self.has_output_intent {
            tags.push("ICC");
        }
        if self.has_spot_pantone {
            tags.push("Spot/Pantone");
        }
        tags.join(" + ")
    }
}

pub struct PdfiumLibrary {
    _lib: Library,
    f_destroy_library: FnDestroyLibrary,
    f_load_mem_doc64: Option<FnLoadMemDocument64>,
    f_load_mem_doc: FnLoadMemDocument,
    f_close_doc: FnCloseDocument,
    f_get_page_count: FnGetPageCount,
    f_get_page_size_f: Option<FnGetPageSizeByIndexF>,
    f_get_page_size: FnGetPageSizeByIndex,
    f_load_page: FnLoadPage,
    f_close_page: FnClosePage,
    f_bitmap_create_ex: FnBitmapCreateEx,
    f_bitmap_fill_rect: FnBitmapFillRect,
    f_bitmap_destroy: FnBitmapDestroy,
    f_render_page_bitmap: FnRenderPageBitmap,
    f_get_last_error: FnGetLastError,
    f_link_enumerate: Option<FnLinkEnumerate>,
    f_link_get_annot_rect: Option<FnLinkGetAnnotRect>,
    f_link_get_dest: Option<FnLinkGetDest>,
    f_link_get_action: Option<FnLinkGetAction>,
    f_action_get_type: Option<FnActionGetType>,
    f_action_get_dest: Option<FnActionGetDest>,
    f_action_get_uri_path: Option<FnActionGetUriPath>,
    f_action_get_file_path: Option<FnActionGetFilePath>,
    f_dest_get_page_index: Option<FnDestGetDestPageIndex>,
    f_page_get_annot_count: Option<FnPageGetAnnotCount>,
    f_page_get_annot: Option<FnPageGetAnnot>,
    f_page_close_annot: Option<FnPageCloseAnnot>,
    f_annot_get_rect: Option<FnAnnotGetRect>,
    f_annot_get_link: Option<FnAnnotGetLink>,
}

unsafe impl Send for PdfiumLibrary {}
unsafe impl Sync for PdfiumLibrary {}

impl PdfiumLibrary {
    pub fn load() -> Result<Arc<Self>, String> {
        let candidates = Self::candidate_dll_paths();
        let mut last_err = String::new();

        for path in &candidates {
            if !path.exists() {
                continue;
            }
            unsafe {
                match Library::new(path) {
                    Ok(lib) => {
                        let f_init: Symbol<FnInitLibrary> = lib
                            .get(b"FPDF_InitLibrary\0")
                            .map_err(|e| format!("Thiếu FPDF_InitLibrary: {e}"))?;
                        f_init();

                        let f_destroy_library = *lib
                            .get::<FnDestroyLibrary>(b"FPDF_DestroyLibrary\0")
                            .map_err(|e| e.to_string())?;
                        let f_load_mem_doc64 = lib
                            .get::<FnLoadMemDocument64>(b"FPDF_LoadMemDocument64\0")
                            .ok()
                            .map(|s| *s);
                        let f_load_mem_doc = *lib
                            .get::<FnLoadMemDocument>(b"FPDF_LoadMemDocument\0")
                            .map_err(|e| e.to_string())?;
                        let f_close_doc = *lib
                            .get::<FnCloseDocument>(b"FPDF_CloseDocument\0")
                            .map_err(|e| e.to_string())?;
                        let f_get_page_count = *lib
                            .get::<FnGetPageCount>(b"FPDF_GetPageCount\0")
                            .map_err(|e| e.to_string())?;
                        let f_get_page_size_f = lib
                            .get::<FnGetPageSizeByIndexF>(b"FPDF_GetPageSizeByIndexF\0")
                            .ok()
                            .map(|s| *s);
                        let f_get_page_size = *lib
                            .get::<FnGetPageSizeByIndex>(b"FPDF_GetPageSizeByIndex\0")
                            .map_err(|e| e.to_string())?;
                        let f_load_page = *lib
                            .get::<FnLoadPage>(b"FPDF_LoadPage\0")
                            .map_err(|e| e.to_string())?;
                        let f_close_page = *lib
                            .get::<FnClosePage>(b"FPDF_ClosePage\0")
                            .map_err(|e| e.to_string())?;
                        let f_bitmap_create_ex = *lib
                            .get::<FnBitmapCreateEx>(b"FPDFBitmap_CreateEx\0")
                            .map_err(|e| e.to_string())?;
                        let f_bitmap_fill_rect = *lib
                            .get::<FnBitmapFillRect>(b"FPDFBitmap_FillRect\0")
                            .map_err(|e| e.to_string())?;
                        let f_bitmap_destroy = *lib
                            .get::<FnBitmapDestroy>(b"FPDFBitmap_Destroy\0")
                            .map_err(|e| e.to_string())?;
                        let f_render_page_bitmap = *lib
                            .get::<FnRenderPageBitmap>(b"FPDF_RenderPageBitmap\0")
                            .map_err(|e| e.to_string())?;
                        let f_get_last_error = *lib
                            .get::<FnGetLastError>(b"FPDF_GetLastError\0")
                            .map_err(|e| e.to_string())?;
                        let f_link_enumerate = lib
                            .get::<FnLinkEnumerate>(b"FPDFLink_Enumerate\0")
                            .ok()
                            .map(|s| *s);
                        let f_link_get_annot_rect = lib
                            .get::<FnLinkGetAnnotRect>(b"FPDFLink_GetAnnotRect\0")
                            .ok()
                            .map(|s| *s);
                        let f_link_get_dest = lib
                            .get::<FnLinkGetDest>(b"FPDFLink_GetDest\0")
                            .ok()
                            .map(|s| *s);
                        let f_link_get_action = lib
                            .get::<FnLinkGetAction>(b"FPDFLink_GetAction\0")
                            .ok()
                            .map(|s| *s);
                        let f_action_get_type = lib
                            .get::<FnActionGetType>(b"FPDFAction_GetType\0")
                            .ok()
                            .map(|s| *s);
                        let f_action_get_dest = lib
                            .get::<FnActionGetDest>(b"FPDFAction_GetDest\0")
                            .ok()
                            .map(|s| *s);
                        let f_action_get_uri_path = lib
                            .get::<FnActionGetUriPath>(b"FPDFAction_GetURIPath\0")
                            .ok()
                            .map(|s| *s);
                        let f_action_get_file_path = lib
                            .get::<FnActionGetFilePath>(b"FPDFAction_GetFilePath\0")
                            .ok()
                            .map(|s| *s);
                        let f_dest_get_page_index = lib
                            .get::<FnDestGetDestPageIndex>(b"FPDFDest_GetDestPageIndex\0")
                            .ok()
                            .map(|s| *s);
                        let f_page_get_annot_count = lib
                            .get::<FnPageGetAnnotCount>(b"FPDFPage_GetAnnotCount\0")
                            .ok()
                            .map(|s| *s);
                        let f_page_get_annot = lib
                            .get::<FnPageGetAnnot>(b"FPDFPage_GetAnnot\0")
                            .ok()
                            .map(|s| *s);
                        let f_page_close_annot = lib
                            .get::<FnPageCloseAnnot>(b"FPDFPage_CloseAnnot\0")
                            .ok()
                            .map(|s| *s);
                        let f_annot_get_rect = lib
                            .get::<FnAnnotGetRect>(b"FPDFAnnot_GetRect\0")
                            .ok()
                            .map(|s| *s);
                        let f_annot_get_link = lib
                            .get::<FnAnnotGetLink>(b"FPDFAnnot_GetLink\0")
                            .ok()
                            .map(|s| *s);

                        return Ok(Arc::new(Self {
                            _lib: lib,
                            f_destroy_library,
                            f_load_mem_doc64,
                            f_load_mem_doc,
                            f_close_doc,
                            f_get_page_count,
                            f_get_page_size_f,
                            f_get_page_size,
                            f_load_page,
                            f_close_page,
                            f_bitmap_create_ex,
                            f_bitmap_fill_rect,
                            f_bitmap_destroy,
                            f_render_page_bitmap,
                            f_get_last_error,
                            f_link_enumerate,
                            f_link_get_annot_rect,
                            f_link_get_dest,
                            f_link_get_action,
                            f_action_get_type,
                            f_action_get_dest,
                            f_action_get_uri_path,
                            f_action_get_file_path,
                            f_dest_get_page_index,
                            f_page_get_annot_count,
                            f_page_get_annot,
                            f_page_close_annot,
                            f_annot_get_rect,
                            f_annot_get_link,
                        }));
                    }
                    Err(e) => {
                        last_err = format!("Không thể nạp {:?}: {e}", path);
                    }
                }
            }
        }

        Err(format!(
            "Không tìm thấy thư viện nhân Google PDFium (pdfium.dll). Đã kiểm tra: {:?}. Lỗi cuối: {}",
            candidates, last_err
        ))
    }

    fn candidate_dll_paths() -> Vec<PathBuf> {
        #[cfg(target_os = "macos")]
        let lib_name = "libpdfium.dylib";
        #[cfg(all(unix, not(target_os = "macos")))]
        let lib_name = "libpdfium.so";
        #[cfg(windows)]
        let lib_name = "pdfium.dll";

        let mut paths = Vec::new();
        if let Ok(exe_path) = std::env::current_exe() {
            if let Some(exe_dir) = exe_path.parent() {
                paths.push(exe_dir.join(lib_name));
                paths.push(exe_dir.join("vendor").join(lib_name));
                if let Some(parent) = exe_dir.parent() {
                    paths.push(parent.join(lib_name));
                    paths.push(parent.join("Frameworks").join(lib_name));
                    paths.push(parent.join("Resources").join(lib_name));
                    paths.push(parent.join("vendor").join(lib_name));
                    if let Some(grand) = parent.parent() {
                        paths.push(grand.join("vendor").join(lib_name));
                    }
                }
            }
        }
        if let Ok(cwd) = std::env::current_dir() {
            paths.push(cwd.join(lib_name));
            paths.push(cwd.join("vendor").join(lib_name));
        }
        #[cfg(windows)]
        paths.push(PathBuf::from(r"d:\des\lumepdf\vendor\pdfium.dll"));
        #[cfg(target_os = "macos")]
        {
            paths.push(PathBuf::from("/Applications/LumePDF.app/Contents/MacOS/libpdfium.dylib"));
            paths.push(PathBuf::from("/Applications/LumePDF.app/Contents/Frameworks/libpdfium.dylib"));
        }
        paths
    }
}

impl Drop for PdfiumLibrary {
    fn drop(&mut self) {
        unsafe {
            (self.f_destroy_library)();
        }
    }
}

/// Tài liệu PDF đã được ánh xạ bộ nhớ (Memory-Mapped) kèm bộ đệm trang FPDF_PAGE (CPDF_PageRenderCache)
pub struct PdfDocumentHandle {
    lib: Arc<PdfiumLibrary>,
    doc: FpdfDocument,
    _mmap: Mmap,
    loaded_pages: LruCache<usize, FpdfPage>,
    page_links_cache: HashMap<usize, Vec<PdfInteractiveLink>>,
    pub file_size_bytes: u64,
    pub page_dimensions: Vec<PageDimension>,
    pub color_meta: PdfColorMetadata,
}

unsafe impl Send for PdfDocumentHandle {}

impl PdfDocumentHandle {
    pub fn open(lib: Arc<PdfiumLibrary>, path: &Path) -> Result<Self, String> {
        let file = File::open(path)
            .map_err(|e| format!("Không thể mở file '{}': {e}", path.display()))?;
        let file_size_bytes = file.metadata().map(|m| m.len()).unwrap_or(0);
        if file_size_bytes == 0 {
            return Err("File PDF trống (0 byte).".to_string());
        }

        let mmap = unsafe {
            Mmap::map(&file)
                .map_err(|e| format!("Không thể ánh xạ bộ nhớ cho file PDF: {e}"))?
        };

        let doc = unsafe {
            if let Some(load64) = lib.f_load_mem_doc64 {
                load64(
                    mmap.as_ptr() as *const c_void,
                    mmap.len(),
                    std::ptr::null(),
                )
            } else {
                let len_i32 = i32::try_from(mmap.len())
                    .map_err(|_| "File PDF vượt quá 2GB, cần FPDF_LoadMemDocument64")?;
                (lib.f_load_mem_doc)(
                    mmap.as_ptr() as *const c_void,
                    len_i32,
                    std::ptr::null(),
                )
            }
        };

        if doc.is_null() {
            let err_code = unsafe { (lib.f_get_last_error)() };
            let reason = match err_code {
                2 => "File không tồn tại hoặc không thể đọc",
                3 => "Định dạng PDF bị lỗi hoặc không hợp lệ",
                4 => "File PDF được đặt mật khẩu bảo vệ",
                5 => "Cơ chế bảo mật PDF không hỗ trợ",
                _ => "Không thể giải mã cấu trúc PDF",
            };
            return Err(format!("{reason} (Mã lỗi PDFium: {err_code})"));
        }

        let page_count = unsafe { (lib.f_get_page_count)(doc) };
        if page_count <= 0 {
            unsafe { (lib.f_close_doc)(doc) };
            return Err("File PDF không có trang nào.".to_string());
        }

        let mut page_dimensions = Vec::with_capacity(page_count as usize);
        for idx in 0..page_count {
            let dim = unsafe {
                if let Some(get_size_f) = lib.f_get_page_size_f {
                    let mut sz = FsSizeF::default();
                    if get_size_f(doc, idx, &mut sz) != 0 && sz.width > 1.0 && sz.height > 1.0 {
                        PageDimension {
                            width_pt: sz.width,
                            height_pt: sz.height,
                        }
                    } else {
                        PageDimension {
                            width_pt: 595.0,
                            height_pt: 842.0,
                        }
                    }
                } else {
                    let mut w = 0.0f64;
                    let mut h = 0.0f64;
                    if (lib.f_get_page_size)(doc, idx, &mut w, &mut h) != 0 && w > 1.0 && h > 1.0 {
                        PageDimension {
                            width_pt: w as f32,
                            height_pt: h as f32,
                        }
                    } else {
                        PageDimension {
                            width_pt: 595.0,
                            height_pt: 842.0,
                        }
                    }
                }
            };
            page_dimensions.push(dim);
        }

        let color_meta = Self::scan_color_metadata(&mmap);

        Ok(Self {
            lib,
            doc,
            _mmap: mmap,
            loaded_pages: LruCache::new(NonZeroUsize::new(24).unwrap()),
            page_links_cache: HashMap::new(),
            file_size_bytes,
            page_dimensions,
            color_meta,
        })
    }

    /// Quét siêu tốc phần đầu và phần cuối của file PDF (< 1ms) để nhận diện không gian màu thiết kế
    fn scan_color_metadata(data: &[u8]) -> PdfColorMetadata {
        let mut meta = PdfColorMetadata::default();
        let head_len = data.len().min(2 * 1024 * 1024);
        let head = &data[..head_len];

        meta.has_cmyk = find_subslice(head, b"/DeviceCMYK") || find_subslice(head, b"/CMYK");
        meta.has_icc_profile = find_subslice(head, b"/ICCBased");
        meta.has_spot_pantone =
            find_subslice(head, b"/Separation") || find_subslice(head, b"/DeviceN");
        meta.has_output_intent = find_subslice(head, b"/OutputIntents");
        meta.has_transparency_group = find_subslice(head, b"/Transparency");

        if data.len() > head_len {
            let tail_start = data.len().saturating_sub(512 * 1024);
            let tail = &data[tail_start..];
            meta.has_cmyk |= find_subslice(tail, b"/DeviceCMYK");
            meta.has_icc_profile |= find_subslice(tail, b"/ICCBased");
            meta.has_spot_pantone |=
                find_subslice(tail, b"/Separation") || find_subslice(tail, b"/DeviceN");
            meta.has_output_intent |= find_subslice(tail, b"/OutputIntents");
        }

        meta
    }

    /// Lấy FPDF_PAGE từ bộ đệm LRU để giữ nguyên CPDF_PageRenderCache (không phải giải mã lại ảnh CMYK khi Zoom/Thumbnail)
    fn get_or_load_page(&mut self, page_index: usize) -> Result<FpdfPage, String> {
        if let Some(&page) = self.loaded_pages.get(&page_index) {
            return Ok(page);
        }

        let page = unsafe { (self.lib.f_load_page)(self.doc, page_index as c_int) };
        if page.is_null() {
            return Err(format!("Không thể tải trang {}", page_index + 1));
        }

        if self.loaded_pages.len() >= self.loaded_pages.cap().get() {
            if let Some((_, evicted_page)) = self.loaded_pages.pop_lru() {
                if !evicted_page.is_null() {
                    unsafe {
                        (self.lib.f_close_page)(evicted_page);
                    }
                }
            }
        }

        self.loaded_pages.put(page_index, page);
        Ok(page)
    }

    /// Trích xuất toàn bộ các vùng liên kết tương tác (Link / Nút bấm chuyển trang / URL) trên 1 trang PDF
    pub fn get_page_links(&mut self, page_index: usize) -> Vec<PdfInteractiveLink> {
        if let Some(cached) = self.page_links_cache.get(&page_index) {
            return cached.clone();
        }

        let Some(&dim) = self.page_dimensions.get(page_index) else {
            return Vec::new();
        };
        let Ok(page) = self.get_or_load_page(page_index) else {
            return Vec::new();
        };

        let page_count = self.page_dimensions.len();
        let w_pt = dim.width_pt.max(1.0);
        let h_pt = dim.height_pt.max(1.0);
        let mut links = Vec::new();

        unsafe {
            if let (Some(f_enum), Some(f_rect)) =
                (self.lib.f_link_enumerate, self.lib.f_link_get_annot_rect)
            {
                let mut start_pos: c_int = 0;
                let mut link_ptr: FpdfLink = std::ptr::null_mut();
                while f_enum(page, &mut start_pos, &mut link_ptr) != 0 && !link_ptr.is_null() {
                    let mut rect = FsRectF::default();
                    if f_rect(link_ptr, &mut rect) != 0 {
                        if let Some(target) = self.resolve_link_target(link_ptr, page_count) {
                            if let Some(item) = Self::build_interactive_link(rect, w_pt, h_pt, target)
                            {
                                links.push(item);
                            }
                        }
                    }
                }
            }

            // Hỗ trợ bổ sung nếu PDF dùng Annotation Widget/Link không qua FPDFLink_Enumerate
            if links.is_empty() {
                if let (
                    Some(f_count),
                    Some(f_get_annot),
                    Some(f_close_annot),
                    Some(f_annot_rect),
                    Some(f_annot_link),
                ) = (
                    self.lib.f_page_get_annot_count,
                    self.lib.f_page_get_annot,
                    self.lib.f_page_close_annot,
                    self.lib.f_annot_get_rect,
                    self.lib.f_annot_get_link,
                ) {
                    let count = f_count(page).clamp(0, 500);
                    for i in 0..count {
                        let annot = f_get_annot(page, i);
                        if !annot.is_null() {
                            let link_ptr = f_annot_link(annot);
                            let mut rect = FsRectF::default();
                            if !link_ptr.is_null() && f_annot_rect(annot, &mut rect) != 0 {
                                if let Some(target) = self.resolve_link_target(link_ptr, page_count)
                                {
                                    if let Some(item) =
                                        Self::build_interactive_link(rect, w_pt, h_pt, target)
                                    {
                                        links.push(item);
                                    }
                                }
                            }
                            f_close_annot(annot);
                        }
                    }
                }
            }
        }

        self.page_links_cache.insert(page_index, links.clone());
        links
    }

    fn build_interactive_link(
        rect: FsRectF,
        w_pt: f32,
        h_pt: f32,
        target: PdfLinkTarget,
    ) -> Option<PdfInteractiveLink> {
        let min_x = rect.left.min(rect.right);
        let max_x = rect.left.max(rect.right);
        let min_y = rect.bottom.min(rect.top);
        let max_y = rect.bottom.max(rect.top);

        if (max_x - min_x) < 1.0 || (max_y - min_y) < 1.0 {
            return None;
        }

        let norm_x0 = (min_x / w_pt).clamp(0.0, 1.0);
        let norm_x1 = (max_x / w_pt).clamp(0.0, 1.0);
        let norm_y0 = ((h_pt - max_y) / h_pt).clamp(0.0, 1.0);
        let norm_y1 = ((h_pt - min_y) / h_pt).clamp(0.0, 1.0);

        if norm_x1 <= norm_x0 || norm_y1 <= norm_y0 {
            return None;
        }

        Some(PdfInteractiveLink {
            norm_x0,
            norm_y0,
            norm_x1,
            norm_y1,
            target,
        })
    }

    unsafe fn resolve_link_target(
        &self,
        link_ptr: FpdfLink,
        page_count: usize,
    ) -> Option<PdfLinkTarget> {
        if let (Some(f_get_dest), Some(f_dest_page)) =
            (self.lib.f_link_get_dest, self.lib.f_dest_get_page_index)
        {
            let dest = f_get_dest(self.doc, link_ptr);
            if !dest.is_null() {
                let page_idx = f_dest_page(self.doc, dest);
                if page_idx >= 0 && (page_idx as usize) < page_count {
                    return Some(PdfLinkTarget::GoToPage(page_idx as usize));
                }
            }
        }

        let f_get_action = self.lib.f_link_get_action?;
        let f_action_type = self.lib.f_action_get_type?;
        let act = f_get_action(link_ptr);
        if act.is_null() {
            return None;
        }

        let act_type = f_action_type(act);
        match act_type {
            PDFACTION_GOTO => {
                let f_act_dest = self.lib.f_action_get_dest?;
                let f_dest_page = self.lib.f_dest_get_page_index?;
                let dest = f_act_dest(self.doc, act);
                if !dest.is_null() {
                    let page_idx = f_dest_page(self.doc, dest);
                    if page_idx >= 0 && (page_idx as usize) < page_count {
                        return Some(PdfLinkTarget::GoToPage(page_idx as usize));
                    }
                }
                None
            }
            PDFACTION_URI => {
                let f_uri = self.lib.f_action_get_uri_path?;
                let len = f_uri(self.doc, act, std::ptr::null_mut(), 0);
                if len > 1 && len < 4096 {
                    let mut buf = vec![0u8; len as usize];
                    let written = f_uri(self.doc, act, buf.as_mut_ptr() as *mut c_void, len);
                    if written > 1 {
                        if let Some(&0) = buf.last() {
                            buf.pop();
                        }
                        let uri = String::from_utf8_lossy(&buf).trim().to_string();
                        return web_link_target(&uri);
                    }
                }
                None
            }
            PDFACTION_REMOTEGOTO | PDFACTION_LAUNCH => {
                let f_file = self.lib.f_action_get_file_path?;
                let len = f_file(act, std::ptr::null_mut(), 0);
                if len > 1 && len < 4096 {
                    let mut buf = vec![0u8; len as usize];
                    let written = f_file(act, buf.as_mut_ptr() as *mut c_void, len);
                    if written > 1 {
                        if let Some(&0) = buf.last() {
                            buf.pop();
                        }
                        let path_str = String::from_utf8_lossy(&buf).trim().to_string();
                        return relative_pdf_target(&path_str);
                    }
                }
                None
            }
            _ => None,
        }
    }

    /// Kết xuất 1 trang PDF trực tiếp (Zero-Copy) ra mảng pixel RGBA8 chuẩn màu thiết kế
    pub fn render_page(
        &mut self,
        page_index: usize,
        width_px: u32,
        height_px: u32,
        rotation_steps: i32,
        color_mode: ColorMode,
        monitor_profile: &MonitorColorProfile,
    ) -> Result<RenderedBitmap, String> {
        self.render_page_ex(
            page_index,
            width_px,
            height_px,
            rotation_steps,
            color_mode,
            monitor_profile,
            false,
        )
    }

    pub fn render_page_ex(
        &mut self,
        page_index: usize,
        width_px: u32,
        height_px: u32,
        rotation_steps: i32,
        color_mode: ColorMode,
        monitor_profile: &MonitorColorProfile,
        fast_thumbnail: bool,
    ) -> Result<RenderedBitmap, String> {
        let width_px = width_px.clamp(16, 4096) as c_int;
        let height_px = height_px.clamp(16, 4096) as c_int;
        let rotate = rotation_steps.rem_euclid(4) as c_int;

        let page = self.get_or_load_page(page_index)?;
        let w_usize = width_px as usize;
        let h_usize = height_px as usize;
        let stride = width_px * 4;
        let mut rgba = vec![255u8; w_usize * h_usize * 4];

        unsafe {
            // Tạo Bitmap trỏ trực tiếp vào bộ nhớ của Vec<u8> (Zero-Copy, tiết kiệm 20MB copy mỗi lần vẽ)
            let bitmap = (self.lib.f_bitmap_create_ex)(
                width_px,
                height_px,
                FPDFBITMAP_BGRA,
                rgba.as_mut_ptr() as *mut c_void,
                stride,
            );

            if bitmap.is_null() {
                return Err("Không đủ bộ nhớ để tạo Bitmap kết xuất trang.".to_string());
            }

            // Lấp nền giấy trắng tuyệt đối (0xFFFFFFFF) để hòa trộn chuẩn xác các lớp Transparency Blend Mode
            (self.lib.f_bitmap_fill_rect)(bitmap, 0, 0, width_px, height_px, 0xFFFFFFFF);

            // Với Thumbnail nhỏ hoặc bản xem trước tức thì (fast_thumbnail): tắt nội suy bicubic nặng và LCD subpixel
            // để tăng tốc độ kết xuất lên 3-5 lần. Với trang chính: bật đầy đủ FPDF_LCD_TEXT + FPDF_ANNOT.
            let flags = if fast_thumbnail {
                FPDF_REVERSE_BYTE_ORDER
                    | FPDF_RENDER_LIMITEDIMAGECACHE
                    | FPDF_RENDER_NO_SMOOTHIMAGE
            } else {
                FPDF_ANNOT | FPDF_REVERSE_BYTE_ORDER | FPDF_LCD_TEXT
            };

            (self.lib.f_render_page_bitmap)(
                bitmap, page, 0, 0, width_px, height_px, rotate, flags,
            );

            (self.lib.f_bitmap_destroy)(bitmap);
        }

        // Áp dụng pipeline quản lý màu sắc (ICC / Màn hình / CMYK Soft-Proof)
        apply_color_pipeline(&mut rgba, color_mode, monitor_profile);

        Ok(RenderedBitmap {
            width: w_usize,
            height: h_usize,
            rgba,
        })
    }
}

impl Drop for PdfDocumentHandle {
    fn drop(&mut self) {
        while let Some((_, page)) = self.loaded_pages.pop_lru() {
            if !page.is_null() {
                unsafe {
                    (self.lib.f_close_page)(page);
                }
            }
        }
        if !self.doc.is_null() {
            unsafe {
                (self.lib.f_close_doc)(self.doc);
            }
        }
    }
}

pub struct RenderedBitmap {
    pub width: usize,
    pub height: usize,
    pub rgba: Vec<u8>,
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() || haystack.len() < needle.len() {
        return false;
    }
    haystack
        .windows(needle.len())
        .any(|window| window == needle)
}
