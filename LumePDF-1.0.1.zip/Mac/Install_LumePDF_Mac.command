#!/bin/bash
set -e

clear
echo "================================================================"
echo "  BỘ CÀI ĐẶT LUMEPDF 1.0.1 DÀNH CHO MACOS (APPLE SILICON & INTEL)"
echo "  Phát triển bởi: Huy cola (huypx92@gmail.com)"
echo "================================================================"
echo ""

HERE="$(cd "$(dirname "$0")" && pwd)"
APP_SRC="$HERE/LumePDF.app"
APP_DST="/Applications/LumePDF.app"
ARCH="$(uname -m)"

echo "[1/4] Kiểm tra kiến trúc máy Mac: $ARCH"
if [ "$ARCH" = "arm64" ]; then
    cp -f "$APP_SRC/Contents/Frameworks/libpdfium_arm64.dylib" "$APP_SRC/Contents/MacOS/libpdfium.dylib"
    cp -f "$APP_SRC/Contents/Frameworks/libpdfium_arm64.dylib" "$APP_SRC/Contents/Frameworks/libpdfium.dylib"
else
    cp -f "$APP_SRC/Contents/Frameworks/libpdfium_x64.dylib" "$APP_SRC/Contents/MacOS/libpdfium.dylib"
    cp -f "$APP_SRC/Contents/Frameworks/libpdfium_x64.dylib" "$APP_SRC/Contents/Frameworks/libpdfium.dylib"
fi

export PATH="$HOME/.cargo/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
echo "[2/4] Kiểm tra môi trường biên dịch Native Mach-O..."
if ! command -v cargo >/dev/null 2>&1; then
    echo " -> Đang cài đặt Rust toolchain tự động cho macOS..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    export PATH="$HOME/.cargo/bin:$PATH"
fi

echo "[3/4] Đang biên dịch LumePDF Native cho chip $ARCH..."
cd "$APP_SRC/Contents/Resources/project"
cargo build --locked --release
cp -f "$APP_SRC/Contents/Resources/project/target/release/lumepdf" "$APP_SRC/Contents/MacOS/lumepdf-bin"
chmod +x "$APP_SRC/Contents/MacOS/lumepdf-bin"
chmod +x "$APP_SRC/Contents/MacOS/LumePDF"

echo "[4/4] Đang cài đặt LumePDF.app vào thư mục /Applications..."
rm -rf "$APP_DST"
cp -R "$APP_SRC" "$APP_DST"
xattr -cr "$APP_DST" 2>/dev/null || true

echo ""
echo "================================================================"
echo "  CÀI ĐẶT THÀNH CÔNG! Đang khởi chạy LumePDF..."
echo "================================================================"
open "$APP_DST"
