#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod app;
mod color_cms;
mod i18n;
mod icon_gen;
mod pdf_engine;
mod updates;
mod worker;

use app::LumePdfApp;
use color_cms::{ColorMode, MonitorColorProfile};
use icon_gen::{render_vector_pdf_icon, save_multi_res_ico};
use pdf_engine::{PdfDocumentHandle, PdfiumLibrary};
use std::path::{Path, PathBuf};
use std::time::Instant;

fn main() -> eframe::Result<()> {
    let args: Vec<String> = std::env::args().collect();

    // Chế độ kiểm thử tự động (--self-test <file.pdf> [page_number] [output.png])
    if args.len() >= 3 && args[1] == "--self-test" {
        run_self_test(&args[2..]);
        return Ok(());
    }

    // Chế độ xuất biểu tượng Vector đa phân giải (.ico) và ảnh mẫu (.png)
    if args.len() >= 3 && args[1] == "--export-icon" {
        export_app_icon_ico(&args[2]);
        return Ok(());
    }

    let initial_files: Vec<PathBuf> = std::env::args_os()
        .skip(1)
        .map(PathBuf::from)
        .filter(|p| p.exists())
        .collect();

    let icon = build_window_icon(64);

    let viewport = egui::ViewportBuilder::default()
        .with_title("LumePDF — Xem PDF Siêu Nhẹ & Chuẩn Màu Thiết Kế")
        .with_inner_size([1280.0, 840.0])
        .with_min_inner_size([680.0, 460.0])
        .with_icon(icon);

    let native_options = eframe::NativeOptions {
        viewport,
        // Tắt multisampling thừa trên 2D texture để giữ nguyên độ sắc nét từng pixel của PDFium
        multisampling: 0,
        renderer: eframe::Renderer::Glow,
        ..Default::default()
    };

    eframe::run_native(
        "LumePDF",
        native_options,
        Box::new(move |cc| Ok(Box::new(LumePdfApp::new(cc, initial_files)))),
    )
}

fn run_self_test(test_args: &[String]) {
    let pdf_path = PathBuf::from(&test_args[0]);
    let page_num: usize = test_args
        .get(1)
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(1);
    let out_png = test_args.get(2).map(PathBuf::from);

    let t_lib = Instant::now();
    let lib = PdfiumLibrary::load().expect("Không thể nạp pdfium.dll");
    let lib_ms = t_lib.elapsed().as_secs_f64() * 1000.0;

    let t_open = Instant::now();
    let mut doc = PdfDocumentHandle::open(lib, &pdf_path).expect("Không thể mở file PDF");
    let open_ms = t_open.elapsed().as_secs_f64() * 1000.0;

    let idx = page_num.saturating_sub(1).min(doc.page_dimensions.len() - 1);
    let dim = doc.page_dimensions[idx];
    let target_w = (dim.width_pt * 2.0).round() as u32;
    let target_h = (dim.height_pt * 2.0).round() as u32;

    let monitor = MonitorColorProfile::detect_from_windows();
    let t_render = Instant::now();
    let rendered = doc
        .render_page(idx, target_w, target_h, 0, ColorMode::StandardSrgb, &monitor)
        .expect("Lỗi kết xuất trang");
    let render_ms = t_render.elapsed().as_secs_f64() * 1000.0;

    if let Some(png_path) = out_png {
        if let Some(img_buf) = image::RgbaImage::from_raw(
            rendered.width as u32,
            rendered.height as u32,
            rendered.rgba,
        ) {
            img_buf.save(&png_path).expect("Không thể lưu ảnh kiểm thử");
        }
    }

    let report = format!(
        "SELF_TEST_OK\nFile: {}\nSizeMB: {:.2}\nPages: {}\nColorSpace: {}\nMonitorICC: {}\nLoadDllMs: {:.2}\nOpenDocMs: {:.2}\nRenderPage{}Ms ({}x{}): {:.2}\n",
        pdf_path.display(),
        doc.file_size_bytes as f64 / (1024.0 * 1024.0),
        doc.page_dimensions.len(),
        doc.color_meta.summary_badge(),
        monitor.profile_name,
        lib_ms,
        open_ms,
        idx + 1,
        rendered.width,
        rendered.height,
        render_ms
    );
    let _ = std::fs::write(r"d:\des\lumepdf\dist\self_test_report.txt", &report);
    println!("{report}");
}

fn export_app_icon_ico(out_path: &str) {
    let p = Path::new(out_path);
    save_multi_res_ico(p).expect("Không thể xuất file .ico đa độ phân giải");

    // Xuất thêm bản PNG 256x256 để kiểm tra trực quan
    let png_path = p.with_extension("png");
    let rgba = render_vector_pdf_icon(256);
    if let Some(img) = image::RgbaImage::from_raw(256, 256, rgba) {
        let _ = img.save(png_path);
    }
}

fn build_window_icon(size: u32) -> egui::IconData {
    egui::IconData {
        rgba: render_vector_pdf_icon(size),
        width: size,
        height: size,
    }
}
