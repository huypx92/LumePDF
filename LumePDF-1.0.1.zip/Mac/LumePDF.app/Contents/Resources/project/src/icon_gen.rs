use image::codecs::ico::{IcoEncoder, IcoFrame};
use image::ExtendedColorType;
use std::fs::File;
use std::io::BufWriter;
use std::path::Path;

/// Xuất file .ico đa độ phân giải (16, 24, 32, 48, 64, 128, 256px) chuẩn Windows Explorer
/// để hiển thị sắc nét cả ở ngoài Desktop, Taskbar lẫn góc dưới bên phải Thumbnail (TypeOverlay)
pub fn save_multi_res_ico(path: &Path) -> Result<(), String> {
    let sizes = [16u32, 24, 32, 48, 64, 128, 256];
    let mut frames = Vec::with_capacity(sizes.len());

    for &sz in &sizes {
        let rgba = render_vector_pdf_icon(sz);
        let frame = IcoFrame::as_png(&rgba, sz, sz, ExtendedColorType::Rgba8)
            .map_err(|e| format!("Lỗi tạo frame ICO {sz}x{sz}: {e}"))?;
        frames.push(frame);
    }

    let file = File::create(path).map_err(|e| format!("Không thể tạo file ICO: {e}"))?;
    let writer = BufWriter::new(file);
    let encoder = IcoEncoder::new(writer);
    encoder
        .encode_images(&frames)
        .map_err(|e| format!("Không thể ghi dữ liệu ICO: {e}"))?;

    Ok(())
}

/// Kết xuất biểu tượng Vector SDF "PDF Cực Xanh" với khử răng cưa 4x4 Supersampling (SSAA)
/// Thiết kế lấy cảm hứng từ huy hiệu góc thumbnail của Foxit nhưng mang sắc Xanh Ngọc Lục Bảo (Emerald)
/// hiện đại, nổi bật và cực kỳ dễ nhận diện trong Windows Explorer.
pub fn render_vector_pdf_icon(size: u32) -> Vec<u8> {
    let mut out = vec![0u8; (size * size * 4) as usize];
    let s = size as f32;
    let ssaa = if size <= 64 { 4 } else { 2 };
    let inv_ssaa = 1.0 / (ssaa as f32);
    let total_samples = (ssaa * ssaa) as f32;

    for py in 0..size {
        for px in 0..size {
            let mut sum_r = 0.0f32;
            let mut sum_g = 0.0f32;
            let mut sum_b = 0.0f32;
            let mut sum_a = 0.0f32;

            for sy in 0..ssaa {
                for sx in 0..ssaa {
                    let u = (px as f32 + (sx as f32 + 0.5) * inv_ssaa) / s;
                    let v = (py as f32 + (sy as f32 + 0.5) * inv_ssaa) / s;
                    let (r, g, b, a) = sample_vector_icon(u, v);
                    sum_r += r * a;
                    sum_g += g * a;
                    sum_b += b * a;
                    sum_a += a;
                }
            }

            let idx = ((py * size + px) * 4) as usize;
            let avg_a = (sum_a / total_samples).clamp(0.0, 1.0);
            if avg_a > 1e-4 {
                out[idx] = ((sum_r / sum_a) * 255.0).round().clamp(0.0, 255.0) as u8;
                out[idx + 1] = ((sum_g / sum_a) * 255.0).round().clamp(0.0, 255.0) as u8;
                out[idx + 2] = ((sum_b / sum_a) * 255.0).round().clamp(0.0, 255.0) as u8;
                out[idx + 3] = (avg_a * 255.0).round().clamp(0.0, 255.0) as u8;
            }
        }
    }

    out
}

/// Hàm toán học Vector (Signed Distance Field) vẽ biểu tượng tài liệu PDF chuẩn vector ở tọa độ chuẩn hóa (u, v) in [0, 1]
fn sample_vector_icon(u: f32, v: f32) -> (f32, f32, f32, f32) {
    // 1. Hình dáng tờ tài liệu có góc gấp (giống phom dáng huy hiệu Foxit PDF nhưng sắc nét hơn)
    // Khung tài liệu: x từ 0.11 đến 0.89, y từ 0.05 đến 0.95
    let left = 0.11;
    let right = 0.89;
    let top = 0.05;
    let bottom = 0.95;
    let fold_size = 0.25; // Góc gấp phía trên bên phải

    let radius = 0.065;
    let dx = (u - 0.5).abs() - ((right - left) * 0.5 - radius);
    let dy = (v - 0.5).abs() - ((bottom - top) * 0.5 - radius);
    let rounded_box_dist =
        (dx.max(0.0).powi(2) + dy.max(0.0).powi(2)).sqrt() + dx.max(dy).min(0.0) - radius;

    // Đường cắt chéo góc trên bên phải: (u - (right - fold_size)) + (top + fold_size - v) > fold_size
    let fold_cut = (u - (right - fold_size)) - (v - top);
    let doc_dist = rounded_box_dist.max(fold_cut);

    if doc_dist > 0.0 {
        // Bóng đổ nhẹ bên ngoài viền tài liệu
        let shadow_dx = (u - 0.5).abs() - ((right - left) * 0.5 - radius);
        let shadow_dy = ((v - 0.02) - 0.5).abs() - ((bottom - top) * 0.5 - radius);
        let shadow_dist = (shadow_dx.max(0.0).powi(2) + shadow_dy.max(0.0).powi(2)).sqrt()
            + shadow_dx.max(shadow_dy).min(0.0)
            - radius;
        let shadow_cut = (u - (right - fold_size)) - ((v - 0.02) - top);
        let s_d = shadow_dist.max(shadow_cut);
        if s_d < 0.035 {
            let sa = ((0.035 - s_d) / 0.035).clamp(0.0, 1.0) * 0.28;
            return (0.0, 0.0, 0.0, sa);
        }
        return (0.0, 0.0, 0.0, 0.0);
    }

    // Gradient nền Xanh Ngọc Lục Bảo ("Cực xanh" - Emerald #00D66C -> #059669 -> #047857)
    let grad_t = ((v - top) / (bottom - top)).clamp(0.0, 1.0);
    let mut r = lerp(0.04, 0.01, grad_t);
    let mut g = lerp(0.84, 0.53, grad_t);
    let mut b = lerp(0.45, 0.35, grad_t);

    // Ánh sáng chéo tinh tế ở nửa trên bên trái
    let highlight = (1.0 - ((u - 0.25).powi(2) + (v - 0.20).powi(2)).sqrt() * 1.4).clamp(0.0, 1.0);
    r += highlight * 0.08;
    g += highlight * 0.10;
    b += highlight * 0.08;

    // 2. Bóng đổ dưới nếp gấp góc trên bên phải
    let in_fold_region = u >= (right - fold_size) && v <= (top + fold_size);
    if !in_fold_region {
        // Bóng tam giác nhỏ ngay dưới mép gấp
        if u >= (right - fold_size * 0.95)
            && v >= (top + fold_size)
            && v <= (top + fold_size + 0.07)
        {
            let shadow_t = 1.0 - ((v - (top + fold_size)) / 0.07).clamp(0.0, 1.0);
            let darkness = shadow_t * 0.25;
            r *= 1.0 - darkness;
            g *= 1.0 - darkness;
            b *= 1.0 - darkness;
        }
    } else {
        // Phần tam giác lật của góc gấp (màu trắng xanh bạc Hà nổi bật)
        r = lerp(0.84, 0.96, (u - (right - fold_size)) / fold_size);
        g = lerp(0.98, 1.00, (u - (right - fold_size)) / fold_size);
        b = lerp(0.91, 0.98, (u - (right - fold_size)) / fold_size);
    }

    // 3. Biểu tượng vòng xoáy Vector (Tốc độ + Chuẩn màu) ở tâm (tương tự vòng chữ C/G của Foxit)
    let cx = 0.48;
    let cy = 0.41;
    let dx_c = u - cx;
    let dy_c = v - cy;
    let rad = (dx_c * dx_c + dy_c * dy_c).sqrt();
    let angle = dy_c.atan2(dx_c); // [-PI, PI]

    // Vòng cung trắng chính (bán kính ngoài 0.215, bán kính trong 0.115) có khe mở năng động bên phải
    let is_gap = angle > -0.42 && angle < 0.32 && dx_c > 0.0;
    if rad <= 0.215 && rad >= 0.118 && !is_gap {
        r = 1.0;
        g = 1.0;
        b = 1.0;
    }

    // Cánh hướng tâm (tạo hình chữ G/L cách điệu hiện đại ở giữa vòng tròn)
    if v >= (cy - 0.032) && v <= (cy + 0.038) && u >= (cx - 0.01) && u <= (cx + 0.205) {
        r = 1.0;
        g = 1.0;
        b = 1.0;
    }

    // Chấm спектра chuẩn màu ở tâm vòng tròn (Điểm nhấn thiết kế)
    if rad <= 0.052 {
        r = 1.0;
        g = 0.98;
        b = 0.95;
    }

    // 4. Chữ "PDF" Vector siêu sắc nét ở phần đáy (y từ 0.69 đến 0.88)
    if draw_bold_pdf_text(u, v) {
        r = 1.0;
        g = 1.0;
        b = 1.0;
    }

    // Viền sáng mảnh giúp icon tách biệt trên mọi nền tối/sáng
    if doc_dist > -0.018 && !in_fold_region {
        r = lerp(r, 0.65, 0.22);
        g = lerp(g, 0.98, 0.22);
        b = lerp(b, 0.80, 0.22);
    }

    (
        r.clamp(0.0, 1.0),
        g.clamp(0.0, 1.0),
        b.clamp(0.0, 1.0),
        1.0,
    )
}

/// Vẽ chữ "PDF" bằng hình học Vector thuần túy để hiển thị rõ nét tuyệt đối ngay cả ở kích thước 16x16 / 24x24
fn draw_bold_pdf_text(u: f32, v: f32) -> bool {
    let y0 = 0.695;
    let y1 = 0.885;
    if v < y0 || v > y1 {
        return false;
    }
    let ny = (v - y0) / (y1 - y0); // [0..1] từ đỉnh chữ xuống chân chữ
    let stroke_x = 0.044;
    let stroke_y = 0.21;

    // --- Chữ 'P' (u từ 0.21 đến 0.39) ---
    if u >= 0.21 && u <= 0.40 {
        let x0 = 0.21;
        // Cột dọc trái của P
        if u <= x0 + stroke_x {
            return true;
        }
        // Bụng trên của P (ny từ 0.0 đến 0.58)
        if ny <= 0.58 {
            let cy = 0.29;
            let rx = 0.095;
            let ry = 0.29;
            let cx = x0 + stroke_x * 0.9;
            if u <= cx {
                if ny <= stroke_y || (0.58 - ny) <= stroke_y {
                    return true;
                }
            } else {
                let dx = (u - cx) / rx;
                let dy = (ny - cy) / ry;
                let d = dx * dx + dy * dy;
                let inner_dx = (u - cx) / (rx - stroke_x).max(0.01);
                let inner_dy = (ny - cy) / (ry - stroke_y).max(0.01);
                let inner_d = inner_dx * inner_dx + inner_dy * inner_dy;
                if d <= 1.0 && inner_d >= 1.0 {
                    return true;
                }
            }
        }
    }

    // --- Chữ 'D' (u từ 0.43 đến 0.62) ---
    if u >= 0.43 && u <= 0.63 {
        let x0 = 0.43;
        if u <= x0 + stroke_x {
            return true;
        }
        let cx = x0 + stroke_x * 0.85;
        let cy = 0.50;
        let rx = 0.105;
        let ry = 0.50;
        if u <= cx {
            if ny <= stroke_y || (1.0 - ny) <= stroke_y {
                return true;
            }
        } else {
            let dx = (u - cx) / rx;
            let dy = (ny - cy) / ry;
            let d = dx * dx + dy * dy;
            let inner_dx = (u - cx) / (rx - stroke_x).max(0.01);
            let inner_dy = (ny - cy) / (ry - stroke_y).max(0.01);
            let inner_d = inner_dx * inner_dx + inner_dy * inner_dy;
            if d <= 1.0 && inner_d >= 1.0 {
                return true;
            }
        }
    }

    // --- Chữ 'F' (u từ 0.66 đến 0.82) ---
    if u >= 0.66 && u <= 0.82 {
        let x0 = 0.66;
        // Cột dọc trái của F
        if u <= x0 + stroke_x {
            return true;
        }
        // Thanh ngang trên cùng của F
        if ny <= stroke_y && u <= 0.815 {
            return true;
        }
        // Thanh ngang giữa của F
        if ny >= 0.42 && ny <= (0.42 + stroke_y * 0.92) && u <= 0.79 {
            return true;
        }
    }

    false
}

#[inline]
fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}
