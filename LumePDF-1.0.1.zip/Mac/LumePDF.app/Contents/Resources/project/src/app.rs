use crate::color_cms::{rgb_to_cmyk_percent, ColorMode, MonitorColorProfile};
use crate::i18n::AppLang;
use crate::icon_gen::render_vector_pdf_icon;
use crate::pdf_engine::{PageDimension, PdfColorMetadata};
use crate::updates::{UpdateCheck, UpdateStatus, CURRENT_VERSION, RELEASES_URL};
use crate::worker::{
    PageCacheKey, RenderTask, RenderWorkerHandle, WorkerCommand, WorkerEvent,
};
use egui::{
    Color32, ColorImage, Context, FontData, FontDefinitions, FontFamily, FontId, Key, Margin,
    Pos2, Rect, RichText, Rounding, ScrollArea, Sense, Stroke, TextureHandle, TextureOptions, Ui,
    Vec2,
};
use lru::LruCache;
use std::collections::{HashMap, HashSet};
use std::num::NonZeroUsize;
use std::path::{Path, PathBuf};
use std::time::Instant;

// Bảng màu Giao diện Sáng (Light Theme) hiện đại, dịu mắt và chuẩn độ tương phản cho Thiết kế
const COLOR_TOP_BAR: Color32 = Color32::from_rgb(248, 250, 252); // #F8FAFC
const COLOR_TAB_BAR: Color32 = Color32::from_rgb(235, 240, 245); // #EBF0F5
const COLOR_SIDEBAR: Color32 = Color32::from_rgb(241, 245, 249); // #F1F5F9
const COLOR_CANVAS: Color32 = Color32::from_rgb(226, 232, 240); // #E2E8F0
const COLOR_ACCENT_GREEN: Color32 = Color32::from_rgb(5, 150, 105); // #059669
const COLOR_ACCENT_LIGHT: Color32 = Color32::from_rgb(209, 250, 229); // #D1FAE5
const COLOR_PILL_BG: Color32 = Color32::from_rgb(255, 255, 255); // #FFFFFF
const COLOR_BORDER: Color32 = Color32::from_rgb(203, 213, 225); // #CBD5E1
const COLOR_TEXT_MAIN: Color32 = Color32::from_rgb(15, 23, 42); // #0F172A
const COLOR_TEXT_DIM: Color32 = Color32::from_rgb(71, 85, 105); // #475569

const PAGE_GAP: f32 = 14.0;
const TOP_PADDING: f32 = 14.0;
const DPI_SCALE: f32 = 96.0 / 72.0;

pub struct CachedPageTexture {
    pub texture: TextureHandle,
    pub width: usize,
    pub height: usize,
    pub raw_rgba: Vec<u8>,
}

#[derive(Debug, Clone)]
pub struct EyedropperSample {
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub c: u8,
    pub m: u8,
    pub y: u8,
    pub k: u8,
}

impl EyedropperSample {
    pub fn hex_string(&self) -> String {
        format!("#{:02X}{:02X}{:02X}", self.r, self.g, self.b)
    }

    pub fn summary_string(&self) -> String {
        format!(
            "{} | RGB({}, {}, {}) | C:{}% M:{}% Y:{}% K:{}%",
            self.hex_string(),
            self.r,
            self.g,
            self.b,
            self.c,
            self.m,
            self.y,
            self.k
        )
    }
}

pub struct DocumentTab {
    pub doc_id: u64,
    pub path: PathBuf,
    pub title: String,
    pub file_size_bytes: u64,
    pub page_dimensions: Vec<PageDimension>,
    pub color_meta: PdfColorMetadata,
    pub open_ms: f64,
    pub is_loading: bool,
    pub error: Option<String>,
    pub zoom: f32,
    pub rotation_steps: i32,
    pub current_page: usize, // 0-indexed
    pub page_input_text: String,
    pub pending_scroll_to_page: Option<usize>,
    pub pending_thumb_scroll_to_page: Option<usize>,
    pub pending_scroll_offset: Option<Vec2>,
    pub last_scroll_offset: Vec2,
    pub last_canvas_size: Vec2,
    pub fit_mode: Option<FitMode>,
    pub last_zoom_instant: Option<Instant>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FitMode {
    FitWidth,
    FitPage,
}

pub struct CoverCardInfo {
    pub path: PathBuf,
    pub title: String,
    pub file_size_bytes: u64,
    pub page_count: Option<usize>,
    pub cover_texture: Option<TextureHandle>,
    pub aspect_ratio: f32,
}

pub struct ToastBanner {
    pub message: String,
    pub is_error: bool,
    pub created_at: Instant,
}

pub struct LumePdfApp {
    worker: RenderWorkerHandle,
    next_doc_id: u64,
    tabs: Vec<DocumentTab>,
    active_tab: usize,
    show_sidebar: bool,
    show_cover_gallery: bool,
    color_mode: ColorMode,
    monitor_profile: MonitorColorProfile,
    engine_error: Option<String>,
    last_render_ms: f64,

    // Huy hiệu Vector "PDF Cực Xanh" & Ngôn ngữ giao diện
    badge_texture: TextureHandle,
    show_about_modal: bool,
    update_check: UpdateCheck,
    show_update_banner: bool,
    lang: AppLang,
    cjk_font_loaded: bool,

    // Danh sách bìa PDF trong thư mục hiện tại / Downloads
    gallery_folder: Option<PathBuf>,
    gallery_cards: Vec<CoverCardInfo>,
    requested_covers: HashSet<PathBuf>,

    // Bộ nhớ đệm Texture GPU (LRU)
    page_cache: LruCache<PageCacheKey, CachedPageTexture>,
    thumb_cache: LruCache<(u64, usize, i32, ColorMode), TextureHandle>,
    // Lưu bản vẽ độ phân giải cao gần nhất của mỗi trang để khi đang Zoom mượt 120FPS không bao giờ giật
    best_page_textures: HashMap<(u64, usize), (u32, TextureHandle)>,

    // Công cụ soi màu chuẩn thiết kế (Eyedropper)
    eyedropper_enabled: bool,
    hovered_color: Option<EyedropperSample>,
    toast: Option<ToastBanner>,

    last_viewport_size: Vec2,
}

impl LumePdfApp {
    pub fn new(cc: &eframe::CreationContext<'_>, initial_files: Vec<PathBuf>) -> Self {
        configure_vietnamese_fonts(&cc.egui_ctx);
        configure_light_visuals(&cc.egui_ctx);

        let worker = RenderWorkerHandle::spawn(cc.egui_ctx.clone());

        let badge_rgba = render_vector_pdf_icon(64);
        let badge_img = ColorImage::from_rgba_unmultiplied([64, 64], &badge_rgba);
        let badge_texture =
            cc.egui_ctx
                .load_texture("lumepdf_vector_badge", badge_img, TextureOptions::LINEAR);

        let mut app = Self {
            worker,
            next_doc_id: 1,
            tabs: Vec::new(),
            active_tab: 0,
            show_sidebar: true,
            show_cover_gallery: false,
            color_mode: ColorMode::StandardSrgb,
            monitor_profile: MonitorColorProfile::default(),
            engine_error: None,
            last_render_ms: 0.0,
            badge_texture,
            show_about_modal: false,
            update_check: UpdateCheck::default(),
            show_update_banner: false,
            lang: AppLang::Vi,
            cjk_font_loaded: false,
            gallery_folder: None,
            gallery_cards: Vec::new(),
            requested_covers: HashSet::new(),
            page_cache: LruCache::new(NonZeroUsize::new(28).unwrap()),
            thumb_cache: LruCache::new(NonZeroUsize::new(160).unwrap()),
            best_page_textures: HashMap::new(),
            eyedropper_enabled: false,
            hovered_color: None,
            toast: None,
            last_viewport_size: Vec2::new(1000.0, 800.0),
        };

        if let Some(downloads) = default_pdf_folder() {
            app.gallery_folder = Some(downloads);
        }

        for path in initial_files {
            if let Some(parent) = path.parent() {
                app.gallery_folder = Some(parent.to_path_buf());
            }
            app.open_file(path);
        }

        app.update_check.start(&cc.egui_ctx);
        app
    }

    pub fn scan_folder_for_covers(&mut self, folder: &Path) {
        if !folder.is_dir() {
            return;
        }
        self.gallery_folder = Some(folder.to_path_buf());
        self.gallery_cards.clear();

        if let Ok(entries) = std::fs::read_dir(folder) {
            let mut pdf_paths: Vec<(PathBuf, u64, std::time::SystemTime)> = entries
                .filter_map(|e| e.ok())
                .filter_map(|e| {
                    let path = e.path();
                    let is_pdf = path
                        .extension()
                        .and_then(|ext| ext.to_str())
                        .map(|s| s.eq_ignore_ascii_case("pdf"))
                        .unwrap_or(false);
                    if !is_pdf {
                        return None;
                    }
                    let meta = e.metadata().ok()?;
                    let mtime = meta.modified().unwrap_or(std::time::UNIX_EPOCH);
                    Some((path, meta.len(), mtime))
                })
                .collect();

            pdf_paths.sort_by(|a, b| b.2.cmp(&a.2));
            pdf_paths.truncate(24);

            for (path, size, _) in pdf_paths {
                let title = path
                    .file_stem()
                    .and_then(|s| s.to_str())
                    .unwrap_or("Tài liệu")
                    .to_string();
                self.gallery_cards.push(CoverCardInfo {
                    path,
                    title,
                    file_size_bytes: size,
                    page_count: None,
                    cover_texture: None,
                    aspect_ratio: 1.0 / 1.4142,
                });
            }
        }
    }

    pub fn open_file(&mut self, path: PathBuf) {
        self.show_cover_gallery = false;
        if let Some(idx) = self.tabs.iter().position(|t| t.path == path) {
            self.active_tab = idx;
            return;
        }

        let doc_id = self.next_doc_id;
        self.next_doc_id += 1;

        let title = path
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("Tài liệu.pdf")
            .to_string();

        let tab = DocumentTab {
            doc_id,
            path: path.clone(),
            title,
            file_size_bytes: 0,
            page_dimensions: Vec::new(),
            color_meta: PdfColorMetadata::default(),
            open_ms: 0.0,
            is_loading: true,
            error: None,
            zoom: 1.0,
            rotation_steps: 0,
            current_page: 0,
            page_input_text: "1".to_string(),
            pending_scroll_to_page: None,
            pending_thumb_scroll_to_page: None,
            pending_scroll_offset: None,
            last_scroll_offset: Vec2::ZERO,
            last_canvas_size: Vec2::new(1000.0, 1000.0),
            fit_mode: None,
            last_zoom_instant: None,
        };

        self.tabs.push(tab);
        self.active_tab = self.tabs.len() - 1;
        let _ = self
            .worker
            .cmd_tx
            .send(WorkerCommand::OpenDocument { doc_id, path });
    }

    fn close_tab(&mut self, index: usize) {
        if index >= self.tabs.len() {
            return;
        }
        let removed = self.tabs.remove(index);
        let _ = self.worker.cmd_tx.send(WorkerCommand::CloseDocument {
            doc_id: removed.doc_id,
        });
        self.best_page_textures
            .retain(|(d, _), _| *d != removed.doc_id);

        if self.tabs.is_empty() {
            self.active_tab = 0;
        } else if self.active_tab >= self.tabs.len() {
            self.active_tab = self.tabs.len() - 1;
        }
    }

    fn trigger_open_file_dialog(&mut self) {
        if let Some(files) = rfd::FileDialog::new()
            .set_title("Chọn file PDF để mở nhanh")
            .add_filter("Tài liệu PDF (*.pdf)", &["pdf", "PDF"])
            .pick_files()
        {
            for file in files {
                if let Some(parent) = file.parent() {
                    self.gallery_folder = Some(parent.to_path_buf());
                }
                self.open_file(file);
            }
        }
    }

    fn trigger_export_page_dialog(
        &mut self,
        doc_id: u64,
        doc_title: &str,
        page_index: usize,
        rotation_steps: i32,
        default_ext: &str,
    ) {
        let stem = Path::new(doc_title)
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("TaiLieu");
        let default_name = format!("{}_Trang_{}.{}", stem, page_index + 1, default_ext);

        let dialog = if default_ext.eq_ignore_ascii_case("png") {
            rfd::FileDialog::new()
                .set_title(format!("Xuất Trang {} ra file ảnh PNG", page_index + 1))
                .set_file_name(&default_name)
                .add_filter("Ảnh PNG (*.png)", &["png"])
                .add_filter("Ảnh JPEG (*.jpg)", &["jpg", "jpeg"])
        } else {
            rfd::FileDialog::new()
                .set_title(format!("Xuất Trang {} ra file ảnh JPG", page_index + 1))
                .set_file_name(&default_name)
                .add_filter("Ảnh JPEG (*.jpg)", &["jpg", "jpeg"])
                .add_filter("Ảnh PNG (*.png)", &["png"])
        };

        if let Some(dest_path) = dialog.save_file() {
            self.toast = Some(ToastBanner {
                message: format!("⏳ Đang kết xuất Trang {} chất lượng cao...", page_index + 1),
                is_error: false,
                created_at: Instant::now(),
            });
            let _ = self.worker.cmd_tx.send(WorkerCommand::ExportPageToImage {
                doc_id,
                page_index,
                rotation_steps,
                color_mode: self.color_mode,
                dest_path,
            });
        }
    }

    fn poll_worker_events(&mut self, ctx: &Context) {
        let mut textures_uploaded = 0usize;
        while textures_uploaded < 4 {
            let Ok(evt) = self.worker.evt_rx.try_recv() else {
                break;
            };
            match evt {
                WorkerEvent::EngineReady { monitor_profile } => {
                    self.monitor_profile = monitor_profile;
                }
                WorkerEvent::EngineError(err) => {
                    self.engine_error = Some(err);
                }
                WorkerEvent::DocumentOpened {
                    doc_id,
                    file_size_bytes,
                    page_dimensions,
                    color_meta,
                    open_ms,
                } => {
                    let vp = self.last_viewport_size;
                    if let Some(tab) = self.tabs.iter_mut().find(|t| t.doc_id == doc_id) {
                        tab.is_loading = false;
                        tab.file_size_bytes = file_size_bytes;
                        let is_single_page = page_dimensions.len() == 1;
                        if let Some(first_dim) = page_dimensions.first() {
                            let (pt_w, pt_h) = first_dim.rotated_size(tab.rotation_steps);
                            let base_w = pt_w * DPI_SCALE;
                            let base_h = pt_h * DPI_SCALE;
                            let max_w = (vp.x - 56.0).max(400.0);
                            let max_h = (vp.y - 44.0).max(400.0);
                            if is_single_page {
                                tab.fit_mode = Some(FitMode::FitPage);
                                let zw = max_w / base_w.max(1.0);
                                let zh = max_h / base_h.max(1.0);
                                tab.zoom = zw.min(zh).clamp(0.05, 8.0);
                            } else if base_w > max_w || base_h > max_h * 1.15 {
                                let zw = max_w / base_w.max(1.0);
                                let zh = max_h / base_h.max(1.0);
                                tab.zoom = zw.min(zh).clamp(0.05, 8.0);
                            }
                        }
                        tab.page_dimensions = page_dimensions;
                        tab.color_meta = color_meta;
                        tab.open_ms = open_ms;
                        tab.current_page = 0;
                        tab.page_input_text = "1".to_string();
                    }
                }
                WorkerEvent::DocumentOpenFailed { doc_id, error } => {
                    if let Some(tab) = self.tabs.iter_mut().find(|t| t.doc_id == doc_id) {
                        tab.is_loading = false;
                        tab.error = Some(error);
                    }
                }
                WorkerEvent::PageRendered {
                    key,
                    bitmap,
                    render_ms,
                } => {
                    textures_uploaded += 1;
                    self.last_render_ms = render_ms;
                    let image = ColorImage::from_rgba_unmultiplied(
                        [bitmap.width, bitmap.height],
                        &bitmap.rgba,
                    );
                    let tex_name = format!(
                        "pdf_d{}_p{}_{}x{}_t{}",
                        key.doc_id,
                        key.page_index,
                        key.width_px,
                        key.height_px,
                        key.is_thumbnail as u8
                    );

                    let texture = ctx.load_texture(tex_name, image, TextureOptions::LINEAR);

                    if key.is_thumbnail {
                        self.thumb_cache.put(
                            (key.doc_id, key.page_index, key.rotation_steps, key.color_mode),
                            texture.clone(),
                        );
                        self.best_page_textures
                            .entry((key.doc_id, key.page_index))
                            .or_insert((key.width_px, texture));
                    } else {
                        self.thumb_cache.put(
                            (key.doc_id, key.page_index, key.rotation_steps, key.color_mode),
                            texture.clone(),
                        );
                        self.best_page_textures
                            .insert((key.doc_id, key.page_index), (key.width_px, texture.clone()));
                        self.page_cache.put(
                            key,
                            CachedPageTexture {
                                texture,
                                width: bitmap.width,
                                height: bitmap.height,
                                raw_rgba: bitmap.rgba,
                            },
                        );
                    }
                }
                WorkerEvent::CoverPreviewRendered {
                    path,
                    bitmap,
                    page_count,
                    file_size_bytes,
                } => {
                    textures_uploaded += 1;
                    let image = ColorImage::from_rgba_unmultiplied(
                        [bitmap.width, bitmap.height],
                        &bitmap.rgba,
                    );
                    let tex_name = format!("cover_{}", path.display());
                    let texture = ctx.load_texture(tex_name, image, TextureOptions::LINEAR);
                    let aspect =
                        (bitmap.width as f32 / (bitmap.height.max(1) as f32)).clamp(0.4, 2.2);
                    if let Some(card) = self.gallery_cards.iter_mut().find(|c| c.path == path) {
                        card.cover_texture = Some(texture);
                        card.page_count = Some(page_count);
                        card.file_size_bytes = file_size_bytes;
                        card.aspect_ratio = aspect;
                    }
                }
                WorkerEvent::ActionToast { message, is_error } => {
                    self.toast = Some(ToastBanner {
                        message,
                        is_error,
                        created_at: Instant::now(),
                    });
                }
            }
        }
        if !self.worker.evt_rx.is_empty() {
            ctx.request_repaint();
        }
    }

    fn handle_shortcuts(&mut self, ctx: &Context) {
        let dropped: Vec<PathBuf> = ctx.input(|i| {
            i.raw
                .dropped_files
                .iter()
                .filter_map(|f| f.path.clone())
                .collect()
        });
        for path in dropped {
            self.open_file(path);
        }

        let mut open_dialog = false;
        let mut close_active = false;
        let mut toggle_sidebar = false;

        ctx.input(|i| {
            if i.modifiers.ctrl && i.key_pressed(Key::O) {
                open_dialog = true;
            }
            if i.modifiers.ctrl && i.key_pressed(Key::W) {
                close_active = true;
            }
            if i.modifiers.ctrl && i.key_pressed(Key::B) {
                toggle_sidebar = true;
            }
        });

        if open_dialog {
            self.trigger_open_file_dialog();
        }
        if close_active && !self.tabs.is_empty() {
            let idx = self.active_tab;
            self.close_tab(idx);
        }
        if toggle_sidebar {
            self.show_sidebar = !self.show_sidebar;
        }

        let view_size = self.last_viewport_size;
        if let Some(tab) = self.tabs.get_mut(self.active_tab) {
            if tab.page_dimensions.is_empty() {
                return;
            }
            let page_count = tab.page_dimensions.len();
            let wants_kb = ctx.wants_keyboard_input();

            ctx.input(|i| {
                if i.modifiers.ctrl && (i.key_pressed(Key::Plus) || i.key_pressed(Key::Equals)) {
                    apply_center_zoom(tab, (tab.zoom * 1.15).clamp(0.05, 8.0), view_size);
                }
                if i.modifiers.ctrl && i.key_pressed(Key::Minus) {
                    apply_center_zoom(tab, (tab.zoom / 1.15).clamp(0.05, 8.0), view_size);
                }
                if i.modifiers.ctrl && i.key_pressed(Key::Num0) {
                    apply_center_zoom(tab, 1.0, view_size);
                }
                if i.modifiers.ctrl && i.key_pressed(Key::R) {
                    tab.rotation_steps = (tab.rotation_steps + 1).rem_euclid(4);
                }

                if !wants_kb {
                    if i.key_pressed(Key::PageDown) || i.key_pressed(Key::ArrowRight) {
                        let next = (tab.current_page + 1).min(page_count.saturating_sub(1));
                        tab.current_page = next;
                        tab.page_input_text = (next + 1).to_string();
                        tab.pending_scroll_to_page = Some(next);
                        tab.pending_thumb_scroll_to_page = Some(next);
                    }
                    if i.key_pressed(Key::PageUp) || i.key_pressed(Key::ArrowLeft) {
                        let prev = tab.current_page.saturating_sub(1);
                        tab.current_page = prev;
                        tab.page_input_text = (prev + 1).to_string();
                        tab.pending_scroll_to_page = Some(prev);
                        tab.pending_thumb_scroll_to_page = Some(prev);
                    }
                    if i.key_pressed(Key::Home) {
                        tab.current_page = 0;
                        tab.page_input_text = "1".to_string();
                        tab.pending_scroll_to_page = Some(0);
                        tab.pending_thumb_scroll_to_page = Some(0);
                    }
                    if i.key_pressed(Key::End) {
                        let last = page_count.saturating_sub(1);
                        tab.current_page = last;
                        tab.page_input_text = (last + 1).to_string();
                        tab.pending_scroll_to_page = Some(last);
                        tab.pending_thumb_scroll_to_page = Some(last);
                    }
                }
            });
        }
    }

    fn render_tab_strip(&mut self, ctx: &Context) {
        if self.tabs.len() <= 1 {
            return;
        }
        egui::TopBottomPanel::top("chrome_tab_strip")
            .exact_height(34.0)
            .frame(egui::Frame::none().fill(COLOR_TAB_BAR).inner_margin(Margin {
                left: 8.0,
                right: 8.0,
                top: 4.0,
                bottom: 0.0,
            }))
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.spacing_mut().item_spacing.x = 4.0;
                    let mut close_idx = None;
                    let mut select_idx = None;

                    for (idx, tab) in self.tabs.iter().enumerate() {
                        let is_active = idx == self.active_tab;
                        let bg = if is_active {
                            COLOR_TOP_BAR
                        } else {
                            Color32::from_rgb(222, 228, 236)
                        };
                        let fg = if is_active {
                            COLOR_TEXT_MAIN
                        } else {
                            COLOR_TEXT_DIM
                        };

                        egui::Frame::none()
                            .fill(bg)
                            .rounding(Rounding {
                                nw: 6.0,
                                ne: 6.0,
                                sw: 0.0,
                                se: 0.0,
                            })
                            .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                            .inner_margin(Margin::symmetric(10.0, 4.0))
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    let short_title = truncate_str(&tab.title, 30);
                                    let resp = ui.add(
                                        egui::Label::new(
                                            RichText::new(short_title).size(12.5).color(fg),
                                        )
                                        .sense(Sense::click()),
                                    );
                                    if resp.clicked() {
                                        select_idx = Some(idx);
                                    }
                                    resp.on_hover_text(tab.path.display().to_string());

                                    let close_btn = ui.add(
                                        egui::Button::new(
                                            RichText::new("×").size(14.0).color(COLOR_TEXT_DIM),
                                        )
                                        .frame(false),
                                    );
                                    if close_btn.clicked() {
                                        close_idx = Some(idx);
                                    }
                                });
                            });
                    }

                    // Nút + mở thêm tab mới (vẽ bằng Vector chuẩn không bao giờ lỗi font)
                    if draw_vector_icon_button(ui, VectorBtnIcon::Plus, "Mở thêm file PDF (Ctrl+O)")
                        .clicked()
                    {
                        self.trigger_open_file_dialog();
                    }

                    if let Some(i) = select_idx {
                        self.active_tab = i;
                        self.show_cover_gallery = false;
                    }
                    if let Some(i) = close_idx {
                        self.close_tab(i);
                    }
                });
            });
    }

    fn render_chrome_toolbar(&mut self, ctx: &Context) {
        let view_size = self.last_viewport_size;
        egui::TopBottomPanel::top("chrome_pdf_toolbar")
            .exact_height(48.0)
            .frame(
                egui::Frame::none()
                    .fill(COLOR_TOP_BAR)
                    .inner_margin(Margin::symmetric(14.0, 6.0))
                    .stroke(Stroke::new(1.0_f32, COLOR_BORDER)),
            )
            .show(ctx, |ui| {
                let tr = self.lang.tr();
                let avail_w = ui.available_width();
                ui.horizontal_centered(|ui| {
                    // ================= CỤM TRÁI: Nút ☰ Sidebar + Mở file + Thư viện Bìa + Tên file =================
                    let sidebar_btn = ui.add_sized(
                        [32.0, 32.0],
                        egui::Button::new(
                            RichText::new("☰")
                                .size(16.0)
                                .color(if self.show_sidebar {
                                    COLOR_ACCENT_GREEN
                                } else {
                                    COLOR_TEXT_MAIN
                                }),
                        )
                        .fill(if self.show_sidebar {
                            COLOR_ACCENT_LIGHT
                        } else {
                            Color32::WHITE
                        })
                        .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                        .rounding(Rounding::same(8.0)),
                    );
                    if sidebar_btn
                        .on_hover_text(tr.sidebar_tooltip)
                        .clicked()
                    {
                        self.show_sidebar = !self.show_sidebar;
                    }

                    ui.add_space(4.0);

                    let open_btn = ui.add_sized(
                        [82.0, 30.0],
                        egui::Button::new(
                            RichText::new(tr.open_pdf)
                                .size(12.5)
                                .strong()
                                .color(COLOR_TEXT_MAIN),
                        )
                        .fill(Color32::WHITE)
                        .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                        .rounding(Rounding::same(6.0)),
                    );
                    if open_btn
                        .on_hover_text(tr.open_pdf_tooltip)
                        .clicked()
                    {
                        self.trigger_open_file_dialog();
                    }

                    let gallery_btn = ui.add_sized(
                        [84.0, 30.0],
                        egui::Button::new(
                            RichText::new(tr.view_covers)
                                .size(12.5)
                                .strong()
                                .color(if self.show_cover_gallery {
                                    COLOR_ACCENT_GREEN
                                } else {
                                    COLOR_TEXT_MAIN
                                }),
                        )
                        .fill(if self.show_cover_gallery {
                            COLOR_ACCENT_LIGHT
                        } else {
                            Color32::WHITE
                        })
                        .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                        .rounding(Rounding::same(6.0)),
                    );
                    if gallery_btn
                        .on_hover_text(tr.view_covers_tooltip)
                        .clicked()
                    {
                        self.show_cover_gallery = !self.show_cover_gallery;
                        if self.show_cover_gallery && self.gallery_cards.is_empty() {
                            if let Some(folder) =
                                self.gallery_folder.clone().or_else(default_pdf_folder)
                            {
                                self.scan_folder_for_covers(&folder);
                            }
                        }
                    }

                    if let Some(tab) = self.tabs.get(self.active_tab) {
                        ui.add_space(8.0);
                        let max_title_chars = if avail_w > 1250.0 {
                            36
                        } else if avail_w > 980.0 {
                            20
                        } else {
                            12
                        };
                        let display_title = truncate_str(&tab.title, max_title_chars);
                        ui.label(
                            RichText::new(display_title)
                                .size(14.0)
                                .strong()
                                .color(COLOR_TEXT_MAIN),
                        )
                        .on_hover_text(format!(
                            "Đường dẫn: {}\nDung lượng: {:.1} MB\nThời gian mở: {:.1} ms",
                            tab.path.display(),
                            tab.file_size_bytes as f64 / (1024.0 * 1024.0),
                            tab.open_ms
                        ));

                        if !tab.page_dimensions.is_empty() {
                            let badge = tab.color_meta.summary_badge();
                            egui::Frame::none()
                                .fill(COLOR_ACCENT_LIGHT)
                                .rounding(Rounding::same(4.0))
                                .stroke(Stroke::new(1.0_f32, COLOR_ACCENT_GREEN))
                                .inner_margin(Margin::symmetric(6.0, 2.0))
                                .show(ui, |ui| {
                                    ui.label(
                                        RichText::new(&badge)
                                            .size(11.0)
                                            .strong()
                                            .color(COLOR_ACCENT_GREEN),
                                    )
                                    .on_hover_text(
                                        "Không gian màu gốc được phát hiện bên trong file PDF thiết kế",
                                    );
                                });
                        }
                    }

                    // ================= CỤM GIỮA: Số trang | Thu phóng (Nút Vector - / +) | Vừa khung | Xoay =================
                    if let Some(tab) = self.tabs.get_mut(self.active_tab) {
                        if !tab.page_dimensions.is_empty() {
                            let page_count = tab.page_dimensions.len();
                            ui.add_space((avail_w * 0.03).clamp(6.0, 32.0));

                            // Ô nhập số trang: [ 7 ] / 805
                            egui::Frame::none()
                                .fill(COLOR_PILL_BG)
                                .rounding(Rounding::same(5.0))
                                .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                                .inner_margin(Margin::symmetric(6.0, 3.0))
                                .show(ui, |ui| {
                                    let edit = ui.add_sized(
                                        [44.0, 20.0],
                                        egui::TextEdit::singleline(&mut tab.page_input_text)
                                            .horizontal_align(egui::Align::Center)
                                            .font(FontId::proportional(13.0))
                                            .text_color(COLOR_TEXT_MAIN)
                                            .frame(false),
                                    );
                                    if edit.lost_focus()
                                        && ui.input(|i| i.key_pressed(Key::Enter))
                                    {
                                        if let Ok(num) = tab.page_input_text.trim().parse::<usize>()
                                        {
                                            let target =
                                                num.saturating_sub(1).min(page_count - 1);
                                            tab.current_page = target;
                                            tab.page_input_text = (target + 1).to_string();
                                            tab.pending_scroll_to_page = Some(target);
                                            tab.pending_thumb_scroll_to_page = Some(target);
                                        } else {
                                            tab.page_input_text =
                                                (tab.current_page + 1).to_string();
                                        }
                                    }
                                });

                            ui.label(
                                RichText::new(format!("/ {page_count}"))
                                    .size(13.0)
                                    .strong()
                                    .color(COLOR_TEXT_DIM),
                            );

                            ui.add_space(6.0);
                            draw_toolbar_divider(ui);
                            ui.add_space(6.0);

                            // Nút thu nhỏ [-] (Vẽ bằng Vector sắc nét tuyệt đối)
                            if draw_vector_icon_button(
                                ui,
                                VectorBtnIcon::Minus,
                                tr.zoom_out_tooltip,
                            )
                            .clicked()
                            {
                                apply_center_zoom(
                                    tab,
                                    (tab.zoom / 1.15).clamp(0.05, 8.0),
                                    view_size,
                                );
                            }

                            // Hiển thị % Zoom
                            let zoom_pct = (tab.zoom * 100.0).round() as i32;
                            egui::Frame::none()
                                .fill(COLOR_PILL_BG)
                                .rounding(Rounding::same(5.0))
                                .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                                .inner_margin(Margin::symmetric(8.0, 4.0))
                                .show(ui, |ui| {
                                    let lbl = ui.add(
                                        egui::Label::new(
                                            RichText::new(format!("{zoom_pct}%"))
                                                .size(13.0)
                                                .strong()
                                                .color(COLOR_TEXT_MAIN),
                                        )
                                        .sense(Sense::click()),
                                    );
                                    if lbl
                                        .on_hover_text(tr.reset_zoom_tooltip)
                                        .clicked()
                                    {
                                        apply_center_zoom(tab, 1.0, view_size);
                                    }
                                });

                            // Nút phóng to [+] (Vẽ bằng Vector sắc nét tuyệt đối, không bao giờ lỗi ô vuông)
                            if draw_vector_icon_button(
                                ui,
                                VectorBtnIcon::Plus,
                                tr.zoom_in_tooltip,
                            )
                            .clicked()
                            {
                                apply_center_zoom(
                                    tab,
                                    (tab.zoom * 1.15).clamp(0.05, 8.0),
                                    view_size,
                                );
                            }

                            ui.add_space(6.0);
                            draw_toolbar_divider(ui);
                            ui.add_space(6.0);

                            // Nút Vừa trang / Vừa chiều ngang
                            let fit_label = match tab.fit_mode {
                                Some(FitMode::FitPage) => tr.fit_page,
                                Some(FitMode::FitWidth) => tr.fit_width,
                                None => tr.fit_frame,
                            };
                            let fit_btn = ui.add_sized(
                                [94.0, 28.0],
                                egui::Button::new(
                                    RichText::new(fit_label)
                                        .size(12.0)
                                        .strong()
                                        .color(if tab.fit_mode.is_some() {
                                            COLOR_ACCENT_GREEN
                                        } else {
                                            COLOR_TEXT_MAIN
                                        }),
                                )
                                .fill(if tab.fit_mode.is_some() {
                                    COLOR_ACCENT_LIGHT
                                } else {
                                    Color32::WHITE
                                })
                                .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                                .rounding(Rounding::same(6.0)),
                            );
                            if fit_btn
                                .on_hover_text(tr.fit_tooltip)
                                .clicked()
                            {
                                tab.fit_mode = match tab.fit_mode {
                                    None | Some(FitMode::FitPage) => Some(FitMode::FitWidth),
                                    Some(FitMode::FitWidth) => Some(FitMode::FitPage),
                                };
                            }

                            // Nút Xoay 90 độ
                            if ui
                                .add_sized(
                                    [68.0, 28.0],
                                    egui::Button::new(
                                        RichText::new(tr.rotate)
                                            .size(12.0)
                                            .strong()
                                            .color(COLOR_TEXT_MAIN),
                                    )
                                    .fill(Color32::WHITE)
                                    .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                                    .rounding(Rounding::same(6.0)),
                                )
                                .on_hover_text(tr.rotate_tooltip)
                                .clicked()
                            {
                                tab.rotation_steps = (tab.rotation_steps + 1).rem_euclid(4);
                            }
                        }
                    }

                    // ================= CỤM PHẢI: Nút Thông tin Tác giả (Icon nhỏ) + Ngôn ngữ + Quản lý Hệ màu + Soi màu =================
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if draw_vector_icon_button(
                            ui,
                            VectorBtnIcon::Info,
                            tr.info_tooltip,
                        )
                        .clicked()
                        {
                            self.show_about_modal = !self.show_about_modal;
                        }

                        ui.add_space(4.0);

                        // Bộ chọn Đổi ngôn ngữ các thứ tiếng cơ bản
                        let prev_lang = self.lang;
                        let lang_combo = egui::ComboBox::from_id_salt("app_lang_selector")
                            .selected_text(
                                RichText::new(self.lang.code())
                                    .size(12.0)
                                    .strong()
                                    .color(COLOR_ACCENT_GREEN),
                            )
                            .width(58.0)
                            .show_ui(ui, |ui| {
                                if !self.cjk_font_loaded {
                                    self.cjk_font_loaded = true;
                                    ensure_cjk_fallback_font(ctx);
                                }
                                ui.set_min_width(150.0);
                                for l in AppLang::ALL {
                                    ui.selectable_value(&mut self.lang, l, l.display_name());
                                }
                            });
                        lang_combo.response.on_hover_text(tr.lang_tooltip);
                        if self.lang != prev_lang && self.lang.needs_cjk_font() && !self.cjk_font_loaded {
                            self.cjk_font_loaded = true;
                            ensure_cjk_fallback_font(ctx);
                        }

                        ui.add_space(4.0);

                        let current_mode = self.color_mode;
                        egui::ComboBox::from_id_salt("color_mode_selector")
                            .selected_text(
                                RichText::new(format!(
                                    "{}: {}",
                                    tr.color_prefix,
                                    current_mode.short_badge()
                                ))
                                .size(12.0)
                                .strong()
                                .color(COLOR_TEXT_MAIN),
                            )
                            .width(185.0)
                            .show_ui(ui, |ui| {
                                ui.label(
                                    RichText::new(tr.color_menu_title)
                                        .size(12.0)
                                        .strong()
                                        .color(COLOR_ACCENT_GREEN),
                                );
                                ui.label(
                                    RichText::new(format!(
                                        "{}: {}",
                                        tr.monitor_icc_prefix,
                                        self.monitor_profile.profile_name
                                    ))
                                    .size(11.0)
                                    .color(COLOR_TEXT_DIM),
                                );
                                ui.separator();

                                for mode in [
                                    ColorMode::StandardSrgb,
                                    ColorMode::MonitorIcc,
                                    ColorMode::CmykSoftProof,
                                ] {
                                    let resp = ui.selectable_value(
                                        &mut self.color_mode,
                                        mode,
                                        mode.label(),
                                    );
                                    resp.on_hover_text(mode.description());
                                }
                            });

                        let eye_btn = ui.add_sized(
                            [74.0, 28.0],
                            egui::Button::new(
                                RichText::new(tr.eyedropper)
                                    .size(12.0)
                                    .strong()
                                    .color(if self.eyedropper_enabled {
                                        COLOR_ACCENT_GREEN
                                    } else {
                                        COLOR_TEXT_MAIN
                                    }),
                            )
                            .fill(if self.eyedropper_enabled {
                                COLOR_ACCENT_LIGHT
                            } else {
                                Color32::WHITE
                            })
                            .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                            .rounding(Rounding::same(6.0)),
                        );
                        if eye_btn
                            .on_hover_text(tr.eyedropper_tooltip)
                            .clicked()
                        {
                            self.eyedropper_enabled = !self.eyedropper_enabled;
                        }

                        if let Some(ref sample) = self.hovered_color {
                            egui::Frame::none()
                                .fill(COLOR_PILL_BG)
                                .rounding(Rounding::same(4.0))
                                .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                                .inner_margin(Margin::symmetric(8.0, 4.0))
                                .show(ui, |ui| {
                                    ui.horizontal(|ui| {
                                        let (rect, _) = ui.allocate_exact_size(
                                            Vec2::new(14.0, 14.0),
                                            Sense::hover(),
                                        );
                                        ui.painter().rect_filled(
                                            rect,
                                            Rounding::same(3.0),
                                            Color32::from_rgb(sample.r, sample.g, sample.b),
                                        );
                                        ui.painter().rect_stroke(
                                            rect,
                                            Rounding::same(3.0),
                                            Stroke::new(1.0_f32, COLOR_TEXT_DIM),
                                        );
                                        ui.label(
                                            RichText::new(format!(
                                                "{} • C:{} M:{} Y:{} K:{}",
                                                sample.hex_string(),
                                                sample.c,
                                                sample.m,
                                                sample.y,
                                                sample.k
                                            ))
                                            .size(11.5)
                                            .monospace()
                                            .color(COLOR_TEXT_MAIN),
                                        );
                                    });
                                });
                        }
                    });
                });
            });
    }

    fn render_empty_welcome(&mut self, ui: &mut Ui) {
        let tr = self.lang.tr();
        let mut clicked_path: Option<PathBuf> = None;
        let mut pick_folder = false;

        ScrollArea::vertical()
            .id_salt("cover_gallery_scroll")
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.add_space(18.0);
                ui.horizontal(|ui| {
                    ui.add_space(28.0);
                    let (icon_rect, _) =
                        ui.allocate_exact_size(Vec2::new(40.0, 40.0), Sense::hover());
                    ui.painter().image(
                        self.badge_texture.id(),
                        icon_rect,
                        Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                        Color32::WHITE,
                    );
                    ui.add_space(10.0);
                    ui.vertical(|ui| {
                        ui.label(
                            RichText::new(tr.welcome_title)
                                .size(20.0)
                                .strong()
                                .color(COLOR_TEXT_MAIN),
                        );
                        let folder_text = self
                            .gallery_folder
                            .as_ref()
                            .map(|p| p.display().to_string())
                            .unwrap_or_else(|| "-".to_string());
                        ui.label(
                            RichText::new(format!(
                                "{}: {}  •  {}: {}",
                                tr.welcome_subtitle_prefix,
                                folder_text,
                                tr.color_prefix,
                                self.color_mode.label()
                            ))
                            .size(12.5)
                            .color(COLOR_TEXT_DIM),
                        );
                    });

                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        ui.add_space(28.0);
                        if ui
                            .add_sized(
                                [155.0, 34.0],
                                egui::Button::new(
                                    RichText::new(tr.change_folder)
                                        .size(13.0)
                                        .strong()
                                        .color(COLOR_TEXT_MAIN),
                                )
                                .fill(Color32::WHITE)
                                .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                                .rounding(Rounding::same(6.0)),
                            )
                            .clicked()
                        {
                            pick_folder = true;
                        }

                        if ui
                            .add_sized(
                                [165.0, 34.0],
                                egui::Button::new(
                                    RichText::new(tr.open_pdf_now)
                                        .size(13.0)
                                        .strong()
                                        .color(Color32::WHITE),
                                )
                                .fill(COLOR_ACCENT_GREEN)
                                .rounding(Rounding::same(6.0)),
                            )
                            .clicked()
                        {
                            self.trigger_open_file_dialog();
                        }
                    });
                });

                ui.add_space(18.0);

                if let Some(ref err) = self.engine_error {
                    ui.horizontal(|ui| {
                        ui.add_space(28.0);
                        ui.label(RichText::new(err).color(Color32::RED));
                    });
                }

                let avail_w = (ui.available_width() - 56.0).max(240.0);
                let card_w = 210.0f32;
                let card_h = 268.0f32;
                let gap_x = 22.0f32;
                let gap_y = 24.0f32;
                let cols = ((avail_w + gap_x) / (card_w + gap_x)).floor().max(1.0) as usize;

                for card in &self.gallery_cards {
                    if card.cover_texture.is_none() && !self.requested_covers.contains(&card.path) {
                        self.requested_covers.insert(card.path.clone());
                        let _ = self.worker.cmd_tx.send(WorkerCommand::RenderCoverPreview {
                            path: card.path.clone(),
                            max_side_px: 280,
                        });
                    }
                }

                let total_cards = self.gallery_cards.len();
                let rows = (total_cards + cols - 1) / cols;

                for r in 0..rows {
                    ui.horizontal(|ui| {
                        ui.add_space(28.0);
                        ui.spacing_mut().item_spacing.x = gap_x;

                        for c in 0..cols {
                            let idx = r * cols + c;
                            if idx >= total_cards {
                                break;
                            }
                            let card = &self.gallery_cards[idx];
                            let (item_rect, resp) = ui.allocate_exact_size(
                                Vec2::new(card_w, card_h),
                                Sense::click(),
                            );
                            if resp.clicked() {
                                clicked_path = Some(card.path.clone());
                            }

                            if resp.hovered() {
                                ui.painter().rect_filled(
                                    item_rect.expand(6.0),
                                    Rounding::same(8.0),
                                    COLOR_ACCENT_LIGHT,
                                );
                                ui.painter().rect_stroke(
                                    item_rect.expand(6.0),
                                    Rounding::same(8.0),
                                    Stroke::new(1.5_f32, COLOR_ACCENT_GREEN),
                                );
                            }

                            let box_area = Rect::from_min_size(
                                item_rect.min,
                                Vec2::new(card_w, 208.0),
                            );
                            let (pw, ph) = if card.aspect_ratio >= (card_w / 208.0) {
                                let w = card_w - 12.0;
                                let h = (w / card.aspect_ratio).clamp(80.0, 204.0);
                                (w, h)
                            } else {
                                let h = 202.0;
                                let w = (h * card.aspect_ratio).clamp(80.0, card_w - 8.0);
                                (w, h)
                            };

                            let cover_rect = Rect::from_center_size(
                                box_area.center(),
                                Vec2::new(pw, ph),
                            );

                            ui.painter().rect_filled(
                                cover_rect.translate(Vec2::new(0.0, 3.0)).expand(1.5),
                                Rounding::same(2.0),
                                Color32::from_black_alpha(38),
                            );

                            ui.painter().rect_filled(
                                cover_rect,
                                Rounding::ZERO,
                                Color32::WHITE,
                            );
                            if let Some(ref tex) = card.cover_texture {
                                ui.painter().image(
                                    tex.id(),
                                    cover_rect,
                                    Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                    Color32::WHITE,
                                );
                            }
                            ui.painter().rect_stroke(
                                cover_rect,
                                Rounding::ZERO,
                                Stroke::new(1.0_f32, COLOR_BORDER),
                            );

                            // Huy hiệu Vector "PDF Cực Xanh" ở góc dưới bên phải trang bìa
                            let badge_size = Vec2::new(42.0, 42.0);
                            let badge_rect = Rect::from_min_size(
                                Pos2::new(
                                    cover_rect.max.x - badge_size.x + 8.0,
                                    cover_rect.max.y - badge_size.y + 4.0,
                                ),
                                badge_size,
                            );
                            ui.painter().image(
                                self.badge_texture.id(),
                                badge_rect,
                                Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                Color32::WHITE,
                            );

                            let title_short = truncate_str(&card.title, 44);
                            let text_rect = Rect::from_min_size(
                                Pos2::new(item_rect.min.x + 4.0, item_rect.min.y + 216.0),
                                Vec2::new(card_w - 8.0, 48.0),
                            );
                            let mut child_ui = ui.new_child(
                                egui::UiBuilder::new()
                                    .max_rect(text_rect)
                                    .layout(egui::Layout::top_down(egui::Align::Center)),
                            );
                            child_ui.label(
                                RichText::new(title_short)
                                    .size(12.5)
                                    .strong()
                                    .color(COLOR_TEXT_MAIN),
                            );
                            let size_mb = card.file_size_bytes as f64 / (1024.0 * 1024.0);
                            let sub_info = match card.page_count {
                                Some(p) => format!("{p} trang • {size_mb:.1} MB"),
                                None => format!("{size_mb:.1} MB"),
                            };
                            child_ui.label(
                                RichText::new(sub_info)
                                    .size(11.0)
                                    .color(COLOR_TEXT_DIM),
                            );
                        }
                    });
                    ui.add_space(gap_y);
                }
            });

        if pick_folder {
            if let Some(folder) = rfd::FileDialog::new()
                .set_title("Chọn thư mục chứa file PDF để xem Bìa Thumbnail")
                .pick_folder()
            {
                self.scan_folder_for_covers(&folder);
            }
        }

        if let Some(path) = clicked_path {
            self.show_cover_gallery = false;
            self.open_file(path);
        }
    }

    fn render_active_document(&mut self, ctx: &Context) {
        let tr = self.lang.tr();
        let Some(tab) = self.tabs.get_mut(self.active_tab) else {
            return;
        };

        if tab.is_loading {
            egui::CentralPanel::default()
                .frame(egui::Frame::none().fill(COLOR_CANVAS))
                .show(ctx, |ui| {
                    ui.centered_and_justified(|ui| {
                        ui.label(
                            RichText::new(format!("{} '{}'...", tr.loading_fast, tab.title))
                                .size(16.0)
                                .strong()
                                .color(COLOR_TEXT_MAIN),
                        );
                    });
                });
            return;
        }

        if let Some(err) = tab.error.clone() {
            egui::CentralPanel::default()
                .frame(egui::Frame::none().fill(COLOR_CANVAS))
                .show(ctx, |ui| {
                    ui.centered_and_justified(|ui| {
                        ui.vertical_centered(|ui| {
                            ui.label(
                                RichText::new(format!("{}: {err}", tr.open_error_prefix))
                                    .size(15.0)
                                    .color(Color32::RED),
                            );
                        });
                    });
                });
            return;
        }

        let doc_id = tab.doc_id;
        let doc_title = tab.title.clone();
        let rotation_steps = tab.rotation_steps;
        let color_mode = self.color_mode;
        let page_count = tab.page_dimensions.len();
        if page_count == 0 {
            return;
        }

        let mut render_tasks: Vec<RenderTask> = Vec::new();
        let mut clicked_thumbnail_page: Option<usize> = None;
        let mut context_copy_page: Option<usize> = None;
        let mut context_export_page: Option<(usize, &'static str)> = None;
        let mut context_rotate = false;
        let mut context_reset_zoom = false;

        let pending_thumb_scroll = tab.pending_thumb_scroll_to_page.take();
        let current_page_snapshot = tab.current_page;
        let page_dims_snapshot = tab.page_dimensions.clone();

        // ================= 1. CỘT THUMBNAIL TRÁI (Giao diện Sáng) =================
        if self.show_sidebar {
            egui::SidePanel::left("chrome_thumbnail_sidebar")
                .resizable(false)
                .exact_width(184.0)
                .frame(
                    egui::Frame::none()
                        .fill(COLOR_SIDEBAR)
                        .inner_margin(Margin::symmetric(12.0, 10.0))
                        .stroke(Stroke::new(1.0_f32, COLOR_BORDER)),
                )
                .show(ctx, |ui| {
                    let max_thumb_w = 118.0f32;
                    let max_thumb_h = 164.0f32;
                    let item_spacing = 18.0f32;

                    let mut thumb_offsets = Vec::with_capacity(page_count + 1);
                    let mut thumb_sizes = Vec::with_capacity(page_count);
                    let mut acc_y = 0.0f32;
                    for dim in &page_dims_snapshot {
                        thumb_offsets.push(acc_y);
                        let (pt_w, pt_h) = dim.rotated_size(rotation_steps);
                        let scale =
                            (max_thumb_w / pt_w.max(1.0)).min(max_thumb_h / pt_h.max(1.0));
                        let tw = (pt_w * scale).max(24.0);
                        let th = (pt_h * scale).max(24.0);
                        thumb_sizes.push(Vec2::new(tw, th));
                        acc_y += th + 24.0 + item_spacing;
                    }
                    thumb_offsets.push(acc_y);

                    let mut scroll_area = ScrollArea::vertical()
                        .id_salt(("thumb_scroll", doc_id))
                        .auto_shrink([false, false]);

                    if let Some(target_idx) = pending_thumb_scroll {
                        if let Some(&target_y) = thumb_offsets.get(target_idx) {
                            scroll_area =
                                scroll_area.vertical_scroll_offset((target_y - 120.0).max(0.0));
                        }
                    }

                    scroll_area.show_viewport(ui, |ui, viewport| {
                        ui.set_height(acc_y.max(viewport.height()));
                        let origin = ui.min_rect().min;
                        let avail_w = ui.available_width();

                        let first_idx = thumb_offsets
                            .partition_point(|&y| y < viewport.min.y - 220.0)
                            .saturating_sub(1);
                        let last_idx = thumb_offsets
                            .partition_point(|&y| y <= viewport.max.y + 220.0)
                            .min(page_count);

                        for idx in first_idx..last_idx {
                            let y_top = thumb_offsets[idx];
                            let tsize = thumb_sizes[idx];
                            let x_left = origin.x + (avail_w - tsize.x) * 0.5;
                            let thumb_rect = Rect::from_min_size(
                                Pos2::new(x_left, origin.y + y_top),
                                tsize,
                            );

                            let resp = ui.interact(
                                thumb_rect,
                                ui.id().with(("thumb_item", idx)),
                                Sense::click(),
                            );
                            if resp.clicked() {
                                clicked_thumbnail_page = Some(idx);
                            }

                            // Menu chuột phải trên cả Thumbnail
                            resp.context_menu(|ui| {
                                ui.set_min_width(230.0);
                                ui.label(
                                    RichText::new(format!(
                                        "{} {} / {}",
                                        tr.page_label,
                                        idx + 1,
                                        page_count
                                    ))
                                    .size(12.0)
                                    .strong()
                                    .color(COLOR_ACCENT_GREEN),
                                );
                                ui.separator();
                                if ui.button(tr.ctx_copy_clipboard).clicked() {
                                    context_copy_page = Some(idx);
                                    ui.close_menu();
                                }
                                if ui.button(tr.ctx_export_jpg).clicked() {
                                    context_export_page = Some((idx, "jpg"));
                                    ui.close_menu();
                                }
                                if ui.button(tr.ctx_export_png).clicked() {
                                    context_export_page = Some((idx, "png"));
                                    ui.close_menu();
                                }
                            });

                            let shadow_rect = thumb_rect.translate(Vec2::new(0.0, 2.0)).expand(1.0);
                            ui.painter().rect_filled(
                                shadow_rect,
                                Rounding::same(2.0),
                                Color32::from_black_alpha(28),
                            );

                            let thumb_key = (doc_id, idx, rotation_steps, color_mode);
                            if let Some(tex) = self.thumb_cache.get(&thumb_key) {
                                ui.painter().image(
                                    tex.id(),
                                    thumb_rect,
                                    Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                    Color32::WHITE,
                                );
                            } else if let Some((_, best_tex)) =
                                self.best_page_textures.get(&(doc_id, idx))
                            {
                                ui.painter().image(
                                    best_tex.id(),
                                    thumb_rect,
                                    Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                    Color32::WHITE,
                                );
                            } else {
                                ui.painter().rect_filled(
                                    thumb_rect,
                                    Rounding::ZERO,
                                    Color32::WHITE,
                                );
                                let req_w = tsize.x.round().max(32.0) as u32;
                                let req_h = tsize.y.round().max(32.0) as u32;
                                render_tasks.push(RenderTask {
                                    key: PageCacheKey {
                                        doc_id,
                                        page_index: idx,
                                        width_px: req_w,
                                        height_px: req_h,
                                        rotation_steps,
                                        color_mode,
                                        is_thumbnail: true,
                                    },
                                    priority: if idx == current_page_snapshot { 0 } else { 1 },
                                });
                            }

                            if idx == current_page_snapshot {
                                ui.painter().rect_stroke(
                                    thumb_rect.expand(3.0),
                                    Rounding::same(3.0),
                                    Stroke::new(2.5_f32, COLOR_ACCENT_GREEN),
                                );
                            } else if resp.hovered() {
                                ui.painter().rect_stroke(
                                    thumb_rect.expand(2.0),
                                    Rounding::same(2.0),
                                    Stroke::new(1.5_f32, Color32::from_rgb(148, 163, 184)),
                                );
                            } else {
                                ui.painter().rect_stroke(
                                    thumb_rect,
                                    Rounding::ZERO,
                                    Stroke::new(1.0_f32, COLOR_BORDER),
                                );
                            }

                            let label_pos = Pos2::new(
                                thumb_rect.center().x,
                                thumb_rect.max.y + 13.0,
                            );
                            ui.painter().text(
                                label_pos,
                                egui::Align2::CENTER_CENTER,
                                format!("{}", idx + 1),
                                FontId::proportional(12.0),
                                if idx == current_page_snapshot {
                                    COLOR_ACCENT_GREEN
                                } else {
                                    COLOR_TEXT_DIM
                                },
                            );
                        }
                    });
                });
        }

        // ================= 2. VÙNG XEM TRANG CHÍNH GIỮA (Zoom 120FPS mượt + Menu Chuột Phải) =================
        egui::CentralPanel::default()
            .frame(egui::Frame::none().fill(COLOR_CANVAS))
            .show(ctx, |ui| {
                let avail_size = ui.available_size();
                self.last_viewport_size = avail_size;

                let Some(tab) = self.tabs.get_mut(self.active_tab) else {
                    return;
                };

                if let Some(clicked_page) = clicked_thumbnail_page {
                    tab.current_page = clicked_page;
                    tab.page_input_text = (clicked_page + 1).to_string();
                    tab.pending_scroll_to_page = Some(clicked_page);
                }

                // Xử lý Ctrl + Lăn chuột:
                // 1) Triệt tiêu smooth_scroll_delta khi đang giữ Ctrl để ScrollArea không cuộn dọc cùng lúc với Zoom (chống giật)
                // 2) Neo chính xác vào vị trí trang hiện tại ở tâm màn hình
                let zoom_delta = ctx.input_mut(|i| {
                    let zd = i.zoom_delta();
                    if (zd - 1.0).abs() > 0.0005 || i.modifiers.ctrl {
                        if (zd - 1.0).abs() > 0.0005 {
                            i.smooth_scroll_delta = Vec2::ZERO;
                        }
                    }
                    zd
                });

                if (zoom_delta - 1.0).abs() > 0.0005 {
                    let target_zoom = (tab.zoom * zoom_delta).clamp(0.05, 8.0);
                    apply_center_zoom(tab, target_zoom, avail_size);
                }

                // Kiểm tra xem người dùng có đang trong thao tác lăn chuột Zoom liên tục không (Debounce 160ms)
                let is_actively_zooming = if let Some(t_zoom) = tab.last_zoom_instant {
                    let elapsed = t_zoom.elapsed().as_millis();
                    if elapsed < 170 {
                        ctx.request_repaint_after(std::time::Duration::from_millis(40));
                        true
                    } else {
                        false
                    }
                } else {
                    false
                };

                if let Some(fit) = tab.fit_mode {
                    let cur_dim = tab.page_dimensions[tab.current_page];
                    let (pt_w, pt_h) = cur_dim.rotated_size(tab.rotation_steps);
                    let base_w = pt_w * DPI_SCALE;
                    let base_h = pt_h * DPI_SCALE;
                    match fit {
                        FitMode::FitWidth => {
                            tab.zoom = ((avail_size.x - 48.0).max(200.0) / base_w).clamp(0.05, 8.0);
                        }
                        FitMode::FitPage => {
                            let zw = (avail_size.x - 48.0).max(200.0) / base_w;
                            let zh = (avail_size.y - 32.0).max(200.0) / base_h;
                            tab.zoom = zw.min(zh).clamp(0.05, 8.0);
                        }
                    }
                }

                let zoom = tab.zoom;

                // QUAN TRỌNG CHỐNG GIẬT KHI ZOOM & CĂN GIỮA KHUNG NHÌN:
                // 1) Tính kích thước hiển thị (disp_w, disp_h) bằng số thực dấu phẩy động (f32) KHÔNG làm tròn .round()
                // 2) Với file có 1 trang (hoặc khi tổng chiều cao các trang nhỏ hơn chiều cao khung nhìn),
                //    tự động căn giữa trang theo cả chiều dọc lẫn chiều ngang trong khung nhìn!
                let mut page_display_sizes = Vec::with_capacity(page_count);
                let mut total_pages_h = 0.0f32;
                for (i, dim) in tab.page_dimensions.iter().enumerate() {
                    let (pt_w, pt_h) = dim.rotated_size(rotation_steps);
                    let disp_w = (pt_w * DPI_SCALE * zoom).max(40.0);
                    let disp_h = (pt_h * DPI_SCALE * zoom).max(40.0);
                    page_display_sizes.push(Vec2::new(disp_w, disp_h));
                    total_pages_h += disp_h;
                    if i + 1 < page_count {
                        total_pages_h += PAGE_GAP;
                    }
                }

                let start_y = if total_pages_h + TOP_PADDING * 2.0 < avail_size.y {
                    ((avail_size.y - total_pages_h) * 0.5).max(TOP_PADDING)
                } else {
                    TOP_PADDING
                };

                let mut page_y_offsets = Vec::with_capacity(page_count + 1);
                let mut acc_y = start_y;
                for disp in &page_display_sizes {
                    page_y_offsets.push(acc_y);
                    acc_y += disp.y + PAGE_GAP;
                }
                page_y_offsets.push(acc_y);

                let cur_page_w = page_display_sizes
                    .get(tab.current_page)
                    .map(|s| s.x)
                    .unwrap_or(800.0);
                let canvas_w = (cur_page_w + 32.0).max(avail_size.x);
                let canvas_h = acc_y.max(avail_size.y);

                let mut scroll_area = ScrollArea::both()
                    .id_salt(("main_pdf_scroll", doc_id))
                    .auto_shrink([false, false]);

                if let Some(target_page) = tab.pending_scroll_to_page.take() {
                    if let Some(&target_y) = page_y_offsets.get(target_page) {
                        let new_y = (target_y - TOP_PADDING).max(0.0);
                        let new_x = ((canvas_w - avail_size.x) * 0.5).max(0.0);
                        scroll_area = scroll_area.scroll_offset(Vec2::new(new_x, new_y));
                    }
                } else if let Some(offset) = tab.pending_scroll_offset.take() {
                    scroll_area = scroll_area.scroll_offset(offset);
                }

                let mut new_current_page = tab.current_page;
                let mut sampled_color: Option<EyedropperSample> = None;
                let alt_held = ui.input(|i| i.modifiers.alt);
                let inspect_color_active = self.eyedropper_enabled || alt_held;

                let scroll_out = scroll_area.show_viewport(ui, |ui, viewport| {
                    ui.set_min_size(Vec2::new(canvas_w, canvas_h));

                    // Kéo trượt bản vẽ (Pan) bằng chuột giữa hoặc giữ phím Space + kéo chuột trái
                    let space_held = ui.input(|i| i.key_down(Key::Space));
                    let drag_middle =
                        ui.input(|i| i.pointer.button_down(egui::PointerButton::Middle));
                    let drag_primary =
                        ui.input(|i| i.pointer.button_down(egui::PointerButton::Primary));
                    if drag_middle || (space_held && drag_primary) {
                        let delta = ui.input(|i| i.pointer.delta());
                        if delta != Vec2::ZERO {
                            ui.scroll_with_delta(delta);
                        }
                    }

                    let origin = ui.min_rect().min;

                    let view_center_y = viewport.min.y + viewport.height() * 0.45;
                    let center_idx = page_y_offsets
                        .partition_point(|&y| y <= view_center_y)
                        .saturating_sub(1)
                        .min(page_count - 1);
                    new_current_page = center_idx;

                    let first_vis = page_y_offsets
                        .partition_point(|&y| y < viewport.min.y - 40.0)
                        .saturating_sub(1);
                    let last_vis = page_y_offsets
                        .partition_point(|&y| y <= viewport.max.y + 40.0)
                        .min(page_count);

                    let ppp = ctx.pixels_per_point().clamp(1.0, 2.5);
                    let pointer_pos = ui.input(|i| i.pointer.hover_pos());

                    for idx in first_vis..last_vis {
                        let disp_size = page_display_sizes[idx];
                        let x_left = origin.x + ((canvas_w - disp_size.x) * 0.5).max(8.0);
                        let y_top = origin.y + page_y_offsets[idx];
                        let page_rect = Rect::from_min_size(Pos2::new(x_left, y_top), disp_size);

                        // Tương tác chuột phải trên trang PDF
                        let page_resp = ui.interact(
                            page_rect,
                            ui.id().with(("pdf_page_view", doc_id, idx)),
                            Sense::click(),
                        );

                        page_resp.context_menu(|ui| {
                            ui.set_min_width(255.0);
                            ui.label(
                                RichText::new(format!(
                                    "{} {} / {}",
                                    tr.page_label,
                                    idx + 1,
                                    page_count
                                ))
                                .size(12.5)
                                .strong()
                                .color(COLOR_ACCENT_GREEN),
                            );
                            ui.separator();
                            if ui.button(tr.ctx_copy_clipboard).clicked() {
                                context_copy_page = Some(idx);
                                ui.close_menu();
                            }
                            if ui.button(tr.ctx_export_jpg).clicked() {
                                context_export_page = Some((idx, "jpg"));
                                ui.close_menu();
                            }
                            if ui.button(tr.ctx_export_png).clicked() {
                                context_export_page = Some((idx, "png"));
                                ui.close_menu();
                            }
                            ui.separator();
                            if ui.button(tr.ctx_rotate_90).clicked() {
                                context_rotate = true;
                                ui.close_menu();
                            }
                            if ui.button(tr.ctx_reset_zoom).clicked() {
                                context_reset_zoom = true;
                                ui.close_menu();
                            }
                        });

                        // Đổ bóng trang giấy tinh tế trên nền sáng
                        let shadow_rect = page_rect.translate(Vec2::new(0.0, 3.0)).expand(2.0);
                        ui.painter().rect_filled(
                            shadow_rect,
                            Rounding::same(2.0),
                            Color32::from_black_alpha(32),
                        );

                        // Nền giấy trắng
                        ui.painter()
                            .rect_filled(page_rect, Rounding::ZERO, Color32::WHITE);

                        let target_w_px = ((disp_size.x * ppp).round() as u32).clamp(64, 3840);
                        let target_h_px = ((disp_size.y * ppp).round() as u32).clamp(64, 3840);

                        let page_key = PageCacheKey {
                            doc_id,
                            page_index: idx,
                            width_px: target_w_px,
                            height_px: target_h_px,
                            rotation_steps,
                            color_mode,
                            is_thumbnail: false,
                        };

                        if let Some(cached) = self.page_cache.get(&page_key) {
                            ui.painter().image(
                                cached.texture.id(),
                                page_rect,
                                Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                Color32::WHITE,
                            );

                            if inspect_color_active {
                                if let Some(pos) = pointer_pos {
                                    if page_rect.contains(pos) {
                                        let rel_x = ((pos.x - page_rect.min.x) / page_rect.width())
                                            .clamp(0.0, 0.9999);
                                        let rel_y = ((pos.y - page_rect.min.y) / page_rect.height())
                                            .clamp(0.0, 0.9999);
                                        let px = (rel_x * cached.width as f32) as usize;
                                        let py = (rel_y * cached.height as f32) as usize;
                                        let offset = (py * cached.width + px) * 4;
                                        if offset + 3 < cached.raw_rgba.len() {
                                            let r = cached.raw_rgba[offset];
                                            let g = cached.raw_rgba[offset + 1];
                                            let b = cached.raw_rgba[offset + 2];
                                            let (c, m, y, k) = rgb_to_cmyk_percent(r, g, b);
                                            let sample = EyedropperSample {
                                                r,
                                                g,
                                                b,
                                                c,
                                                m,
                                                y,
                                                k,
                                            };

                                            if ui.input(|i| {
                                                i.pointer
                                                    .button_clicked(egui::PointerButton::Primary)
                                            }) {
                                                let text = sample.summary_string();
                                                ctx.copy_text(text.clone());
                                                self.toast = Some(ToastBanner {
                                                    message: format!(
                                                        "✅ Đã copy mã màu: {}",
                                                        text
                                                    ),
                                                    is_error: false,
                                                    created_at: Instant::now(),
                                                });
                                            }
                                            sampled_color = Some(sample);
                                        }
                                    }
                                }
                            }
                        } else {
                            // Hiển thị ngay bản vẽ sẵn có trên GPU trong lúc đang lăn chuột Zoom (mượt 120 FPS)
                            let mut has_any_tex = false;
                            if let Some((_, best_tex)) =
                                self.best_page_textures.get(&(doc_id, idx))
                            {
                                ui.painter().image(
                                    best_tex.id(),
                                    page_rect,
                                    Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                    Color32::WHITE,
                                );
                                has_any_tex = true;
                            }

                            // CHỐNG GIẬT: Khi người dùng đang giữ Ctrl + Lăn chuột liên tục,
                            // chỉ yêu cầu PDFium vẽ lại sau khi đã ngừng lăn 160ms (trừ khi trang đó chưa có ảnh nào)!
                            if !is_actively_zooming || !has_any_tex {
                                let is_on_screen = page_rect.max.y >= origin.y + viewport.min.y
                                    && page_rect.min.y <= origin.y + viewport.max.y;
                                let priority = if idx == center_idx {
                                    0
                                } else if is_on_screen {
                                    1
                                } else {
                                    3
                                };

                                render_tasks.push(RenderTask {
                                    key: page_key,
                                    priority,
                                });
                            }
                        }

                        ui.painter().rect_stroke(
                            page_rect,
                            Rounding::ZERO,
                            Stroke::new(1.0_f32, COLOR_BORDER),
                        );
                    }
                });

                tab.last_scroll_offset = scroll_out.state.offset;
                tab.last_canvas_size = Vec2::new(canvas_w, canvas_h);

                if new_current_page != tab.current_page {
                    tab.current_page = new_current_page;
                    if !ctx.wants_keyboard_input() {
                        tab.page_input_text = (new_current_page + 1).to_string();
                    }
                    tab.pending_thumb_scroll_to_page = Some(new_current_page);
                }
                self.hovered_color = sampled_color;

                if context_rotate {
                    tab.rotation_steps = (tab.rotation_steps + 1).rem_euclid(4);
                }
                if context_reset_zoom {
                    apply_center_zoom(tab, 1.0, avail_size);
                }
            });

        // Xử lý lệnh từ Menu Chuột Phải (Copy trang vào Clipboard / Xuất ra file JPG-PNG)
        if let Some(page_idx) = context_copy_page {
            self.toast = Some(ToastBanner {
                message: format!(
                    "⏳ Đang copy Trang {} độ phân giải cao vào Clipboard...",
                    page_idx + 1
                ),
                is_error: false,
                created_at: Instant::now(),
            });
            let _ = self.worker.cmd_tx.send(WorkerCommand::CopyPageToClipboard {
                doc_id,
                page_index: page_idx,
                rotation_steps,
                color_mode,
            });
        }

        if let Some((page_idx, ext)) = context_export_page {
            self.trigger_export_page_dialog(doc_id, &doc_title, page_idx, rotation_steps, ext);
        }

        if !render_tasks.is_empty() {
            let _ = self
                .worker
                .cmd_tx
                .send(WorkerCommand::SyncRenderQueue { tasks: render_tasks });
        }
    }

    fn render_toast_overlay(&mut self, ctx: &Context) {
        let Some(ref toast) = self.toast else {
            return;
        };
        let elapsed = toast.created_at.elapsed().as_secs_f32();
        if elapsed > 3.8 {
            self.toast = None;
            return;
        }
        ctx.request_repaint_after(std::time::Duration::from_millis(100));

        let screen = ctx.screen_rect();
        let pos = Pos2::new(screen.center().x, screen.max.y - 42.0);
        let bg = if toast.is_error {
            Color32::from_rgb(185, 28, 28)
        } else {
            Color32::from_rgb(6, 95, 70)
        };

        egui::Area::new(egui::Id::new("lumepdf_toast_banner"))
            .fixed_pos(pos)
            .pivot(egui::Align2::CENTER_CENTER)
            .order(egui::Order::Foreground)
            .interactable(false)
            .show(ctx, |ui| {
                egui::Frame::none()
                    .fill(bg)
                    .rounding(Rounding::same(8.0))
                    .stroke(Stroke::new(1.0_f32, Color32::WHITE.gamma_multiply(0.35)))
                    .inner_margin(Margin::symmetric(16.0, 9.0))
                    .show(ui, |ui| {
                        ui.label(
                            RichText::new(&toast.message)
                                .size(13.0)
                                .strong()
                                .color(Color32::WHITE),
                        );
                    });
            });
    }
}

/// Thuật toán Zoom Neo Chính Xác Theo Tọa Độ Nội Bộ Của Trang Đang Xem (Page-Local Center Anchor):
/// Triệt tiêu hoàn toàn hiện tượng nhảy trang do khoảng cách giữa các trang (PAGE_GAP) kể cả ở trang thứ 800!
fn apply_center_zoom(tab: &mut DocumentTab, new_zoom: f32, viewport_size: Vec2) {
    let old_zoom = tab.zoom;
    if (new_zoom - old_zoom).abs() < 0.0005 {
        return;
    }
    tab.fit_mode = None;
    tab.zoom = new_zoom;
    tab.last_zoom_instant = Some(Instant::now());

    let view_w = viewport_size.x.max(100.0);
    let view_h = viewport_size.y.max(100.0);
    let old_center_y = tab.last_scroll_offset.y + view_h * 0.5;

    let page_count = tab.page_dimensions.len();
    let mut old_total_h = 0.0f32;
    let mut new_total_h = 0.0f32;
    for (i, dim) in tab.page_dimensions.iter().enumerate() {
        let (_, pt_h) = dim.rotated_size(tab.rotation_steps);
        old_total_h += (pt_h * DPI_SCALE * old_zoom).max(40.0);
        new_total_h += (pt_h * DPI_SCALE * new_zoom).max(40.0);
        if i + 1 < page_count {
            old_total_h += PAGE_GAP;
            new_total_h += PAGE_GAP;
        }
    }

    let old_start_y = if old_total_h + TOP_PADDING * 2.0 < view_h {
        ((view_h - old_total_h) * 0.5).max(TOP_PADDING)
    } else {
        TOP_PADDING
    };
    let new_start_y = if new_total_h + TOP_PADDING * 2.0 < view_h {
        ((view_h - new_total_h) * 0.5).max(TOP_PADDING)
    } else {
        TOP_PADDING
    };

    // 1. Tìm chính xác trang đang nằm ở tâm màn hình và tỷ lệ vị trí dọc (rel_y in [0..1]) bên trong trang đó
    let mut old_acc_y = old_start_y;
    let mut anchor_page = tab.current_page;
    let mut rel_y_in_page = 0.5f32;

    for (idx, dim) in tab.page_dimensions.iter().enumerate() {
        let (_, pt_h) = dim.rotated_size(tab.rotation_steps);
        let old_h = (pt_h * DPI_SCALE * old_zoom).max(40.0);
        let next_y = old_acc_y + old_h + PAGE_GAP;
        if old_center_y <= next_y || idx + 1 == page_count {
            anchor_page = idx;
            rel_y_in_page = ((old_center_y - old_acc_y) / old_h).clamp(0.0, 1.0);
            break;
        }
        old_acc_y = next_y;
    }

    // 2. Tính vị trí Y mới của đúng điểm đó ở mức new_zoom
    let mut new_anchor_top_y = new_start_y;
    for idx in 0..anchor_page {
        let (_, pt_h) = tab.page_dimensions[idx].rotated_size(tab.rotation_steps);
        let new_h = (pt_h * DPI_SCALE * new_zoom).max(40.0);
        new_anchor_top_y += new_h + PAGE_GAP;
    }
    let (_, anchor_pt_h) = tab.page_dimensions[anchor_page].rotated_size(tab.rotation_steps);
    let new_anchor_h = (anchor_pt_h * DPI_SCALE * new_zoom).max(40.0);
    let new_center_y = new_anchor_top_y + rel_y_in_page * new_anchor_h;
    let new_scroll_y = (new_center_y - view_h * 0.5).max(0.0);

    // 3. Neo tâm theo chiều ngang (luôn giữ chính giữa 50% khi trang bắt đầu phóng to vượt khung nhìn)
    let cur_dim = tab
        .page_dimensions
        .get(anchor_page)
        .copied()
        .unwrap_or(PageDimension {
            width_pt: 595.0,
            height_pt: 842.0,
        });
    let (pt_w, _) = cur_dim.rotated_size(tab.rotation_steps);
    let new_page_w = (pt_w * DPI_SCALE * new_zoom).max(40.0);
    let new_canvas_w = (new_page_w + 32.0).max(view_w);

    let old_canvas_w = tab.last_canvas_size.x.max(view_w);
    let rel_center_x = if old_canvas_w > view_w + 2.0 {
        ((tab.last_scroll_offset.x + view_w * 0.5) / old_canvas_w).clamp(0.0, 1.0)
    } else {
        0.5
    };

    let new_scroll_x = if new_canvas_w > view_w {
        (rel_center_x * new_canvas_w - view_w * 0.5).clamp(0.0, new_canvas_w - view_w)
    } else {
        0.0
    };

    tab.pending_scroll_offset = Some(Vec2::new(new_scroll_x, new_scroll_y));
}

#[derive(Clone, Copy)]
enum VectorBtnIcon {
    Minus,
    Plus,
    Info,
}

/// Vẽ nút bấm có biểu tượng "-", "+" và "i" (Thông tin) bằng Vector thuần túy (egui::Painter)
/// đảm bảo sắc nét 100% và KHÔNG BAO GIỜ bị lỗi ô vuông (□) trên bất kỳ máy Windows nào
fn draw_vector_icon_button(ui: &mut Ui, icon: VectorBtnIcon, tooltip: &str) -> egui::Response {
    let desired_size = Vec2::new(28.0, 28.0);
    let (rect, resp) = ui.allocate_exact_size(desired_size, Sense::click());

    let bg = if resp.is_pointer_button_down_on() || resp.hovered() {
        COLOR_ACCENT_LIGHT
    } else {
        Color32::WHITE
    };
    let border_col = if resp.hovered() {
        COLOR_ACCENT_GREEN
    } else {
        COLOR_BORDER
    };
    let fg_col = if resp.hovered() {
        COLOR_ACCENT_GREEN
    } else {
        COLOR_TEXT_MAIN
    };

    ui.painter().rect_filled(rect, Rounding::same(6.0), bg);
    ui.painter()
        .rect_stroke(rect, Rounding::same(6.0), Stroke::new(1.0_f32, border_col));

    let c = rect.center();
    let half_len = 5.5f32;
    let stroke = Stroke::new(2.0_f32, fg_col);

    match icon {
        VectorBtnIcon::Minus => {
            ui.painter().line_segment(
                [Pos2::new(c.x - half_len, c.y), Pos2::new(c.x + half_len, c.y)],
                stroke,
            );
        }
        VectorBtnIcon::Plus => {
            ui.painter().line_segment(
                [Pos2::new(c.x - half_len, c.y), Pos2::new(c.x + half_len, c.y)],
                stroke,
            );
            ui.painter().line_segment(
                [Pos2::new(c.x, c.y - half_len), Pos2::new(c.x, c.y + half_len)],
                stroke,
            );
        }
        VectorBtnIcon::Info => {
            // Vòng tròn chữ i Vector nhỏ gọn, sắc nét
            ui.painter()
                .circle_stroke(c, 7.5, Stroke::new(1.6_f32, fg_col));
            ui.painter()
                .circle_filled(Pos2::new(c.x, c.y - 3.5), 1.25, fg_col);
            ui.painter().line_segment(
                [Pos2::new(c.x, c.y - 0.8), Pos2::new(c.x, c.y + 4.3)],
                Stroke::new(1.8_f32, fg_col),
            );
        }
    }

    resp.on_hover_text(tooltip)
}

impl LumePdfApp {
    fn render_update_banner(&mut self, ctx: &Context) {
        let UpdateStatus::Available(version) = &self.update_check.status else {
            return;
        };
        if !self.show_update_banner {
            return;
        }

        let tr = self.lang.update_text();
        egui::TopBottomPanel::bottom("lumepdf_update_banner").show(ctx, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.label(format!("{} {version}", tr.available));
                ui.hyperlink_to(tr.download, RELEASES_URL);
                if ui.button(self.lang.tr().close_btn).clicked() {
                    self.show_update_banner = false;
                }
            });
        });
    }

    fn render_update_controls(&mut self, ui: &mut Ui, ctx: &Context) {
        let tr = self.lang.update_text();
        let checking = matches!(self.update_check.status, UpdateStatus::Checking);
        if ui.add_enabled(!checking, egui::Button::new(tr.check)).clicked() {
            self.update_check.start(ctx);
        }

        match &self.update_check.status {
            UpdateStatus::Idle => {}
            UpdateStatus::Checking => { ui.label(tr.checking); }
            UpdateStatus::Current => { ui.label(tr.current); }
            UpdateStatus::Available(version) => {
                ui.label(format!("{} {version}", tr.available));
                ui.hyperlink_to(tr.download, RELEASES_URL);
            }
            UpdateStatus::Failed => {
                ui.label(tr.failed);
                ui.hyperlink_to(tr.download, RELEASES_URL);
            }
        }
    }

    fn render_about_modal(&mut self, ctx: &Context) {
        if !self.show_about_modal {
            return;
        }
        let tr = self.lang.tr();

        if ctx.input(|i| i.key_pressed(Key::Escape)) {
            self.show_about_modal = false;
            return;
        }

        // Lớp nền mờ phía sau Popup (bấm ra ngoài để đóng nhanh)
        let screen_rect = ctx.screen_rect();
        egui::Area::new(egui::Id::new("about_modal_backdrop"))
            .order(egui::Order::Middle)
            .fixed_pos(screen_rect.min)
            .show(ctx, |ui| {
                let (rect, resp) =
                    ui.allocate_exact_size(screen_rect.size(), Sense::click());
                ui.painter()
                    .rect_filled(rect, Rounding::ZERO, Color32::from_black_alpha(95));
                if resp.clicked() {
                    self.show_about_modal = false;
                }
            });

        // Hộp thoại Popup Thông tin Phần mềm & Tác giả chính giữa màn hình
        egui::Window::new("Thông tin Phần mềm & Tác giả")
            .id(egui::Id::new("lumepdf_about_author_window"))
            .order(egui::Order::Foreground)
            .collapsible(false)
            .resizable(false)
            .title_bar(false)
            .anchor(egui::Align2::CENTER_CENTER, Vec2::ZERO)
            .fixed_size([320.0, 300.0])
            .frame(
                egui::Frame::none()
                    .fill(Color32::WHITE)
                    .rounding(Rounding::same(12.0))
                    .stroke(Stroke::new(1.5_f32, COLOR_ACCENT_GREEN))
                    .inner_margin(Margin::symmetric(22.0, 18.0)),
            )
            .show(ctx, |ui| {
                ui.vertical_centered(|ui| {
                    // Huy hiệu Icon Vector LumePDF
                    let (icon_rect, _) =
                        ui.allocate_exact_size(Vec2::new(48.0, 48.0), Sense::hover());
                    ui.painter().image(
                        self.badge_texture.id(),
                        icon_rect,
                        Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                        Color32::WHITE,
                    );

                    ui.add_space(6.0);
                    ui.label(
                        RichText::new("LumePDF")
                            .size(20.0)
                            .strong()
                            .color(COLOR_TEXT_MAIN),
                    );
                    ui.label(
                        RichText::new(format!("{} {CURRENT_VERSION}", tr.version_label))
                            .size(12.5)
                            .strong()
                            .color(COLOR_ACCENT_GREEN),
                    );
                    ui.label(
                        RichText::new(tr.app_subtitle)
                            .size(12.0)
                            .color(COLOR_TEXT_DIM),
                    );

                    ui.add_space(12.0);

                    // Khung thông tin Tác giả
                    egui::Frame::none()
                        .fill(COLOR_SIDEBAR)
                        .rounding(Rounding::same(8.0))
                        .stroke(Stroke::new(1.0_f32, COLOR_BORDER))
                        .inner_margin(Margin::symmetric(16.0, 10.0))
                        .show(ui, |ui| {
                            ui.set_min_width(265.0);
                            ui.vertical_centered(|ui| {
                                ui.label(
                                    RichText::new(tr.developed_by)
                                        .size(11.5)
                                        .color(COLOR_TEXT_DIM),
                                );
                                ui.add_space(2.0);
                                ui.label(
                                    RichText::new("Huy cola")
                                        .size(16.0)
                                        .strong()
                                        .color(COLOR_TEXT_MAIN),
                                );
                                ui.add_space(2.0);
                                let email_lbl = ui.add(
                                    egui::Label::new(
                                        RichText::new("huypx92@gmail.com")
                                            .size(13.0)
                                            .strong()
                                            .color(COLOR_ACCENT_GREEN),
                                    )
                                    .sense(Sense::click()),
                                );
                                if email_lbl
                                    .on_hover_text(tr.copy_email_tooltip)
                                    .clicked()
                                {
                                    ctx.copy_text("huypx92@gmail.com".to_string());
                                    self.toast = Some(ToastBanner {
                                        message: tr.copied_email_toast.to_string(),
                                        is_error: false,
                                        created_at: Instant::now(),
                                    });
                                }
                            });
                        });

                    ui.add_space(10.0);
                    self.render_update_controls(ui, ctx);
                    ui.add_space(12.0);
                    if ui
                        .add_sized(
                            [110.0, 32.0],
                            egui::Button::new(
                                RichText::new(tr.close_btn)
                                    .size(13.0)
                                    .strong()
                                    .color(Color32::WHITE),
                            )
                            .fill(COLOR_ACCENT_GREEN)
                            .rounding(Rounding::same(6.0)),
                        )
                        .clicked()
                    {
                        self.show_about_modal = false;
                    }
                });
            });
    }
}

impl eframe::App for LumePdfApp {
    fn update(&mut self, ctx: &Context, _frame: &mut eframe::Frame) {
        self.poll_worker_events(ctx);
        if self.update_check.poll() {
            self.show_update_banner = matches!(self.update_check.status, UpdateStatus::Available(_));
        }
        self.handle_shortcuts(ctx);
        self.render_tab_strip(ctx);
        self.render_chrome_toolbar(ctx);
        self.render_update_banner(ctx);

        if self.tabs.is_empty() || self.show_cover_gallery {
            egui::CentralPanel::default()
                .frame(egui::Frame::none().fill(COLOR_CANVAS))
                .show(ctx, |ui| {
                    self.render_empty_welcome(ui);
                });
        } else {
            self.render_active_document(ctx);
        }

        self.render_about_modal(ctx);
        self.render_toast_overlay(ctx);
    }
}

fn default_pdf_folder() -> Option<PathBuf> {
    if let Ok(profile) = std::env::var("USERPROFILE") {
        let dl = PathBuf::from(&profile).join("Downloads");
        if dl.is_dir() {
            return Some(dl);
        }
    }
    std::env::current_dir().ok()
}

fn draw_toolbar_divider(ui: &mut Ui) {
    let (rect, _) = ui.allocate_exact_size(Vec2::new(1.0, 20.0), Sense::hover());
    ui.painter()
        .rect_filled(rect, Rounding::ZERO, COLOR_BORDER);
}

fn truncate_str(s: &str, max_chars: usize) -> String {
    let count = s.chars().count();
    if count <= max_chars {
        s.to_string()
    } else {
        let prefix: String = s.chars().take(max_chars.saturating_sub(1)).collect();
        format!("{prefix}…")
    }
}

fn configure_vietnamese_fonts(ctx: &Context) {
    let mut fonts = FontDefinitions::default();
    let candidate_fonts = [
        r"C:\Windows\Fonts\segoeui.ttf",
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\tahoma.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/SFNS.ttf",
        "/Library/Fonts/Arial.ttf",
    ];

    for font_path in candidate_fonts {
        if let Ok(bytes) = std::fs::read(font_path) {
            fonts.font_data.insert(
                "vn_system_font".to_owned(),
                FontData::from_owned(bytes).into(),
            );
            if let Some(family) = fonts.families.get_mut(&FontFamily::Proportional) {
                family.insert(0, "vn_system_font".to_owned());
            }
            if let Some(family) = fonts.families.get_mut(&FontFamily::Monospace) {
                family.push("vn_system_font".to_owned());
            }
            break;
        }
    }

    let mono_candidates = [
        r"C:\Windows\Fonts\consola.ttf",
        "/System/Library/Fonts/Supplemental/Courier New.ttf",
    ];
    for mono_path in mono_candidates {
        if let Ok(consolas) = std::fs::read(mono_path) {
            fonts
                .font_data
                .insert("vn_mono".to_owned(), FontData::from_owned(consolas).into());
            if let Some(family) = fonts.families.get_mut(&FontFamily::Monospace) {
                family.insert(0, "vn_mono".to_owned());
            }
            break;
        }
    }

    ctx.set_fonts(fonts);
}

fn ensure_cjk_fallback_font(ctx: &Context) {
    static CJK_LOADED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
    if CJK_LOADED.swap(true, std::sync::atomic::Ordering::SeqCst) {
        return;
    }

    let mut fonts = FontDefinitions::default();
    let candidate_fonts = [
        r"C:\Windows\Fonts\segoeui.ttf",
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\tahoma.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/SFNS.ttf",
        "/Library/Fonts/Arial.ttf",
    ];

    for font_path in candidate_fonts {
        if let Ok(bytes) = std::fs::read(font_path) {
            fonts.font_data.insert(
                "vn_system_font".to_owned(),
                FontData::from_owned(bytes).into(),
            );
            if let Some(family) = fonts.families.get_mut(&FontFamily::Proportional) {
                family.insert(0, "vn_system_font".to_owned());
            }
            if let Some(family) = fonts.families.get_mut(&FontFamily::Monospace) {
                family.push("vn_system_font".to_owned());
            }
            break;
        }
    }

    let cjk_candidates = [
        r"C:\Windows\Fonts\ARIALUNI.TTF",
        r"C:\Windows\Fonts\malgun.ttf",
        r"C:\Windows\Fonts\msyh.ttf",
        r"C:\Windows\Fonts\simsun.ttc",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/Library/Fonts/Arial Unicode.ttf",
        "/System/Library/Fonts/PingFang.ttc",
    ];
    for cjk_path in cjk_candidates {
        if let Ok(bytes) = std::fs::read(cjk_path) {
            fonts.font_data.insert(
                "cjk_fallback_font".to_owned(),
                FontData::from_owned(bytes).into(),
            );
            if let Some(family) = fonts.families.get_mut(&FontFamily::Proportional) {
                let insert_idx = family.len().min(1);
                family.insert(insert_idx, "cjk_fallback_font".to_owned());
            }
            if let Some(family) = fonts.families.get_mut(&FontFamily::Monospace) {
                family.push("cjk_fallback_font".to_owned());
            }
            break;
        }
    }

    let mono_candidates = [
        r"C:\Windows\Fonts\consola.ttf",
        "/System/Library/Fonts/Supplemental/Courier New.ttf",
    ];
    for mono_path in mono_candidates {
        if let Ok(consolas) = std::fs::read(mono_path) {
            fonts
                .font_data
                .insert("vn_mono".to_owned(), FontData::from_owned(consolas).into());
            if let Some(family) = fonts.families.get_mut(&FontFamily::Monospace) {
                family.insert(0, "vn_mono".to_owned());
            }
            break;
        }
    }

    ctx.set_fonts(fonts);
}

fn configure_light_visuals(ctx: &Context) {
    let mut visuals = egui::Visuals::light();
    visuals.panel_fill = COLOR_CANVAS;
    visuals.window_fill = COLOR_TOP_BAR;
    visuals.override_text_color = Some(COLOR_TEXT_MAIN);
    visuals.widgets.noninteractive.bg_fill = COLOR_TOP_BAR;
    visuals.widgets.inactive.bg_fill = Color32::WHITE;
    visuals.widgets.inactive.bg_stroke = Stroke::new(1.0_f32, COLOR_BORDER);
    visuals.widgets.hovered.bg_fill = COLOR_ACCENT_LIGHT;
    visuals.widgets.hovered.bg_stroke = Stroke::new(1.0_f32, COLOR_ACCENT_GREEN);
    visuals.widgets.active.bg_fill = COLOR_ACCENT_LIGHT;
    visuals.selection.bg_fill = COLOR_ACCENT_LIGHT;
    visuals.selection.stroke = Stroke::new(1.0_f32, COLOR_ACCENT_GREEN);
    ctx.set_visuals(visuals);
}
