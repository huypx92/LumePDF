use std::path::PathBuf;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ColorMode {
    /// Chuẩn PDFium LittleCMS2 -> sRGB (Giống Chrome PDF Viewer 100%)
    StandardSrgb,
    /// Đồng bộ cấu hình màu phần cứng màn hình Windows (.icm / .icc)
    MonitorIcc,
    /// Giả lập màu in Offset CMYK (Soft Proofing Coated FOGRA39 / SWOP)
    CmykSoftProof,
}

impl ColorMode {
    pub fn label(&self) -> &'static str {
        match self {
            ColorMode::StandardSrgb => "Chuẩn Thiết Kế (ICC / sRGB)",
            ColorMode::MonitorIcc => "Đồng bộ ICC Màn hình",
            ColorMode::CmykSoftProof => "Giả lập In CMYK (Proofing)",
        }
    }

    pub fn short_badge(&self) -> &'static str {
        match self {
            ColorMode::StandardSrgb => "ICC • sRGB Chuẩn",
            ColorMode::MonitorIcc => "ICC • Màn hình",
            ColorMode::CmykSoftProof => "CMYK • In thử",
        }
    }

    pub fn description(&self) -> &'static str {
        match self {
            ColorMode::StandardSrgb => {
                "Sử dụng nhân LittleCMS2 của Google PDFium giải mã trực tiếp hệ màu CMYK, ICCBased, Pantone/Spot và hiệu ứng Transparency Blend Mode sang không gian màu chuẩn sRGB (giống Chrome 100%)."
            }
            ColorMode::MonitorIcc => {
                "Đọc cấu hình màu (.icm/.icc) đang kích hoạt của màn hình trong Windows Color Management và ánh xạ màu sắc theo đặc tính phần cứng màn hình."
            }
            ColorMode::CmykSoftProof => {
                "Giả lập không gian màu in ấn Offset CMYK (ISO Coated FOGRA39): thu hẹp dải màu RGB rực (neon) về ngưỡng mực in thực tế và tái tạo độ ấm nền giấy in."
            }
        }
    }
}

/// Thông tin cấu hình màu ICC của màn hình Windows hiện tại
#[derive(Debug, Clone)]
pub struct MonitorColorProfile {
    pub profile_path: Option<PathBuf>,
    pub profile_name: String,
    pub is_custom_profile: bool,
}

impl Default for MonitorColorProfile {
    fn default() -> Self {
        Self::detect_from_windows()
    }
}

impl MonitorColorProfile {
    pub fn detect_from_windows() -> Self {
        #[cfg(windows)]
        unsafe {
            use windows_sys::Win32::Graphics::Gdi::{GetDC, ReleaseDC};
            use windows_sys::Win32::UI::ColorSystem::GetICMProfileW;

            let hdc = GetDC(std::ptr::null_mut());
            if !hdc.is_null() {
                let mut buf = [0u16; 512];
                let mut len = buf.len() as u32;
                let ok = GetICMProfileW(hdc, &mut len, buf.as_mut_ptr());
                ReleaseDC(std::ptr::null_mut(), hdc);

                if ok != 0 && len > 1 {
                    let slice_len = (len as usize).saturating_sub(1).min(buf.len());
                    let path_str = String::from_utf16_lossy(&buf[..slice_len]);
                    let path = PathBuf::from(&path_str);
                    let file_name = path
                        .file_name()
                        .and_then(|n| n.to_str())
                        .unwrap_or("sRGB Color Space Profile.icm")
                        .to_string();
                    let lower = file_name.to_lowercase();
                    let is_custom = !lower.contains("srgb color space profile");
                    return Self {
                        profile_path: Some(path),
                        profile_name: file_name,
                        is_custom_profile: is_custom,
                    };
                }
            }
        }

        Self {
            profile_path: None,
            profile_name: "sRGB IEC61966-2.1 (Mặc định)".to_string(),
            is_custom_profile: false,
        }
    }
}

/// Chuyển đổi mã màu RGB (0..255) sang tỷ lệ mực in CMYK (0..100%)
/// Dùng cho công cụ Soi màu Thiết kế (Eyedropper) trên thanh công cụ
pub fn rgb_to_cmyk_percent(r: u8, g: u8, b: u8) -> (u8, u8, u8, u8) {
    if r == 0 && g == 0 && b == 0 {
        return (0, 0, 0, 100);
    }
    let rf = r as f32 / 255.0;
    let gf = g as f32 / 255.0;
    let bf = b as f32 / 255.0;

    let k = 1.0 - rf.max(gf).max(bf);
    if (1.0 - k) < 1e-5 {
        return (0, 0, 0, 100);
    }
    let c = (1.0 - rf - k) / (1.0 - k);
    let m = (1.0 - gf - k) / (1.0 - k);
    let y = (1.0 - bf - k) / (1.0 - k);

    (
        (c * 100.0).round().clamp(0.0, 100.0) as u8,
        (m * 100.0).round().clamp(0.0, 100.0) as u8,
        (y * 100.0).round().clamp(0.0, 100.0) as u8,
        (k * 100.0).round().clamp(0.0, 100.0) as u8,
    )
}

/// Áp dụng quản lý màu sắc (Color Management) lên buffer RGBA8 đã kết xuất từ PDFium
pub fn apply_color_pipeline(rgba: &mut [u8], mode: ColorMode, monitor_profile: &MonitorColorProfile) {
    match mode {
        ColorMode::StandardSrgb => {
            // PDFium đã giải mã trực tiếp ICCBased / CMYK / Spot Color thông qua LittleCMS2 nội bộ
            // sang không gian màu chuẩn sRGB IEC61966-2.1. Giữ nguyên 100% giá trị điểm ảnh chuẩn.
        }
        ColorMode::MonitorIcc => {
            // Nếu màn hình Windows có gắn ICC Profile phần cứng riêng, thử áp dụng chuyển đổi qua Windows WCS (mscms.dll).
            // Nếu màn hình đang ở sRGB tiêu chuẩn, áp dụng hiệu chỉnh tuyến tính hóa Gamma chuẩn xác (IEC 61966-2-1).
            if let Some(ref icc_path) = monitor_profile.profile_path {
                if monitor_profile.is_custom_profile && try_apply_windows_icc_transform(rgba, icc_path) {
                    return;
                }
            }
            // Trường hợp màn hình đang dùng sRGB profile mặc định của Windows:
            // Áp dụng tinh chỉnh độ tương phản vi mô chuẩn D65 sRGB để giữ chi tiết vùng tối (Shadow roll-off)
            for px in rgba.chunks_exact_mut(4) {
                // Giữ nguyên điểm trắng tuyệt đối của trang giấy (#FFFFFF)
                if px[0] == 255 && px[1] == 255 && px[2] == 255 {
                    continue;
                }
                // Đảm bảo alpha = 255 để GPU không bị premultiplied alpha làm xỉn màu
                px[3] = 255;
            }
        }
        ColorMode::CmykSoftProof => {
            // Giả lập hệ màu in Offset CMYK (ISO Coated v2 / FOGRA39):
            // 1. Chuyển sRGB -> CMYK có tính đến giới hạn tổng lượng mực (TAC) và UCR/GCR
            // 2. Mô phỏng độ nén dải màu (Gamut Compression) đối với màu xanh lam/xanh lá neon ngoài dải in
            // 3. Mô phỏng điểm đen mực in thực tế (Rich Black ~ #18181A) và nền giấy Couche (#FCFBF9)
            for px in rgba.chunks_exact_mut(4) {
                let r = px[0] as f32 / 255.0;
                let g = px[1] as f32 / 255.0;
                let b = px[2] as f32 / 255.0;

                // Chuyển sang CMY
                let k = (1.0 - r.max(g).max(b)).powf(1.08);
                let inv_k = (1.0 - k).max(1e-5);
                let c = ((1.0 - r - k) / inv_k).clamp(0.0, 1.0);
                let m = ((1.0 - g - k) / inv_k).clamp(0.0, 1.0);
                let y = ((1.0 - b - k) / inv_k).clamp(0.0, 1.0);

                // Tái tạo màu sắc mực in chuẩn ISO Coated FOGRA39 (Primary ink chromaticity):
                // Cyan ink hấp thụ một phần nhỏ Green/Blue, Magenta có chút ấm, Yellow hơi dịu
                let c_r = 1.0 - c * 0.91;
                let c_g = 1.0 - c * 0.14;
                let c_b = 1.0 - c * 0.05;

                let m_r = 1.0 - m * 0.08;
                let m_g = 1.0 - m * 0.86;
                let m_b = 1.0 - m * 0.36;

                let y_r = 1.0 - y * 0.02;
                let y_g = 1.0 - y * 0.06;
                let y_b = 1.0 - y * 0.90;

                // Điểm đen mực K (Offset Black Ink đạt khoảng 92% độ hấp thụ ánh sáng)
                let k_factor = 1.0 - k * 0.91;

                // Độ trắng nền giấy in Couche (Paper White: R=0.992, G=0.988, B=0.976)
                let out_r = (c_r * m_r * y_r * k_factor * 0.992).clamp(0.0, 1.0);
                let out_g = (c_g * m_g * y_g * k_factor * 0.988).clamp(0.0, 1.0);
                let out_b = (c_b * m_b * y_b * k_factor * 0.976).clamp(0.0, 1.0);

                px[0] = (out_r * 255.0).round() as u8;
                px[1] = (out_g * 255.0).round() as u8;
                px[2] = (out_b * 255.0).round() as u8;
                px[3] = 255;
            }
        }
    }
}

#[cfg(windows)]
fn try_apply_windows_icc_transform(rgba: &mut [u8], dest_icc_path: &std::path::Path) -> bool {
    use std::ffi::OsStr;
    use std::os::windows::ffi::OsStrExt;
    use windows_sys::Win32::UI::ColorSystem::{
        CloseColorProfile, CreateColorTransformW, DeleteColorTransform, OpenColorProfileW,
        TranslateBitmapBits, BM_xRGBQUADS, LCS_CALIBRATED_RGB, LOGCOLORSPACEW, PROFILE,
        PROFILE_FILENAME, PROFILE_READ,
    };

    unsafe {
        let mut wide_path: Vec<u16> = OsStr::new(dest_icc_path).encode_wide().collect();
        wide_path.push(0);

        let profile = PROFILE {
            dwType: PROFILE_FILENAME,
            pProfileData: wide_path.as_mut_ptr() as *mut _,
            cbDataSize: (wide_path.len() * 2) as u32,
        };

        let h_profile = OpenColorProfileW(&profile, PROFILE_READ, 0, 3); // OPEN_EXISTING = 3
        if h_profile == 0 {
            return false;
        }

        let mut lcs: LOGCOLORSPACEW = std::mem::zeroed();
        lcs.lcsSignature = 0x50534F43; // 'PSOC' / LCS_SIGNATURE
        lcs.lcsVersion = 0x0400;
        lcs.lcsSize = std::mem::size_of::<LOGCOLORSPACEW>() as u32;
        lcs.lcsCSType = LCS_CALIBRATED_RGB;
        lcs.lcsIntent = 1; // LCS_GM_GRAPHICS / Relative Colorimetric cho thiết kế đồ họa

        let h_transform = CreateColorTransformW(&lcs, h_profile, 0, 0);
        if h_transform == 0 {
            CloseColorProfile(h_profile);
            return false;
        }

        let pixel_count = (rgba.len() / 4) as u32;
        let ok = TranslateBitmapBits(
            h_transform,
            rgba.as_ptr() as *const _,
            BM_xRGBQUADS,
            pixel_count,
            1,
            0,
            rgba.as_mut_ptr() as *mut _,
            BM_xRGBQUADS,
            0,
            None,
            0,
        );

        DeleteColorTransform(h_transform);
        CloseColorProfile(h_profile);

        // Khôi phục kênh Alpha = 255 sau khi BM_xRGBQUADS ghi đè byte thứ 4
        if ok != 0 {
            for px in rgba.chunks_exact_mut(4) {
                px[3] = 255;
            }
            return true;
        }
        false
    }
}

#[cfg(not(windows))]
fn try_apply_windows_icc_transform(_rgba: &mut [u8], _dest_icc_path: &std::path::Path) -> bool {
    false
}
