use crate::color_cms::{apply_color_pipeline, ColorMode, MonitorColorProfile};
use libloading::{Library, Symbol};
use lru::LruCache;
use memmap2::Mmap;
use std::ffi::{c_int, c_ulong, c_void};
use std::fs::File;
use std::num::NonZeroUsize;
use std::path::{Path, PathBuf};
use std::sync::Arc;

// Định nghĩa các kiểu con trỏ hàm C chuẩn của Google PDFium
type FpdfDocument = *mut c_void;
type FpdfPage = *mut c_void;
type FpdfBitmap = *mut c_void;

const FPDF_ANNOT: c_int = 0x01;
const FPDF_LCD_TEXT: c_int = 0x02;
const FPDF_REVERSE_BYTE_ORDER: c_int = 0x10;
const FPDF_RENDER_LIMITEDIMAGECACHE: c_int = 0x200;
const FPDF_RENDER_NO_SMOOTHIMAGE: c_int = 0x2000;
const FPDFBITMAP_BGRA: c_int = 4;

type FnInitLibrary = unsafe extern "C" fn();
type FnDestroyLibrary = unsafe extern "C" fn();
type FnLoadMemDocument64 =
    unsafe extern "C" fn(data_buf: *const c_void, size: usize, password: *const i8) -> FpdfDocument;
type FnLoadMemDocument =
    unsafe extern "C" fn(data_buf: *const c_void, size: c_int, password: *const i8) -> FpdfDocument;
type FnCloseDocument = unsafe extern "C" fn(document: FpdfDocument);
type FnGetPageCount = unsafe extern "C" fn(document: FpdfDocument) -> c_int;
type FnGetPageSizeByIndexF =
    unsafe extern "C" fn(document: FpdfDocument, page_index: c_int, size: *mut FsSizeF) -> c_int;
type FnGetPageSizeByIndex = unsafe extern "C" fn(
    document: FpdfDocument,
    page_index: c_int,
    width: *mut f64,
    height: *mut f64,
) -> c_int;
type FnLoadPage = unsafe extern "C" fn(document: FpdfDocument, page_index: c_int) -> FpdfPage;
type FnClosePage = unsafe extern "C" fn(page: FpdfPage);
type FnBitmapCreateEx = unsafe extern "C" fn(
    width: c_int,
    height: c_int,
    format: c_int,
    first_scan: *mut c_void,
    stride: c_int,
) -> FpdfBitmap;
type FnBitmapFillRect = unsafe extern "C" fn(
    bitmap: FpdfBitmap,
    left: c_int,
    top: c_int,
    width: c_int,
    height: c_int,
    color: c_ulong,
);
type FnBitmapDestroy = unsafe extern "C" fn(bitmap: FpdfBitmap);
type FnRenderPageBitmap = unsafe extern "C" fn(
    bitmap: FpdfBitmap,
    page: FpdfPage,
    start_x: c_int,
    start_y: c_int,
    size_x: c_int,
    size_y: c_int,
    rotate: c_int,
    flags: c_int,
);
type FnGetLastError = unsafe extern "C" fn() -> c_ulong;

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
struct FsSizeF {
    width: f32,
    height: f32,
}

#[derive(Debug, Clone, Copy)]
pub struct PageDimension {
    pub width_pt: f32,
    pub height_pt: f32,
}

impl PageDimension {
    pub fn aspect_ratio(&self, rotation_steps: i32) -> f32 {
        let (w, h) = self.rotated_size(rotation_steps);
        if h <= 0.1 {
            1.0 / 1.4142
        } else {
            w / h
        }
    }

    pub fn rotated_size(&self, rotation_steps: i32) -> (f32, f32) {
        if rotation_steps.rem_euclid(2) == 1 {
            (self.height_pt, self.width_pt)
        } else {
            (self.width_pt, self.height_pt)
        }
    }
}

/// Thông tin hệ màu phát hiện bên trong file PDF thiết kế
#[derive(Debug, Clone, Default)]
pub struct PdfColorMetadata {
    pub has_cmyk: bool,
    pub has_icc_profile: bool,
    pub has_spot_pantone: bool,
    pub has_output_intent: bool,
    pub has_transparency_group: bool,
}

impl PdfColorMetadata {
    pub fn summary_badge(&self) -> String {
        let mut tags = Vec::new();
        if self.has_cmyk {
            tags.push("CMYK");
        } else {
            tags.push("RGB");
        }
        if self.has_icc_profile || self.has_output_intent {
            tags.push("ICC");
        }
        if self.has_spot_pantone {
            tags.push("Spot/Pantone");
        }
        tags.join(" + ")
    }
}

pub struct PdfiumLibrary {
    _lib: Library,
    f_destroy_library: FnDestroyLibrary,
    f_load_mem_doc64: Option<FnLoadMemDocument64>,
    f_load_mem_doc: FnLoadMemDocument,
    f_close_doc: FnCloseDocument,
    f_get_page_count: FnGetPageCount,
    f_get_page_size_f: Option<FnGetPageSizeByIndexF>,
    f_get_page_size: FnGetPageSizeByIndex,
    f_load_page: FnLoadPage,
    f_close_page: FnClosePage,
    f_bitmap_create_ex: FnBitmapCreateEx,
    f_bitmap_fill_rect: FnBitmapFillRect,
    f_bitmap_destroy: FnBitmapDestroy,
    f_render_page_bitmap: FnRenderPageBitmap,
    f_get_last_error: FnGetLastError,
}

unsafe impl Send for PdfiumLibrary {}
unsafe impl Sync for PdfiumLibrary {}

impl PdfiumLibrary {
    pub fn load() -> Result<Arc<Self>, String> {
        let candidates = Self::candidate_dll_paths();
        let mut last_err = String::new();

        for path in &candidates {
            if !path.exists() {
                continue;
            }
            unsafe {
                match Library::new(path) {
                    Ok(lib) => {
                        let f_init: Symbol<FnInitLibrary> = lib
                            .get(b"FPDF_InitLibrary\0")
                            .map_err(|e| format!("Thiếu FPDF_InitLibrary: {e}"))?;
                        f_init();

                        let f_destroy_library = *lib
                            .get::<FnDestroyLibrary>(b"FPDF_DestroyLibrary\0")
                            .map_err(|e| e.to_string())?;
                        let f_load_mem_doc64 = lib
                            .get::<FnLoadMemDocument64>(b"FPDF_LoadMemDocument64\0")
                            .ok()
                            .map(|s| *s);
                        let f_load_mem_doc = *lib
                            .get::<FnLoadMemDocument>(b"FPDF_LoadMemDocument\0")
                            .map_err(|e| e.to_string())?;
                        let f_close_doc = *lib
                            .get::<FnCloseDocument>(b"FPDF_CloseDocument\0")
                            .map_err(|e| e.to_string())?;
                        let f_get_page_count = *lib
                            .get::<FnGetPageCount>(b"FPDF_GetPageCount\0")
                            .map_err(|e| e.to_string())?;
                        let f_get_page_size_f = lib
                            .get::<FnGetPageSizeByIndexF>(b"FPDF_GetPageSizeByIndexF\0")
                            .ok()
                            .map(|s| *s);
                        let f_get_page_size = *lib
                            .get::<FnGetPageSizeByIndex>(b"FPDF_GetPageSizeByIndex\0")
                            .map_err(|e| e.to_string())?;
                        let f_load_page = *lib
                            .get::<FnLoadPage>(b"FPDF_LoadPage\0")
                            .map_err(|e| e.to_string())?;
                        let f_close_page = *lib
                            .get::<FnClosePage>(b"FPDF_ClosePage\0")
                            .map_err(|e| e.to_string())?;
                        let f_bitmap_create_ex = *lib
                            .get::<FnBitmapCreateEx>(b"FPDFBitmap_CreateEx\0")
                            .map_err(|e| e.to_string())?;
                        let f_bitmap_fill_rect = *lib
                            .get::<FnBitmapFillRect>(b"FPDFBitmap_FillRect\0")
                            .map_err(|e| e.to_string())?;
                        let f_bitmap_destroy = *lib
                            .get::<FnBitmapDestroy>(b"FPDFBitmap_Destroy\0")
                            .map_err(|e| e.to_string())?;
                        let f_render_page_bitmap = *lib
                            .get::<FnRenderPageBitmap>(b"FPDF_RenderPageBitmap\0")
                            .map_err(|e| e.to_string())?;
                        let f_get_last_error = *lib
                            .get::<FnGetLastError>(b"FPDF_GetLastError\0")
                            .map_err(|e| e.to_string())?;

                        return Ok(Arc::new(Self {
                            _lib: lib,
                            f_destroy_library,
                            f_load_mem_doc64,
                            f_load_mem_doc,
                            f_close_doc,
                            f_get_page_count,
                            f_get_page_size_f,
                            f_get_page_size,
                            f_load_page,
                            f_close_page,
                            f_bitmap_create_ex,
                            f_bitmap_fill_rect,
                            f_bitmap_destroy,
                            f_render_page_bitmap,
                            f_get_last_error,
                        }));
                    }
                    Err(e) => {
                        last_err = format!("Không thể nạp {:?}: {e}", path);
                    }
                }
            }
        }

        Err(format!(
            "Không tìm thấy thư viện nhân Google PDFium (pdfium.dll). Đã kiểm tra: {:?}. Lỗi cuối: {}",
            candidates, last_err
        ))
    }

    fn candidate_dll_paths() -> Vec<PathBuf> {
        #[cfg(target_os = "macos")]
        let lib_name = "libpdfium.dylib";
        #[cfg(all(unix, not(target_os = "macos")))]
        let lib_name = "libpdfium.so";
        #[cfg(windows)]
        let lib_name = "pdfium.dll";

        let mut paths = Vec::new();
        if let Ok(exe_path) = std::env::current_exe() {
            if let Some(exe_dir) = exe_path.parent() {
                paths.push(exe_dir.join(lib_name));
                paths.push(exe_dir.join("vendor").join(lib_name));
                if let Some(parent) = exe_dir.parent() {
                    paths.push(parent.join(lib_name));
                    paths.push(parent.join("Frameworks").join(lib_name));
                    paths.push(parent.join("Resources").join(lib_name));
                    paths.push(parent.join("vendor").join(lib_name));
                    if let Some(grand) = parent.parent() {
                        paths.push(grand.join("vendor").join(lib_name));
                    }
                }
            }
        }
        if let Ok(cwd) = std::env::current_dir() {
            paths.push(cwd.join(lib_name));
            paths.push(cwd.join("vendor").join(lib_name));
        }
        #[cfg(windows)]
        paths.push(PathBuf::from(r"d:\des\lumepdf\vendor\pdfium.dll"));
        #[cfg(target_os = "macos")]
        {
            paths.push(PathBuf::from("/Applications/LumePDF.app/Contents/MacOS/libpdfium.dylib"));
            paths.push(PathBuf::from("/Applications/LumePDF.app/Contents/Frameworks/libpdfium.dylib"));
        }
        paths
    }
}

impl Drop for PdfiumLibrary {
    fn drop(&mut self) {
        unsafe {
            (self.f_destroy_library)();
        }
    }
}

/// Tài liệu PDF đã được ánh xạ bộ nhớ (Memory-Mapped) kèm bộ đệm trang FPDF_PAGE (CPDF_PageRenderCache)
pub struct PdfDocumentHandle {
    lib: Arc<PdfiumLibrary>,
    doc: FpdfDocument,
    _mmap: Mmap,
    loaded_pages: LruCache<usize, FpdfPage>,
    pub file_size_bytes: u64,
    pub page_dimensions: Vec<PageDimension>,
    pub color_meta: PdfColorMetadata,
}

unsafe impl Send for PdfDocumentHandle {}

impl PdfDocumentHandle {
    pub fn open(lib: Arc<PdfiumLibrary>, path: &Path) -> Result<Self, String> {
        let file = File::open(path)
            .map_err(|e| format!("Không thể mở file '{}': {e}", path.display()))?;
        let file_size_bytes = file.metadata().map(|m| m.len()).unwrap_or(0);
        if file_size_bytes == 0 {
            return Err("File PDF trống (0 byte).".to_string());
        }

        let mmap = unsafe {
            Mmap::map(&file)
                .map_err(|e| format!("Không thể ánh xạ bộ nhớ cho file PDF: {e}"))?
        };

        let doc = unsafe {
            if let Some(load64) = lib.f_load_mem_doc64 {
                load64(
                    mmap.as_ptr() as *const c_void,
                    mmap.len(),
                    std::ptr::null(),
                )
            } else {
                let len_i32 = i32::try_from(mmap.len())
                    .map_err(|_| "File PDF vượt quá 2GB, cần FPDF_LoadMemDocument64")?;
                (lib.f_load_mem_doc)(
                    mmap.as_ptr() as *const c_void,
                    len_i32,
                    std::ptr::null(),
                )
            }
        };

        if doc.is_null() {
            let err_code = unsafe { (lib.f_get_last_error)() };
            let reason = match err_code {
                2 => "File không tồn tại hoặc không thể đọc",
                3 => "Định dạng PDF bị lỗi hoặc không hợp lệ",
                4 => "File PDF được đặt mật khẩu bảo vệ",
                5 => "Cơ chế bảo mật PDF không hỗ trợ",
                _ => "Không thể giải mã cấu trúc PDF",
            };
            return Err(format!("{reason} (Mã lỗi PDFium: {err_code})"));
        }

        let page_count = unsafe { (lib.f_get_page_count)(doc) };
        if page_count <= 0 {
            unsafe { (lib.f_close_doc)(doc) };
            return Err("File PDF không có trang nào.".to_string());
        }

        let mut page_dimensions = Vec::with_capacity(page_count as usize);
        for idx in 0..page_count {
            let dim = unsafe {
                if let Some(get_size_f) = lib.f_get_page_size_f {
                    let mut sz = FsSizeF::default();
                    if get_size_f(doc, idx, &mut sz) != 0 && sz.width > 1.0 && sz.height > 1.0 {
                        PageDimension {
                            width_pt: sz.width,
                            height_pt: sz.height,
                        }
                    } else {
                        PageDimension {
                            width_pt: 595.0,
                            height_pt: 842.0,
                        }
                    }
                } else {
                    let mut w = 0.0f64;
                    let mut h = 0.0f64;
                    if (lib.f_get_page_size)(doc, idx, &mut w, &mut h) != 0 && w > 1.0 && h > 1.0 {
                        PageDimension {
                            width_pt: w as f32,
                            height_pt: h as f32,
                        }
                    } else {
                        PageDimension {
                            width_pt: 595.0,
                            height_pt: 842.0,
                        }
                    }
                }
            };
            page_dimensions.push(dim);
        }

        let color_meta = Self::scan_color_metadata(&mmap);

        Ok(Self {
            lib,
            doc,
            _mmap: mmap,
            loaded_pages: LruCache::new(NonZeroUsize::new(24).unwrap()),
            file_size_bytes,
            page_dimensions,
            color_meta,
        })
    }

    /// Quét siêu tốc phần đầu và phần cuối của file PDF (< 1ms) để nhận diện không gian màu thiết kế
    fn scan_color_metadata(data: &[u8]) -> PdfColorMetadata {
        let mut meta = PdfColorMetadata::default();
        let head_len = data.len().min(2 * 1024 * 1024);
        let head = &data[..head_len];

        meta.has_cmyk = find_subslice(head, b"/DeviceCMYK") || find_subslice(head, b"/CMYK");
        meta.has_icc_profile = find_subslice(head, b"/ICCBased");
        meta.has_spot_pantone =
            find_subslice(head, b"/Separation") || find_subslice(head, b"/DeviceN");
        meta.has_output_intent = find_subslice(head, b"/OutputIntents");
        meta.has_transparency_group = find_subslice(head, b"/Transparency");

        if data.len() > head_len {
            let tail_start = data.len().saturating_sub(512 * 1024);
            let tail = &data[tail_start..];
            meta.has_cmyk |= find_subslice(tail, b"/DeviceCMYK");
            meta.has_icc_profile |= find_subslice(tail, b"/ICCBased");
            meta.has_spot_pantone |=
                find_subslice(tail, b"/Separation") || find_subslice(tail, b"/DeviceN");
            meta.has_output_intent |= find_subslice(tail, b"/OutputIntents");
        }

        meta
    }

    /// Lấy FPDF_PAGE từ bộ đệm LRU để giữ nguyên CPDF_PageRenderCache (không phải giải mã lại ảnh CMYK khi Zoom/Thumbnail)
    fn get_or_load_page(&mut self, page_index: usize) -> Result<FpdfPage, String> {
        if let Some(&page) = self.loaded_pages.get(&page_index) {
            return Ok(page);
        }

        let page = unsafe { (self.lib.f_load_page)(self.doc, page_index as c_int) };
        if page.is_null() {
            return Err(format!("Không thể tải trang {}", page_index + 1));
        }

        if self.loaded_pages.len() >= self.loaded_pages.cap().get() {
            if let Some((_, evicted_page)) = self.loaded_pages.pop_lru() {
                if !evicted_page.is_null() {
                    unsafe {
                        (self.lib.f_close_page)(evicted_page);
                    }
                }
            }
        }

        self.loaded_pages.put(page_index, page);
        Ok(page)
    }

    /// Kết xuất 1 trang PDF trực tiếp (Zero-Copy) ra mảng pixel RGBA8 chuẩn màu thiết kế
    pub fn render_page(
        &mut self,
        page_index: usize,
        width_px: u32,
        height_px: u32,
        rotation_steps: i32,
        color_mode: ColorMode,
        monitor_profile: &MonitorColorProfile,
    ) -> Result<RenderedBitmap, String> {
        self.render_page_ex(
            page_index,
            width_px,
            height_px,
            rotation_steps,
            color_mode,
            monitor_profile,
            false,
        )
    }

    pub fn render_page_ex(
        &mut self,
        page_index: usize,
        width_px: u32,
        height_px: u32,
        rotation_steps: i32,
        color_mode: ColorMode,
        monitor_profile: &MonitorColorProfile,
        fast_thumbnail: bool,
    ) -> Result<RenderedBitmap, String> {
        let width_px = width_px.clamp(16, 4096) as c_int;
        let height_px = height_px.clamp(16, 4096) as c_int;
        let rotate = rotation_steps.rem_euclid(4) as c_int;

        let page = self.get_or_load_page(page_index)?;
        let w_usize = width_px as usize;
        let h_usize = height_px as usize;
        let stride = width_px * 4;
        let mut rgba = vec![255u8; w_usize * h_usize * 4];

        unsafe {
            // Tạo Bitmap trỏ trực tiếp vào bộ nhớ của Vec<u8> (Zero-Copy, tiết kiệm 20MB copy mỗi lần vẽ)
            let bitmap = (self.lib.f_bitmap_create_ex)(
                width_px,
                height_px,
                FPDFBITMAP_BGRA,
                rgba.as_mut_ptr() as *mut c_void,
                stride,
            );

            if bitmap.is_null() {
                return Err("Không đủ bộ nhớ để tạo Bitmap kết xuất trang.".to_string());
            }

            // Lấp nền giấy trắng tuyệt đối (0xFFFFFFFF) để hòa trộn chuẩn xác các lớp Transparency Blend Mode
            (self.lib.f_bitmap_fill_rect)(bitmap, 0, 0, width_px, height_px, 0xFFFFFFFF);

            // Với Thumbnail nhỏ hoặc bản xem trước tức thì (fast_thumbnail): tắt nội suy bicubic nặng và LCD subpixel
            // để tăng tốc độ kết xuất lên 3-5 lần. Với trang chính: bật đầy đủ FPDF_LCD_TEXT + FPDF_ANNOT.
            let flags = if fast_thumbnail {
                FPDF_REVERSE_BYTE_ORDER
                    | FPDF_RENDER_LIMITEDIMAGECACHE
                    | FPDF_RENDER_NO_SMOOTHIMAGE
            } else {
                FPDF_ANNOT | FPDF_REVERSE_BYTE_ORDER | FPDF_LCD_TEXT
            };

            (self.lib.f_render_page_bitmap)(
                bitmap, page, 0, 0, width_px, height_px, rotate, flags,
            );

            (self.lib.f_bitmap_destroy)(bitmap);
        }

        // Áp dụng pipeline quản lý màu sắc (ICC / Màn hình / CMYK Soft-Proof)
        apply_color_pipeline(&mut rgba, color_mode, monitor_profile);

        Ok(RenderedBitmap {
            width: w_usize,
            height: h_usize,
            rgba,
        })
    }
}

impl Drop for PdfDocumentHandle {
    fn drop(&mut self) {
        while let Some((_, page)) = self.loaded_pages.pop_lru() {
            if !page.is_null() {
                unsafe {
                    (self.lib.f_close_page)(page);
                }
            }
        }
        if !self.doc.is_null() {
            unsafe {
                (self.lib.f_close_doc)(self.doc);
            }
        }
    }
}

pub struct RenderedBitmap {
    pub width: usize,
    pub height: usize,
    pub rgba: Vec<u8>,
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() || haystack.len() < needle.len() {
        return false;
    }
    haystack
        .windows(needle.len())
        .any(|window| window == needle)
}
