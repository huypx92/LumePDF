use semver::Version;
use serde::Deserialize;
use std::sync::mpsc::{self, Receiver, TryRecvError};
use std::time::Duration;
use ureq::tls::{RootCerts, TlsConfig, TlsProvider};

pub const CURRENT_VERSION: &str = env!("CARGO_PKG_VERSION");
pub const RELEASES_URL: &str = "https://github.com/huypx92/LumePDF/releases/latest";
const RELEASE_API: &str = "https://api.github.com/repos/huypx92/LumePDF/releases/latest";

#[derive(Default)]
pub enum UpdateStatus {
    #[default]
    Idle,
    Checking,
    Current,
    Available(Version),
    Failed,
}

#[derive(Default)]
pub struct UpdateCheck {
    pub status: UpdateStatus,
    result: Option<Receiver<UpdateStatus>>,
}

impl UpdateCheck {
    pub fn start(&mut self, ctx: &egui::Context) {
        if self.result.is_some() {
            return;
        }

        let (sender, receiver) = mpsc::channel();
        let ctx = ctx.clone();
        let worker = std::thread::Builder::new().name("lumepdf-update-check".into());
        match worker.spawn(move || {
            let status = match fetch_latest_release() {
                Ok(Some(version)) => UpdateStatus::Available(version),
                Ok(None) => UpdateStatus::Current,
                Err(error) => {
                    eprintln!("LumePDF update check failed: {error}");
                    UpdateStatus::Failed
                }
            };
            let _ = sender.send(status);
            ctx.request_repaint();
        }) {
            Ok(_) => {
                self.status = UpdateStatus::Checking;
                self.result = Some(receiver);
            }
            Err(_) => self.status = UpdateStatus::Failed,
        }
    }

    pub fn poll(&mut self) -> bool {
        let Some(receiver) = &self.result else {
            return false;
        };
        self.status = match receiver.try_recv() {
            Ok(status) => status,
            Err(TryRecvError::Disconnected) => UpdateStatus::Failed,
            Err(TryRecvError::Empty) => return false,
        };
        self.result = None;
        true
    }
}

#[derive(Deserialize)]
struct Release {
    tag_name: String,
    draft: bool,
    prerelease: bool,
}

fn fetch_latest_release() -> Result<Option<Version>, Box<dyn std::error::Error>> {
    let agent = ureq::Agent::config_builder()
        .https_only(true)
        .max_redirects(0)
        .timeout_global(Some(Duration::from_secs(8)))
        .tls_config(
            TlsConfig::builder()
                .provider(TlsProvider::NativeTls)
                .root_certs(RootCerts::PlatformVerifier)
                .build(),
        )
        .build()
        .new_agent();
    let mut response = agent
        .get(RELEASE_API)
        .header("Accept", "application/vnd.github+json")
        .header("User-Agent", concat!("LumePDF/", env!("CARGO_PKG_VERSION")))
        .call()?;
    let release: Release = response.body_mut().with_config().limit(1024 * 1024).read_json()?;
    Ok(newer_release(&release, &Version::parse(CURRENT_VERSION)?)?)
}

fn newer_release(release: &Release, current: &Version) -> Result<Option<Version>, semver::Error> {
    if release.draft || release.prerelease {
        return Ok(None);
    }
    let tag = release.tag_name.strip_prefix('v').unwrap_or(&release.tag_name);
    let version = Version::parse(tag)?;
    Ok((version.pre.is_empty() && version.cmp_precedence(current).is_gt()).then_some(version))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_newer_stable_releases_trigger_an_update() {
        let current = Version::parse("1.2.3").unwrap();
        for (tag, draft, prerelease, expected) in [
            ("v1.10.0", false, false, true),
            ("2.0.0", false, false, true),
            ("v1.2.3", false, false, false),
            ("v1.2.3+repack", false, false, false),
            ("v1.1.9", false, false, false),
            ("v1.2.4-beta.1", false, false, false),
            ("v1.2.4", true, false, false),
            ("v1.2.4", false, true, false),
        ] {
            let release = Release { tag_name: tag.into(), draft, prerelease };
            assert_eq!(newer_release(&release, &current).unwrap().is_some(), expected, "{tag}");
        }
        let invalid = Release { tag_name: "latest".into(), draft: false, prerelease: false };
        assert!(newer_release(&invalid, &current).is_err());
    }

    #[test]
    #[ignore = "requires Internet access to the public GitHub API"]
    fn live_github_release_check() {
        fetch_latest_release().unwrap();
    }
}
