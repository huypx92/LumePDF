use crate::color_cms::{ColorMode, MonitorColorProfile};
use crate::pdf_engine::{
    PageDimension, PdfColorMetadata, PdfDocumentHandle, PdfiumLibrary, RenderedBitmap,
};
use crossbeam_channel::{unbounded, Receiver, Sender};
use image::codecs::jpeg::JpegEncoder;
use image::ExtendedColorType;
use std::borrow::Cow;
use std::collections::HashMap;
use std::fs::File;
use std::io::BufWriter;
use std::path::PathBuf;
use std::sync::Arc;
use std::thread;
use std::time::Instant;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct PageCacheKey {
    pub doc_id: u64,
    pub page_index: usize,
    pub width_px: u32,
    pub height_px: u32,
    pub rotation_steps: i32,
    pub color_mode: ColorMode,
    pub is_thumbnail: bool,
}

#[derive(Debug, Clone)]
pub struct RenderTask {
    pub key: PageCacheKey,
    pub priority: u8, // 0 = Trang chính đang nhìn, 1 = Trang lân cận, 2 = Thumbnail
}

pub enum WorkerCommand {
    OpenDocument {
        doc_id: u64,
        path: PathBuf,
    },
    CloseDocument {
        doc_id: u64,
    },
    SyncRenderQueue {
        tasks: Vec<RenderTask>,
    },
    RenderCoverPreview {
        path: PathBuf,
        max_side_px: u32,
    },
    CopyPageToClipboard {
        doc_id: u64,
        page_index: usize,
        rotation_steps: i32,
        color_mode: ColorMode,
    },
    ExportPageToImage {
        doc_id: u64,
        page_index: usize,
        rotation_steps: i32,
        color_mode: ColorMode,
        dest_path: PathBuf,
    },
}

pub enum WorkerEvent {
    EngineReady {
        monitor_profile: MonitorColorProfile,
    },
    EngineError(String),
    DocumentOpened {
        doc_id: u64,
        file_size_bytes: u64,
        page_dimensions: Vec<PageDimension>,
        color_meta: PdfColorMetadata,
        open_ms: f64,
    },
    DocumentOpenFailed {
        doc_id: u64,
        error: String,
    },
    PageRendered {
        key: PageCacheKey,
        bitmap: RenderedBitmap,
        render_ms: f64,
    },
    CoverPreviewRendered {
        path: PathBuf,
        bitmap: RenderedBitmap,
        page_count: usize,
        file_size_bytes: u64,
    },
    ActionToast {
        message: String,
        is_error: bool,
    },
}

pub struct RenderWorkerHandle {
    pub cmd_tx: Sender<WorkerCommand>,
    pub evt_rx: Receiver<WorkerEvent>,
}

impl RenderWorkerHandle {
    pub fn spawn(egui_ctx: egui::Context) -> Self {
        let (cmd_tx, cmd_rx) = unbounded::<WorkerCommand>();
        let (evt_tx, evt_rx) = unbounded::<WorkerEvent>();

        thread::Builder::new()
            .name("lumepdf-render-worker".to_string())
            .spawn(move || {
                worker_loop(cmd_rx, evt_tx, egui_ctx);
            })
            .expect("Không thể khởi tạo luồng kết xuất PDF");

        Self { cmd_tx, evt_rx }
    }
}

fn worker_loop(
    cmd_rx: Receiver<WorkerCommand>,
    evt_tx: Sender<WorkerEvent>,
    egui_ctx: egui::Context,
) {
    let monitor_profile = MonitorColorProfile::detect_from_windows();
    let pdfium = match PdfiumLibrary::load() {
        Ok(lib) => {
            let _ = evt_tx.send(WorkerEvent::EngineReady {
                monitor_profile: monitor_profile.clone(),
            });
            egui_ctx.request_repaint();
            lib
        }
        Err(err) => {
            let _ = evt_tx.send(WorkerEvent::EngineError(err));
            egui_ctx.request_repaint();
            return;
        }
    };

    let mut documents: HashMap<u64, PdfDocumentHandle> = HashMap::new();
    let mut recently_rendered: HashMap<PageCacheKey, Instant> = HashMap::new();
    let mut pending_tasks: Vec<RenderTask> = Vec::new();
    let mut pending_covers: Vec<(PathBuf, u32)> = Vec::new();

    loop {
        if pending_tasks.is_empty() && pending_covers.is_empty() {
            match cmd_rx.recv() {
                Ok(cmd) => {
                    if !handle_command(
                        cmd,
                        &pdfium,
                        &monitor_profile,
                        &mut documents,
                        &mut recently_rendered,
                        &mut pending_tasks,
                        &mut pending_covers,
                        &evt_tx,
                        &egui_ctx,
                    ) {
                        break;
                    }
                }
                Err(_) => break,
            }
        }

        while let Ok(cmd) = cmd_rx.try_recv() {
            if !handle_command(
                cmd,
                &pdfium,
                &monitor_profile,
                &mut documents,
                &mut recently_rendered,
                &mut pending_tasks,
                &mut pending_covers,
                &evt_tx,
                &egui_ctx,
            ) {
                return;
            }
        }

        // ƯU TIÊN SỐ 1: Kết xuất các trang của tài liệu đang mở
        if let Some(task) = pending_tasks.pop() {
            if let Some(&ts) = recently_rendered.get(&task.key) {
                if ts.elapsed().as_millis() < 800 {
                    continue;
                }
            }
            if let Some(doc) = documents.get_mut(&task.key.doc_id) {
                let t0 = Instant::now();
                if let Ok(bitmap) = doc.render_page_ex(
                    task.key.page_index,
                    task.key.width_px,
                    task.key.height_px,
                    task.key.rotation_steps,
                    task.key.color_mode,
                    &monitor_profile,
                    task.key.is_thumbnail,
                ) {
                    let render_ms = t0.elapsed().as_secs_f64() * 1000.0;
                    recently_rendered.insert(task.key, Instant::now());
                    let _ = evt_tx.send(WorkerEvent::PageRendered {
                        key: task.key,
                        bitmap,
                        render_ms,
                    });
                    egui_ctx.request_repaint();
                }
            }
            continue;
        }

        // ƯU TIÊN SỐ 2 (Chỉ chạy khi rảnh): Kết xuất ảnh bìa trong màn hình Xem Bìa
        if let Some((path, max_side_px)) = pending_covers.pop() {
            if let Ok(mut handle) = PdfDocumentHandle::open(Arc::clone(&pdfium), &path) {
                let page_count = handle.page_dimensions.len();
                let file_size_bytes = handle.file_size_bytes;
                if let Some(dim) = handle.page_dimensions.first() {
                    let aspect = dim.aspect_ratio(0);
                    let (w, h) = if aspect >= 1.0 {
                        (
                            max_side_px,
                            ((max_side_px as f32) / aspect).round().max(48.0) as u32,
                        )
                    } else {
                        (
                            ((max_side_px as f32) * aspect).round().max(48.0) as u32,
                            max_side_px,
                        )
                    };
                    if let Ok(bitmap) = handle.render_page_ex(
                        0,
                        w,
                        h,
                        0,
                        ColorMode::StandardSrgb,
                        &monitor_profile,
                        true,
                    ) {
                        let _ = evt_tx.send(WorkerEvent::CoverPreviewRendered {
                            path,
                            bitmap,
                            page_count,
                            file_size_bytes,
                        });
                        egui_ctx.request_repaint();
                    }
                }
            }
        }
    }
}

fn handle_command(
    cmd: WorkerCommand,
    pdfium: &Arc<PdfiumLibrary>,
    monitor_profile: &MonitorColorProfile,
    documents: &mut HashMap<u64, PdfDocumentHandle>,
    recently_rendered: &mut HashMap<PageCacheKey, Instant>,
    pending_tasks: &mut Vec<RenderTask>,
    pending_covers: &mut Vec<(PathBuf, u32)>,
    evt_tx: &Sender<WorkerEvent>,
    egui_ctx: &egui::Context,
) -> bool {
    recently_rendered.retain(|_, ts| ts.elapsed().as_millis() < 800);

    match cmd {
        WorkerCommand::OpenDocument { doc_id, path } => {
            pending_covers.clear();
            let t0 = Instant::now();
            match PdfDocumentHandle::open(Arc::clone(pdfium), &path) {
                Ok(handle) => {
                    let open_ms = t0.elapsed().as_secs_f64() * 1000.0;
                    let page_dimensions = handle.page_dimensions.clone();
                    let file_size_bytes = handle.file_size_bytes;
                    let color_meta = handle.color_meta.clone();
                    documents.insert(doc_id, handle);
                    let _ = evt_tx.send(WorkerEvent::DocumentOpened {
                        doc_id,
                        file_size_bytes,
                        page_dimensions,
                        color_meta,
                        open_ms,
                    });
                    egui_ctx.request_repaint();
                }
                Err(error) => {
                    let _ = evt_tx.send(WorkerEvent::DocumentOpenFailed { doc_id, error });
                    egui_ctx.request_repaint();
                }
            }
            true
        }
        WorkerCommand::CloseDocument { doc_id } => {
            documents.remove(&doc_id);
            recently_rendered.retain(|k, _| k.doc_id != doc_id);
            pending_tasks.retain(|t| t.key.doc_id != doc_id);
            true
        }
        WorkerCommand::SyncRenderQueue { mut tasks } => {
            tasks.retain(|t| !recently_rendered.contains_key(&t.key));
            tasks.sort_by(|a, b| {
                b.priority
                    .cmp(&a.priority)
                    .then_with(|| a.key.is_thumbnail.cmp(&b.key.is_thumbnail))
                    .then_with(|| b.key.page_index.cmp(&a.key.page_index))
            });
            *pending_tasks = tasks;
            true
        }
        WorkerCommand::RenderCoverPreview { path, max_side_px } => {
            pending_covers.insert(0, (path, max_side_px));
            true
        }
        WorkerCommand::CopyPageToClipboard {
            doc_id,
            page_index,
            rotation_steps,
            color_mode,
        } => {
            if let Some(doc) = documents.get_mut(&doc_id) {
                let dim = doc
                    .page_dimensions
                    .get(page_index)
                    .copied()
                    .unwrap_or(PageDimension {
                        width_pt: 595.0,
                        height_pt: 842.0,
                    });
                let (pt_w, pt_h) = dim.rotated_size(rotation_steps);
                // Kết xuất ở hệ số 2.2x (~160 DPI) để ảnh dán vào Zalo / Word / Photoshop cực kỳ sắc nét
                let w = ((pt_w * 2.2).round() as u32).clamp(200, 3200);
                let h = ((pt_h * 2.2).round() as u32).clamp(200, 3200);

                match doc.render_page(page_index, w, h, rotation_steps, color_mode, monitor_profile)
                {
                    Ok(bmp) => match arboard::Clipboard::new() {
                        Ok(mut cb) => {
                            let img_data = arboard::ImageData {
                                width: bmp.width,
                                height: bmp.height,
                                bytes: Cow::Borrowed(&bmp.rgba),
                            };
                            match cb.set_image(img_data) {
                                Ok(_) => {
                                    let _ = evt_tx.send(WorkerEvent::ActionToast {
                                        message: format!(
                                            "✅ Đã copy Trang {} ({}x{} px) vào Clipboard! Nhấn Ctrl+V để dán.",
                                            page_index + 1,
                                            bmp.width,
                                            bmp.height
                                        ),
                                        is_error: false,
                                    });
                                }
                                Err(e) => {
                                    let _ = evt_tx.send(WorkerEvent::ActionToast {
                                        message: format!("Không thể ghi ảnh vào Clipboard: {e}"),
                                        is_error: true,
                                    });
                                }
                            }
                        }
                        Err(e) => {
                            let _ = evt_tx.send(WorkerEvent::ActionToast {
                                message: format!("Không thể mở Clipboard Windows: {e}"),
                                is_error: true,
                            });
                        }
                    },
                    Err(e) => {
                        let _ = evt_tx.send(WorkerEvent::ActionToast {
                            message: format!("Lỗi kết xuất trang: {e}"),
                            is_error: true,
                        });
                    }
                }
                egui_ctx.request_repaint();
            }
            true
        }
        WorkerCommand::ExportPageToImage {
            doc_id,
            page_index,
            rotation_steps,
            color_mode,
            dest_path,
        } => {
            if let Some(doc) = documents.get_mut(&doc_id) {
                let dim = doc
                    .page_dimensions
                    .get(page_index)
                    .copied()
                    .unwrap_or(PageDimension {
                        width_pt: 595.0,
                        height_pt: 842.0,
                    });
                let (pt_w, pt_h) = dim.rotated_size(rotation_steps);
                // Kết xuất ở hệ số 2.5x (~180 DPI) chất lượng cao chuẩn in ấn / thiết kế
                let w = ((pt_w * 2.5).round() as u32).clamp(200, 3840);
                let h = ((pt_h * 2.5).round() as u32).clamp(200, 3840);

                match doc.render_page(page_index, w, h, rotation_steps, color_mode, monitor_profile)
                {
                    Ok(bmp) => {
                        let is_png = dest_path
                            .extension()
                            .and_then(|s| s.to_str())
                            .map(|s| s.eq_ignore_ascii_case("png"))
                            .unwrap_or(false);

                        let save_res = if is_png {
                            image::RgbaImage::from_raw(
                                bmp.width as u32,
                                bmp.height as u32,
                                bmp.rgba,
                            )
                            .ok_or_else(|| "Buffer ảnh không hợp lệ".to_string())
                            .and_then(|img| img.save(&dest_path).map_err(|e| e.to_string()))
                        } else {
                            // Chuyển RGBA -> RGB24 để xuất JPEG chuẩn chất lượng 95%
                            let mut rgb = Vec::with_capacity(bmp.width * bmp.height * 3);
                            for px in bmp.rgba.chunks_exact(4) {
                                rgb.extend_from_slice(&[px[0], px[1], px[2]]);
                            }
                            File::create(&dest_path)
                                .map_err(|e| e.to_string())
                                .and_then(|file| {
                                    let writer = BufWriter::new(file);
                                    let mut encoder = JpegEncoder::new_with_quality(writer, 95);
                                    encoder
                                        .encode(
                                            &rgb,
                                            bmp.width as u32,
                                            bmp.height as u32,
                                            ExtendedColorType::Rgb8,
                                        )
                                        .map_err(|e| e.to_string())
                                })
                        };

                        match save_res {
                            Ok(_) => {
                                let _ = evt_tx.send(WorkerEvent::ActionToast {
                                    message: format!(
                                        "✅ Đã xuất Trang {} ({}x{} px) ra file: {}",
                                        page_index + 1,
                                        bmp.width,
                                        bmp.height,
                                        dest_path.display()
                                    ),
                                    is_error: false,
                                });
                            }
                            Err(e) => {
                                let _ = evt_tx.send(WorkerEvent::ActionToast {
                                    message: format!("Không thể lưu file ảnh: {e}"),
                                    is_error: true,
                                });
                            }
                        }
                    }
                    Err(e) => {
                        let _ = evt_tx.send(WorkerEvent::ActionToast {
                            message: format!("Lỗi kết xuất trang: {e}"),
                            is_error: true,
                        });
                    }
                }
                egui_ctx.request_repaint();
            }
            true
        }
    }
}
