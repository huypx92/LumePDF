use std::path::Path;
use std::process::Command;

fn main() {
    println!("cargo:rerun-if-changed=assets/lumepdf.rc");
    println!("cargo:rerun-if-changed=assets/lumepdf.ico");

    if cfg!(target_os = "windows") && Path::new("assets/lumepdf.ico").exists() {
        let out_dir = std::env::var("OUT_DIR").unwrap();
        let res_obj = format!("{out_dir}/lumepdf_res.o");
        let status = Command::new("windres")
            .args(["assets/lumepdf.rc", "-O", "coff", "-o", &res_obj])
            .status();

        if let Ok(s) = status {
            if s.success() {
                println!("cargo:rustc-link-arg-bins={res_obj}");
            }
        }
    }
}
