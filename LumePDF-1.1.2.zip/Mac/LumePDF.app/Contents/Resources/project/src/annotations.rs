use crate::pdf_engine::PageDimension;
use egui::{Color32, Painter, Pos2, Rect, Rounding, Shape, Stroke, Vec2};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum DrawTool {
    #[default]
    None,
    Pen,
    Line,
    Circle,
    Rect,
    Text,
    Eraser,
}

#[derive(Debug, Clone)]
pub enum AnnotationGeometry {
    Pen { points: Vec<Vec2> },
    Line { start: Vec2, end: Vec2 },
    Circle { a: Vec2, b: Vec2 },
    Rect { a: Vec2, b: Vec2 },
    Text { pos: Vec2, text: String },
}

#[derive(Debug, Clone)]
pub struct PdfAnnotation {
    pub anchor_page: usize,
    pub color: Color32,
    pub stroke_pt: f32,
    pub geom: AnnotationGeometry,
}

#[derive(Debug, Clone)]
pub struct ActiveDrawDraft {
    pub doc_id: u64,
    pub tool: DrawTool,
    pub anchor_page: usize,
    pub color: Color32,
    pub stroke_pt: f32,
    pub start_local: Vec2,
    pub end_local: Vec2,
    pub pen_points: Vec<Vec2>,
    pub last_screen_pos: Pos2,
}

pub const DRAW_COLOR_PRESETS: [Color32; 5] = [
    Color32::from_rgb(225, 29, 72),  // Đỏ nổi bật (mặc định)
    Color32::from_rgb(0, 103, 192),  // Xanh dương Win11 Accent
    Color32::from_rgb(234, 88, 12),  // Cam đậm
    Color32::from_rgb(5, 150, 105),  // Xanh lá ngọc
    Color32::from_rgb(24, 24, 27),   // Đen mực đậm
];

pub const DRAW_STROKE_PRESETS_PT: [f32; 3] = [1.8, 3.0, 5.2];

/// Tính `Rect` hiển thị trên màn hình cho bất kỳ trang PDF nào theo bố cục dọc hiện tại.
pub fn page_screen_rect(
    origin: Pos2,
    canvas_w: f32,
    page_y_offsets: &[f32],
    page_display_sizes: &[Vec2],
    page_index: usize,
) -> Option<Rect> {
    let disp_size = *page_display_sizes.get(page_index)?;
    let y_top = *page_y_offsets.get(page_index)?;
    let x_left = origin.x + ((canvas_w - disp_size.x) * 0.5).max(8.0);
    Some(Rect::from_min_size(
        Pos2::new(x_left, origin.y + y_top),
        disp_size,
    ))
}

/// Tìm trang gần vị trí con trỏ nhất để neo nét vẽ (hoạt động cả bên trong trang lẫn ngoài lề).
pub fn find_anchor_page(
    pos: Pos2,
    origin: Pos2,
    page_y_offsets: &[f32],
    page_display_sizes: &[Vec2],
) -> Option<usize> {
    let count = page_display_sizes.len();
    if count == 0 {
        return None;
    }
    let rel_y = pos.y - origin.y;
    let mut best_idx = 0usize;
    let mut best_dist = f32::INFINITY;
    for (idx, disp) in page_display_sizes.iter().enumerate() {
        let top = page_y_offsets[idx];
        let bot = top + disp.y;
        let dist = if rel_y < top {
            top - rel_y
        } else if rel_y > bot {
            rel_y - bot
        } else {
            0.0
        };
        if dist < best_dist {
            best_dist = dist;
            best_idx = idx;
            if dist == 0.0 {
                break;
            }
        }
    }
    Some(best_idx)
}

pub fn rotate_pt(v: Vec2, rotation_steps: i32) -> Vec2 {
    match rotation_steps.rem_euclid(4) {
        1 => Vec2::new(-v.y, v.x),
        2 => Vec2::new(-v.x, -v.y),
        3 => Vec2::new(v.y, -v.x),
        _ => v,
    }
}

pub fn unrotate_pt(v: Vec2, rotation_steps: i32) -> Vec2 {
    match rotation_steps.rem_euclid(4) {
        1 => Vec2::new(v.y, -v.x),
        2 => Vec2::new(-v.x, -v.y),
        3 => Vec2::new(-v.y, v.x),
        _ => v,
    }
}

pub fn screen_to_page_local_pt(
    screen_pos: Pos2,
    page_rect: Rect,
    dim: PageDimension,
    rotation_steps: i32,
) -> Vec2 {
    let (rot_w, rot_h) = dim.rotated_size(rotation_steps);
    let sx = (page_rect.width() / rot_w.max(1.0)).max(0.0001);
    let sy = (page_rect.height() / rot_h.max(1.0)).max(0.0001);
    let center = page_rect.center();
    let rotated_delta = Vec2::new((screen_pos.x - center.x) / sx, (screen_pos.y - center.y) / sy);
    unrotate_pt(rotated_delta, rotation_steps)
}

pub fn page_local_pt_to_screen(
    local_pt: Vec2,
    page_rect: Rect,
    dim: PageDimension,
    rotation_steps: i32,
) -> Pos2 {
    let (rot_w, rot_h) = dim.rotated_size(rotation_steps);
    let sx = page_rect.width() / rot_w.max(1.0);
    let sy = page_rect.height() / rot_h.max(1.0);
    let center = page_rect.center();
    let rotated = rotate_pt(local_pt, rotation_steps);
    Pos2::new(center.x + rotated.x * sx, center.y + rotated.y * sy)
}

pub fn page_stroke_px(
    stroke_pt: f32,
    page_rect: Rect,
    dim: PageDimension,
    rotation_steps: i32,
) -> f32 {
    let (rot_w, rot_h) = dim.rotated_size(rotation_steps);
    let avg_scale =
        0.5 * ((page_rect.width() / rot_w.max(1.0)) + (page_rect.height() / rot_h.max(1.0)));
    (stroke_pt * avg_scale).clamp(1.2, 24.0)
}

pub fn page_text_px(
    stroke_pt: f32,
    page_rect: Rect,
    dim: PageDimension,
    rotation_steps: i32,
) -> f32 {
    let (rot_w, rot_h) = dim.rotated_size(rotation_steps);
    let avg_scale =
        0.5 * ((page_rect.width() / rot_w.max(1.0)) + (page_rect.height() / rot_h.max(1.0)));
    (stroke_pt * 5.2 * avg_scale).clamp(10.0, 72.0)
}

pub fn approx_text_size_px(text: &str, font_px: f32) -> Vec2 {
    let mut max_chars = 1usize;
    let mut line_count = 0usize;
    for line in text.lines() {
        line_count += 1;
        max_chars = max_chars.max(line.chars().count());
    }
    if line_count == 0 {
        line_count = 1;
    }
    let w = (max_chars as f32 * font_px * 0.58).max(font_px * 1.4);
    let h = (line_count as f32 * font_px * 1.25).max(font_px * 1.25);
    Vec2::new(w, h)
}

pub fn constrain_line_end(start: Pos2, end: Pos2, constrain: bool) -> Pos2 {
    if !constrain {
        return end;
    }
    let delta = end - start;
    let len = delta.length();
    if len < 1e-3 {
        return end;
    }
    let angle = delta.y.atan2(delta.x);
    let step = std::f32::consts::FRAC_PI_4;
    let snapped = (angle / step).round() * step;
    Pos2::new(start.x + len * snapped.cos(), start.y + len * snapped.sin())
}

pub fn constrain_box_end(start: Pos2, end: Pos2, constrain: bool) -> Pos2 {
    if !constrain {
        return end;
    }
    let dx = end.x - start.x;
    let dy = end.y - start.y;
    let side = dx.abs().max(dy.abs());
    let sx = if dx < 0.0 { -1.0 } else { 1.0 };
    let sy = if dy < 0.0 { -1.0 } else { 1.0 };
    Pos2::new(start.x + sx * side, start.y + sy * side)
}

pub fn paint_annotation(
    painter: &Painter,
    ann: &PdfAnnotation,
    origin: Pos2,
    canvas_w: f32,
    page_y_offsets: &[f32],
    page_display_sizes: &[Vec2],
    page_dimensions: &[PageDimension],
    rotation_steps: i32,
    override_color: Option<Color32>,
    extra_width_px: f32,
) {
    let Some(page_rect) = page_screen_rect(
        origin,
        canvas_w,
        page_y_offsets,
        page_display_sizes,
        ann.anchor_page,
    ) else {
        return;
    };
    let Some(&dim) = page_dimensions.get(ann.anchor_page) else {
        return;
    };

    let color = override_color.unwrap_or(ann.color);
    let width = page_stroke_px(ann.stroke_pt, page_rect, dim, rotation_steps) + extra_width_px;
    let stroke = Stroke::new(width, color);

    match &ann.geom {
        AnnotationGeometry::Pen { points } => {
            if points.is_empty() {
                return;
            }
            if points.len() == 1 {
                let p = page_local_pt_to_screen(points[0], page_rect, dim, rotation_steps);
                painter.circle_filled(p, (width * 0.55).max(1.5), color);
                return;
            }
            let screen_pts: Vec<Pos2> = points
                .iter()
                .map(|&pt| page_local_pt_to_screen(pt, page_rect, dim, rotation_steps))
                .collect();
            if let Some(&first) = screen_pts.first() {
                painter.circle_filled(first, width * 0.45, color);
            }
            if let Some(&last) = screen_pts.last() {
                painter.circle_filled(last, width * 0.45, color);
            }
            painter.add(Shape::line(screen_pts, stroke));
        }
        AnnotationGeometry::Line { start, end } => {
            let s = page_local_pt_to_screen(*start, page_rect, dim, rotation_steps);
            let e = page_local_pt_to_screen(*end, page_rect, dim, rotation_steps);
            painter.circle_filled(s, width * 0.45, color);
            painter.circle_filled(e, width * 0.45, color);
            painter.line_segment([s, e], stroke);
        }
        AnnotationGeometry::Circle { a, b } => {
            let sa = page_local_pt_to_screen(*a, page_rect, dim, rotation_steps);
            let sb = page_local_pt_to_screen(*b, page_rect, dim, rotation_steps);
            let r = Rect::from_two_pos(sa, sb);
            let radius = Vec2::new((r.width() * 0.5).max(1.0), (r.height() * 0.5).max(1.0));
            painter.add(Shape::Ellipse(egui::epaint::EllipseShape::stroke(
                r.center(),
                radius,
                stroke,
            )));
        }
        AnnotationGeometry::Rect { a, b } => {
            let sa = page_local_pt_to_screen(*a, page_rect, dim, rotation_steps);
            let sb = page_local_pt_to_screen(*b, page_rect, dim, rotation_steps);
            let r = Rect::from_two_pos(sa, sb);
            painter.rect_stroke(r, Rounding::same(2.0), stroke);
        }
        AnnotationGeometry::Text { pos, text } => {
            if text.trim().is_empty() {
                return;
            }
            let screen_pos = page_local_pt_to_screen(*pos, page_rect, dim, rotation_steps);
            let font_px = page_text_px(ann.stroke_pt, page_rect, dim, rotation_steps);
            let galley_rect = painter.text(
                screen_pos,
                egui::Align2::LEFT_TOP,
                text,
                egui::FontId::proportional(font_px),
                color,
            );
            if extra_width_px > 0.0 {
                painter.rect_stroke(
                    galley_rect.expand(4.0),
                    Rounding::same(3.0),
                    Stroke::new(1.5_f32, color),
                );
            }
        }
    }
}

pub fn draft_to_annotation(draft: &ActiveDrawDraft) -> Option<PdfAnnotation> {
    let geom = match draft.tool {
        DrawTool::Pen => {
            if draft.pen_points.is_empty() {
                return None;
            }
            AnnotationGeometry::Pen {
                points: draft.pen_points.clone(),
            }
        }
        DrawTool::Line => {
            if (draft.end_local - draft.start_local).length() < 1.0 {
                return None;
            }
            AnnotationGeometry::Line {
                start: draft.start_local,
                end: draft.end_local,
            }
        }
        DrawTool::Circle => {
            if (draft.end_local.x - draft.start_local.x).abs() < 1.0
                && (draft.end_local.y - draft.start_local.y).abs() < 1.0
            {
                return None;
            }
            AnnotationGeometry::Circle {
                a: draft.start_local,
                b: draft.end_local,
            }
        }
        DrawTool::Rect => {
            if (draft.end_local.x - draft.start_local.x).abs() < 1.0
                && (draft.end_local.y - draft.start_local.y).abs() < 1.0
            {
                return None;
            }
            AnnotationGeometry::Rect {
                a: draft.start_local,
                b: draft.end_local,
            }
        }
        DrawTool::None | DrawTool::Text | DrawTool::Eraser => return None,
    };

    Some(PdfAnnotation {
        anchor_page: draft.anchor_page,
        color: draft.color,
        stroke_pt: draft.stroke_pt,
        geom,
    })
}

pub fn point_to_segment_dist_sq(p: Pos2, a: Pos2, b: Pos2) -> f32 {
    let ab = b - a;
    let len_sq = ab.length_sq();
    if len_sq <= 1e-6 {
        return p.distance_sq(a);
    }
    let t = ((p - a).dot(ab) / len_sq).clamp(0.0, 1.0);
    let proj = a + ab * t;
    p.distance_sq(proj)
}

pub fn annotation_hits_screen_pos(
    ann: &PdfAnnotation,
    cursor: Pos2,
    origin: Pos2,
    canvas_w: f32,
    page_y_offsets: &[f32],
    page_display_sizes: &[Vec2],
    page_dimensions: &[PageDimension],
    rotation_steps: i32,
) -> bool {
    let Some(page_rect) = page_screen_rect(
        origin,
        canvas_w,
        page_y_offsets,
        page_display_sizes,
        ann.anchor_page,
    ) else {
        return false;
    };
    let Some(&dim) = page_dimensions.get(ann.anchor_page) else {
        return false;
    };

    let width = page_stroke_px(ann.stroke_pt, page_rect, dim, rotation_steps);
    let tol = width * 0.5 + 8.0;
    let tol_sq = tol * tol;

    match &ann.geom {
        AnnotationGeometry::Pen { points } => {
            if points.is_empty() {
                return false;
            }
            if points.len() == 1 {
                let sp = page_local_pt_to_screen(points[0], page_rect, dim, rotation_steps);
                return cursor.distance_sq(sp) <= tol_sq;
            }
            let mut prev = page_local_pt_to_screen(points[0], page_rect, dim, rotation_steps);
            for &pt in &points[1..] {
                let next = page_local_pt_to_screen(pt, page_rect, dim, rotation_steps);
                if point_to_segment_dist_sq(cursor, prev, next) <= tol_sq {
                    return true;
                }
                prev = next;
            }
            false
        }
        AnnotationGeometry::Line { start, end } => {
            let sa = page_local_pt_to_screen(*start, page_rect, dim, rotation_steps);
            let sb = page_local_pt_to_screen(*end, page_rect, dim, rotation_steps);
            point_to_segment_dist_sq(cursor, sa, sb) <= tol_sq
        }
        AnnotationGeometry::Rect { a, b } => {
            let sa = page_local_pt_to_screen(*a, page_rect, dim, rotation_steps);
            let sb = page_local_pt_to_screen(*b, page_rect, dim, rotation_steps);
            let r = Rect::from_two_pos(sa, sb);
            if r.width() < 16.0 && r.height() < 16.0 {
                return r.expand(tol).contains(cursor);
            }
            let tl = r.left_top();
            let tr = r.right_top();
            let br = r.right_bottom();
            let bl = r.left_bottom();
            point_to_segment_dist_sq(cursor, tl, tr) <= tol_sq
                || point_to_segment_dist_sq(cursor, tr, br) <= tol_sq
                || point_to_segment_dist_sq(cursor, br, bl) <= tol_sq
                || point_to_segment_dist_sq(cursor, bl, tl) <= tol_sq
        }
        AnnotationGeometry::Circle { a, b } => {
            let sa = page_local_pt_to_screen(*a, page_rect, dim, rotation_steps);
            let sb = page_local_pt_to_screen(*b, page_rect, dim, rotation_steps);
            let r = Rect::from_two_pos(sa, sb);
            let rx = (r.width() * 0.5).max(1.0);
            let ry = (r.height() * 0.5).max(1.0);
            if rx < 8.0 && ry < 8.0 {
                return r.expand(tol).contains(cursor);
            }
            let c = r.center();
            let dx = cursor.x - c.x;
            let dy = cursor.y - c.y;
            if dx.abs() > rx + tol || dy.abs() > ry + tol {
                return false;
            }
            let norm = (dx / rx).powi(2) + (dy / ry).powi(2);
            let approx_radial_dist = (norm.sqrt() - 1.0).abs() * rx.min(ry);
            approx_radial_dist <= tol
        }
        AnnotationGeometry::Text { pos, text } => {
            let sp = page_local_pt_to_screen(*pos, page_rect, dim, rotation_steps);
            let font_px = page_text_px(ann.stroke_pt, page_rect, dim, rotation_steps);
            let size = approx_text_size_px(text, font_px);
            Rect::from_min_size(sp, size).expand(8.0).contains(cursor)
        }
    }
}

pub fn find_hit_annotation_index(
    annotations: &[PdfAnnotation],
    cursor: Pos2,
    origin: Pos2,
    canvas_w: f32,
    page_y_offsets: &[f32],
    page_display_sizes: &[Vec2],
    page_dimensions: &[PageDimension],
    rotation_steps: i32,
) -> Option<usize> {
    annotations.iter().rposition(|ann| {
        annotation_hits_screen_pos(
            ann,
            cursor,
            origin,
            canvas_w,
            page_y_offsets,
            page_display_sizes,
            page_dimensions,
            rotation_steps,
        )
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrips_margin_points_across_zoom_and_rotation() {
        let dim = PageDimension {
            width_pt: 200.0,
            height_pt: 100.0,
        };
        let outer_margin_pt = Vec2::new(-165.0, -70.0); // Ngoài lề trái và phía trên trang
        for steps in 0..4 {
            let (rw, rh) = dim.rotated_size(steps);
            let page_rect = Rect::from_min_size(Pos2::new(300.0, 80.0), Vec2::new(rw * 2.0, rh * 2.0));
            let screen = page_local_pt_to_screen(outer_margin_pt, page_rect, dim, steps);
            assert!(!page_rect.contains(screen));
            let recovered = screen_to_page_local_pt(screen, page_rect, dim, steps);
            assert!((recovered.x - outer_margin_pt.x).abs() < 0.01);
            assert!((recovered.y - outer_margin_pt.y).abs() < 0.01);
        }
    }

    #[test]
    fn hits_outer_margin_line_circle_rect_and_pen_for_eraser() {
        let dim = PageDimension {
            width_pt: 200.0,
            height_pt: 100.0,
        };
        let page_dims = vec![dim];
        let page_sizes = vec![Vec2::new(200.0, 100.0)];
        let offsets = vec![14.0, 128.0];
        let origin = Pos2::ZERO;
        let canvas_w = 1000.0;
        let page_rect = page_screen_rect(origin, canvas_w, &offsets, &page_sizes, 0).unwrap();

        // Nét kẻ hoàn toàn ngoài lề trái trang PDF
        let line = PdfAnnotation {
            anchor_page: 0,
            color: DRAW_COLOR_PRESETS[0],
            stroke_pt: 3.0,
            geom: AnnotationGeometry::Line {
                start: Vec2::new(-200.0, -20.0),
                end: Vec2::new(-130.0, 40.0),
            },
        };
        // Khoanh tròn trùm từ trong trang ra ngoài lề
        let circle = PdfAnnotation {
            anchor_page: 0,
            color: DRAW_COLOR_PRESETS[1],
            stroke_pt: 3.0,
            geom: AnnotationGeometry::Circle {
                a: Vec2::new(60.0, -40.0),
                b: Vec2::new(140.0, 40.0),
            },
        };
        let anns = vec![line, circle];

        let hit_margin_line = page_local_pt_to_screen(Vec2::new(-165.0, 10.0), page_rect, dim, 0);
        assert_eq!(
            find_hit_annotation_index(&anns, hit_margin_line, origin, canvas_w, &offsets, &page_sizes, &page_dims, 0),
            Some(0)
        );

        let hit_circle_edge = page_local_pt_to_screen(Vec2::new(140.0, 0.0), page_rect, dim, 0);
        assert_eq!(
            find_hit_annotation_index(&anns, hit_circle_edge, origin, canvas_w, &offsets, &page_sizes, &page_dims, 0),
            Some(1)
        );

        let center_inside_circle = page_local_pt_to_screen(Vec2::new(100.0, 0.0), page_rect, dim, 0);
        assert_eq!(
            find_hit_annotation_index(&anns, center_inside_circle, origin, canvas_w, &offsets, &page_sizes, &page_dims, 0),
            None
        );

        // Chữ ghi chú đặt ngoài lề phải trang PDF vẫn tẩy xóa chính xác
        let margin_text = PdfAnnotation {
            anchor_page: 0,
            color: DRAW_COLOR_PRESETS[0],
            stroke_pt: 3.0,
            geom: AnnotationGeometry::Text {
                pos: Vec2::new(140.0, -20.0),
                text: "Sua gia".to_string(),
            },
        };
        let anns_with_text = vec![margin_text];
        let hit_text = page_local_pt_to_screen(Vec2::new(155.0, -10.0), page_rect, dim, 0);
        assert_eq!(
            find_hit_annotation_index(&anns_with_text, hit_text, origin, canvas_w, &offsets, &page_sizes, &page_dims, 0),
            Some(0)
        );
    }

    #[test]
    fn constrains_shift_lines_and_squares() {
        let start = Pos2::new(100.0, 100.0);
        let horiz = constrain_line_end(start, Pos2::new(220.0, 108.0), true);
        assert!((horiz.y - 100.0).abs() < 0.01);
        let diag = constrain_line_end(start, Pos2::new(180.0, 175.0), true);
        assert!(((diag.x - start.x).abs() - (diag.y - start.y).abs()).abs() < 0.01);
        let sq = constrain_box_end(start, Pos2::new(140.0, 195.0), true);
        assert_eq!(sq, Pos2::new(195.0, 195.0));
    }
}
