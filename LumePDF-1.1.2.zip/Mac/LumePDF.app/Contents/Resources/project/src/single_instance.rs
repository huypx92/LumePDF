use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

#[derive(Default)]
struct InboxState {
    pending_paths: Vec<PathBuf>,
    focus_requested: bool,
    egui_ctx: Option<egui::Context>,
}

/// Kênh nhận yêu cầu mở tệp PDF / focus cửa sổ từ tiến trình phụ (single-instance IPC).
#[derive(Clone, Default)]
pub struct SingleInstanceInbox {
    inner: Arc<Mutex<InboxState>>,
}

impl SingleInstanceInbox {
    pub fn attach_context(&self, ctx: egui::Context) {
        if let Ok(mut guard) = self.inner.lock() {
            guard.egui_ctx = Some(ctx);
        }
    }

    pub fn push_event(&self, paths: Vec<PathBuf>, request_focus: bool) {
        if let Ok(mut guard) = self.inner.lock() {
            for p in paths {
                let norm = normalize_display_path(&p);
                if !guard.pending_paths.iter().any(|existing| paths_match(existing, &norm)) {
                    guard.pending_paths.push(norm);
                }
            }
            if request_focus {
                guard.focus_requested = true;
            }
            if let Some(ref ctx) = guard.egui_ctx {
                ctx.request_repaint();
            }
        }
    }

    pub fn take_pending(&self) -> (Vec<PathBuf>, bool) {
        if let Ok(mut guard) = self.inner.lock() {
            let paths = std::mem::take(&mut guard.pending_paths);
            let focus = guard.focus_requested;
            guard.focus_requested = false;
            (paths, focus)
        } else {
            (Vec::new(), false)
        }
    }
}

/// Chuẩn hóa đường dẫn thực tế trên đĩa và loại bỏ tiền tố `\\?\` của Windows để hiển thị & so sánh nhất quán.
pub fn normalize_display_path(path: &Path) -> PathBuf {
    if let Ok(canon) = std::fs::canonicalize(path) {
        return strip_windows_verbatim_prefix(&canon);
    }
    if path.is_relative() {
        if let Ok(cwd) = std::env::current_dir() {
            return strip_windows_verbatim_prefix(&cwd.join(path));
        }
    }
    strip_windows_verbatim_prefix(path)
}

pub fn strip_windows_verbatim_prefix(path: &Path) -> PathBuf {
    let raw = path.to_string_lossy();
    if let Some(unc) = raw.strip_prefix(r"\\?\UNC\") {
        return PathBuf::from(format!(r"\\{unc}"));
    }
    if let Some(local) = raw.strip_prefix(r"\\?\") {
        return PathBuf::from(local);
    }
    path.to_path_buf()
}

pub fn paths_match(a: &Path, b: &Path) -> bool {
    let clean_a = strip_windows_verbatim_prefix(a);
    let clean_b = strip_windows_verbatim_prefix(b);
    #[cfg(windows)]
    {
        clean_a.to_string_lossy().to_lowercase() == clean_b.to_string_lossy().to_lowercase()
    }
    #[cfg(not(windows))]
    {
        clean_a == clean_b
    }
}

pub fn encode_ipc_message(paths: &[PathBuf]) -> String {
    let mut out = String::from("FOCUS\n");
    for path in paths {
        let abs = normalize_display_path(path);
        let text = abs.to_string_lossy();
        if !text.contains('\n') && !text.contains('\r') && !text.is_empty() {
            out.push_str("OPEN\t");
            out.push_str(&text);
            out.push('\n');
        }
    }
    out.push_str("END\n");
    out
}

pub fn decode_ipc_message(msg: &str) -> (Vec<PathBuf>, bool) {
    let mut paths = Vec::new();
    let mut focus = false;
    for line in msg.lines() {
        if line == "FOCUS" {
            focus = true;
        } else if let Some(raw_path) = line.strip_prefix("OPEN\t") {
            let trimmed = raw_path.trim();
            if !trimmed.is_empty() {
                paths.push(PathBuf::from(trimmed));
                focus = true;
            }
        }
    }
    (paths, focus)
}

pub enum AcquireResult {
    Primary(SingleInstanceGuard),
    ForwardedToExisting,
}

#[cfg(windows)]
mod win_impl {
    use super::*;
    use std::fs::OpenOptions;
    use std::io::{BufRead, BufReader, Write};
    use std::mem::ManuallyDrop;
    use std::os::windows::io::{FromRawHandle, RawHandle};
    use std::ptr;
    use std::time::Duration;
    use windows_sys::Win32::Foundation::{
        CloseHandle, GetLastError, BOOL, ERROR_ALREADY_EXISTS, ERROR_PIPE_CONNECTED, HANDLE, HWND,
        INVALID_HANDLE_VALUE, LPARAM,
    };
    use windows_sys::Win32::Storage::FileSystem::PIPE_ACCESS_DUPLEX;
    use windows_sys::Win32::System::Pipes::{
        ConnectNamedPipe, CreateNamedPipeW, DisconnectNamedPipe, WaitNamedPipeW, PIPE_READMODE_BYTE,
        PIPE_TYPE_BYTE, PIPE_UNLIMITED_INSTANCES, PIPE_WAIT,
    };
    use windows_sys::Win32::System::Threading::{CreateMutexW, GetCurrentProcessId};
    use windows_sys::Win32::UI::WindowsAndMessaging::{
        AllowSetForegroundWindow, BringWindowToTop, EnumWindows, GetWindow, GetWindowThreadProcessId,
        IsIconic, IsWindowVisible, SetForegroundWindow, ShowWindow, ASFW_ANY, GW_OWNER, SW_RESTORE,
    };

    const MUTEX_NAME: &str = "Local\\LumePDF_SingleInstance_Mutex_v1";

    pub struct SingleInstanceGuard {
        mutex_handle: HANDLE,
        pub inbox: SingleInstanceInbox,
    }

    impl Drop for SingleInstanceGuard {
        fn drop(&mut self) {
            if !self.mutex_handle.is_null() && self.mutex_handle != INVALID_HANDLE_VALUE {
                unsafe {
                    CloseHandle(self.mutex_handle);
                }
                self.mutex_handle = ptr::null_mut();
            }
        }
    }

    fn to_wide_null(s: &str) -> Vec<u16> {
        s.encode_utf16().chain(std::iter::once(0)).collect()
    }

    fn session_pipe_name() -> String {
        let user = std::env::var("USERNAME").unwrap_or_else(|_| "user".to_string());
        let session = std::env::var("SESSIONNAME").unwrap_or_else(|_| "local".to_string());
        let suffix: String = format!("{user}_{session}")
            .chars()
            .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' })
            .collect();
        format!(r"\\.\pipe\LumePDF_SingleInstance_Pipe_v1_{suffix}")
    }

    fn create_server_pipe_instance(pipe_w: &[u16]) -> HANDLE {
        unsafe {
            CreateNamedPipeW(
                pipe_w.as_ptr(),
                PIPE_ACCESS_DUPLEX,
                PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
                PIPE_UNLIMITED_INSTANCES,
                8192,
                8192,
                0,
                ptr::null(),
            )
        }
    }

    pub fn acquire_or_forward(initial_files: &[PathBuf]) -> AcquireResult {
        let mutex_w = to_wide_null(MUTEX_NAME);
        let pipe_name = session_pipe_name();
        let pipe_w = to_wide_null(&pipe_name);

        let mutex_handle = unsafe { CreateMutexW(ptr::null(), 0, mutex_w.as_ptr()) };
        if mutex_handle.is_null() || mutex_handle == INVALID_HANDLE_VALUE {
            return AcquireResult::Primary(SingleInstanceGuard {
                mutex_handle: ptr::null_mut(),
                inbox: SingleInstanceInbox::default(),
            });
        }

        let already_exists = unsafe { GetLastError() == ERROR_ALREADY_EXISTS };
        if already_exists {
            // Cho phép tiến trình chính đưa cửa sổ lên foreground khi mở file từ Explorer.
            unsafe {
                AllowSetForegroundWindow(ASFW_ANY);
            }
            if try_forward_to_primary(&pipe_name, &pipe_w, initial_files) {
                unsafe {
                    CloseHandle(mutex_handle);
                }
                return AcquireResult::ForwardedToExisting;
            }
            // Nếu tiến trình cũ vừa thoát ngay thời điểm chuyển giao, kiểm tra lại quyền sở hữu mutex.
            unsafe {
                CloseHandle(mutex_handle);
            }
            let retry_mutex = unsafe { CreateMutexW(ptr::null(), 0, mutex_w.as_ptr()) };
            if !retry_mutex.is_null() && retry_mutex != INVALID_HANDLE_VALUE {
                if unsafe { GetLastError() == ERROR_ALREADY_EXISTS } {
                    // Vẫn còn tiến trình chính đang giữ mutex nhưng chưa kịp mở pipe -> thoát an toàn thay vì mở 2 cửa sổ.
                    unsafe {
                        CloseHandle(retry_mutex);
                    }
                    return AcquireResult::ForwardedToExisting;
                }
                return start_primary(retry_mutex, pipe_name, pipe_w);
            }
            return AcquireResult::ForwardedToExisting;
        }

        start_primary(mutex_handle, pipe_name, pipe_w)
    }

    fn start_primary(mutex_handle: HANDLE, pipe_name: String, pipe_w: Vec<u16>) -> AcquireResult {
        let inbox = SingleInstanceInbox::default();
        // Tạo sẵn pipe đầu tiên đồng bộ trước khi dựng cửa sổ để tránh race khi mở nhiều file cùng lúc.
        let first_pipe = create_server_pipe_instance(&pipe_w);
        let first_pipe_usize = first_pipe as usize;
        let inbox_clone = inbox.clone();

        let _ = std::thread::Builder::new()
            .name("lumepdf-ipc".to_string())
            .spawn(move || {
                run_pipe_server(first_pipe_usize, &pipe_name, &pipe_w, inbox_clone);
            });

        AcquireResult::Primary(SingleInstanceGuard {
            mutex_handle,
            inbox,
        })
    }

    fn run_pipe_server(
        first_pipe_usize: usize,
        _pipe_name: &str,
        pipe_w: &[u16],
        inbox: SingleInstanceInbox,
    ) {
        let mut pipe = first_pipe_usize as HANDLE;
        loop {
            if pipe.is_null() || pipe == INVALID_HANDLE_VALUE {
                std::thread::sleep(Duration::from_millis(50));
                pipe = create_server_pipe_instance(pipe_w);
                continue;
            }

            let connected = unsafe { ConnectNamedPipe(pipe, ptr::null_mut()) };
            let ok = connected != 0 || unsafe { GetLastError() } == ERROR_PIPE_CONNECTED;

            // Tạo sẵn instance kế tiếp ngay lập tức để client tiếp theo không bao giờ gặp ERROR_FILE_NOT_FOUND.
            let next_pipe = create_server_pipe_instance(pipe_w);

            if ok {
                let mut payload = String::new();
                {
                    let mut file =
                        ManuallyDrop::new(unsafe { std::fs::File::from_raw_handle(pipe as RawHandle) });
                    let mut reader = BufReader::new(&mut *file);
                    let mut line = String::new();
                    while let Ok(n) = reader.read_line(&mut line) {
                        if n == 0 || line == "END\n" || line == "END\r\n" {
                            break;
                        }
                        payload.push_str(&line);
                        line.clear();
                    }

                    let (paths, focus) = decode_ipc_message(&payload);
                    if !paths.is_empty() || focus {
                        inbox.push_event(paths, focus);
                        bring_current_process_window_to_front();
                    }

                    let _ = file.write_all(b"OK\n");
                    let _ = file.flush();
                }

                unsafe {
                    DisconnectNamedPipe(pipe);
                }
            }

            unsafe {
                CloseHandle(pipe);
            }
            pipe = next_pipe;
        }
    }

    fn try_forward_to_primary(pipe_name: &str, pipe_w: &[u16], initial_files: &[PathBuf]) -> bool {
        let payload = encode_ipc_message(initial_files);
        for _ in 0..50 {
            match OpenOptions::new().read(true).write(true).open(pipe_name) {
                Ok(mut pipe_file) => {
                    if pipe_file.write_all(payload.as_bytes()).is_ok() && pipe_file.flush().is_ok() {
                        let mut reader = BufReader::new(pipe_file);
                        let mut ack = String::new();
                        let _ = reader.read_line(&mut ack);
                        return true;
                    }
                }
                Err(_) => {
                    let waited = unsafe { WaitNamedPipeW(pipe_w.as_ptr(), 35) };
                    if waited == 0 {
                        std::thread::sleep(Duration::from_millis(30));
                    }
                }
            }
        }
        false
    }

    /// Đưa cửa sổ LumePDF hiện tại lên foreground và khôi phục nếu đang thu nhỏ dưới taskbar.
    pub fn bring_current_process_window_to_front() {
        struct SearchCtx {
            target_pid: u32,
            found: HWND,
        }

        unsafe extern "system" fn enum_cb(hwnd: HWND, lparam: LPARAM) -> BOOL {
            let ctx = &mut *(lparam as *mut SearchCtx);
            let mut pid: u32 = 0;
            GetWindowThreadProcessId(hwnd, &mut pid);
            if pid == ctx.target_pid
                && GetWindow(hwnd, GW_OWNER).is_null()
                && (IsWindowVisible(hwnd) != 0 || IsIconic(hwnd) != 0)
            {
                ctx.found = hwnd;
                return 0;
            }
            1
        }

        let mut search = SearchCtx {
            target_pid: unsafe { GetCurrentProcessId() },
            found: ptr::null_mut(),
        };
        unsafe {
            EnumWindows(Some(enum_cb), &mut search as *mut SearchCtx as LPARAM);
            if !search.found.is_null() {
                if IsIconic(search.found) != 0 {
                    ShowWindow(search.found, SW_RESTORE);
                }
                SetForegroundWindow(search.found);
                BringWindowToTop(search.found);
            }
        }
    }
}

#[cfg(not(windows))]
mod win_impl {
    use super::*;

    pub struct SingleInstanceGuard {
        pub inbox: SingleInstanceInbox,
    }

    pub fn acquire_or_forward(_initial_files: &[PathBuf]) -> AcquireResult {
        AcquireResult::Primary(SingleInstanceGuard {
            inbox: SingleInstanceInbox::default(),
        })
    }

    pub fn bring_current_process_window_to_front() {}
}

pub use win_impl::{acquire_or_forward, bring_current_process_window_to_front, SingleInstanceGuard};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_windows_verbatim_prefixes_cleanly() {
        assert_eq!(
            strip_windows_verbatim_prefix(Path::new(r"\\?\D:\Docs\Bao gia.pdf")),
            PathBuf::from(r"D:\Docs\Bao gia.pdf")
        );
        assert_eq!(
            strip_windows_verbatim_prefix(Path::new(r"\\?\UNC\server\share\Menu.pdf")),
            PathBuf::from(r"\\server\share\Menu.pdf")
        );
        assert_eq!(
            strip_windows_verbatim_prefix(Path::new(r"D:\Docs\Normal.pdf")),
            PathBuf::from(r"D:\Docs\Normal.pdf")
        );
    }

    #[cfg(windows)]
    #[test]
    fn matches_windows_paths_case_insensitively() {
        assert!(paths_match(
            Path::new(r"\\?\D:\Thiet ke\In Đại Minh - Báo giá.pdf"),
            Path::new(r"d:\thiet ke\in đại minh - báo giá.PDF")
        ));
        assert!(!paths_match(
            Path::new(r"D:\Docs\A.pdf"),
            Path::new(r"D:\Docs\B.pdf")
        ));
    }

    #[test]
    fn roundtrips_ipc_open_and_focus_payloads() {
        let files = vec![
            PathBuf::from(r"D:\Docs\In Đại Minh - Báo giá.pdf"),
            PathBuf::from(r"D:\Docs\TIRAN Menu 2027.pdf"),
        ];
        let encoded = encode_ipc_message(&files);
        let (decoded, focus) = decode_ipc_message(&encoded);
        assert!(focus);
        assert_eq!(decoded, files);

        let empty_msg = encode_ipc_message(&[]);
        let (empty_paths, empty_focus) = decode_ipc_message(&empty_msg);
        assert!(empty_paths.is_empty());
        assert!(empty_focus);
    }

    #[test]
    fn inbox_deduplicates_identical_pending_paths() {
        let inbox = SingleInstanceInbox::default();
        inbox.push_event(
            vec![
                PathBuf::from(r"d:\docs\BaoGia.pdf"),
                PathBuf::from(r"D:\Docs\baogia.pdf"),
            ],
            true,
        );
        let (paths, focus) = inbox.take_pending();
        assert!(focus);
        #[cfg(windows)]
        assert_eq!(paths.len(), 1);
    }
}
